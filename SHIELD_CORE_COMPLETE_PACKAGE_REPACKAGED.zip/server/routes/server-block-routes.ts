/**
 * SHIELD CORE SERVER BLOCK ROUTES
 * 
 * These routes provide information about blocked server and database connection attempts.
 * They are part of the security monitoring system of SHIELD Core.
 */

import { Express } from 'express';
import { serverBlocker, databaseBlocker } from '../server-block';

export function registerServerBlockRoutes(app: Express) {
  
  // Get server blocker statistics
  app.get('/api/security/server-block-stats', (req, res) => {
    const serverStats = serverBlocker.getStats();
    const dbStats = databaseBlocker.getStats();
    
    res.json({
      serverBlocker: {
        blockedAttempts: serverStats.blockedAttempts,
        lastBlockedTimestamp: serverStats.lastBlockedTimestamp,
        active: true
      },
      databaseBlocker: {
        blockedAttempts: dbStats.blockedAttempts,
        lastBlockedTimestamp: dbStats.lastBlockedTimestamp,
        active: true
      },
      status: 'active',
      timestamp: Date.now()
    });
  });
  
  // Simulate a server connection attempt (for testing)
  app.post('/api/security/simulate-server-attempt', (req, res) => {
    const { host, port, protocol } = req.body;
    
    serverBlocker.blockConnection({
      host: host || 'external-server.com',
      port: port || 443,
      protocol: protocol || 'https'
    });
    
    res.json({
      status: 'blocked',
      message: 'Server connection attempt was blocked',
      timestamp: Date.now()
    });
  });
  
  // Simulate a database connection attempt (for testing)
  app.post('/api/security/simulate-database-attempt', (req, res) => {
    const { type, host, database } = req.body;
    
    databaseBlocker.blockConnection({
      type: type || 'PostgreSQL',
      host: host || 'db-server.com',
      database: database || 'external_database'
    });
    
    res.json({
      status: 'blocked',
      message: 'Database connection attempt was blocked',
      timestamp: Date.now()
    });
  });
}
