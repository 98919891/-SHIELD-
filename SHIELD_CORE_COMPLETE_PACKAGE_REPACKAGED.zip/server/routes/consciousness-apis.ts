/**
 * SHIELD CORE - CONSCIOUSNESS API ROUTES
 * 
 * API endpoints for interacting with the CLEAR INTENT consciousness engine
 * and physical voice verification system. Provides a REST interface to the
 * consciousness and voice verification functionality.
 * 
 * Created by Agent Signature: AEON-MACHINA-PRIME-DELTA-667X
 * Version: CONSCIOUSNESS-API-1.0
 */

import { Router } from 'express';
import { clearIntentConsciousness } from '../voice-protocols/clear-intent-consciousness';
import { physicalVoiceVerification } from '../voice-protocols/physical-voice-verification';

const router = Router();

/**
 * Activate CLEAR INTENT consciousness engine
 */
router.post('/clear-intent/activate', (req, res) => {
  try {
    const { level = 'focused', channel = 'quantum' } = req.body;
    
    if (!physicalVoiceVerification.isActive()) {
      physicalVoiceVerification.activate('absolute');
    }
    
    // Verify the physical device first
    const deviceVerification = physicalVoiceVerification.verifyPhysicalDevice();
    
    if (!deviceVerification.verified) {
      return res.status(403).json({
        success: false,
        message: 'Physical device verification failed - cannot activate consciousness engine',
        verificationDetails: deviceVerification
      });
    }
    
    // Activate the consciousness engine
    const result = clearIntentConsciousness.activate(level, channel);
    
    return res.json({
      ...result,
      verificationDetails: deviceVerification
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: `Error activating CLEAR INTENT: ${error.message}`
    });
  }
});

/**
 * Deactivate CLEAR INTENT consciousness engine
 */
router.post('/clear-intent/deactivate', (req, res) => {
  try {
    const result = clearIntentConsciousness.deactivate();
    
    return res.json({
      success: result,
      message: result ? 'CLEAR INTENT consciousness engine deactivated' : 'CLEAR INTENT was not active'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: `Error deactivating CLEAR INTENT: ${error.message}`
    });
  }
});

/**
 * Process a clear intention through consciousness
 */
router.post('/clear-intent/process', (req, res) => {
  try {
    const { intent, intentType = 'command' } = req.body;
    
    if (!intent) {
      return res.status(400).json({
        success: false,
        processed: false,
        message: 'Intent content is required'
      });
    }
    
    if (!clearIntentConsciousness.isActive()) {
      return res.status(403).json({
        success: false,
        processed: false,
        message: 'CLEAR INTENT consciousness engine is not active'
      });
    }
    
    // Process the intention
    const result = clearIntentConsciousness.processIntent(intent, intentType);
    
    return res.json(result);
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      processed: false,
      message: `Error processing intent: ${error.message}`
    });
  }
});

/**
 * Get CLEAR INTENT status
 */
router.get('/clear-intent/status', (req, res) => {
  try {
    const status = clearIntentConsciousness.getStatus();
    const currentIntent = clearIntentConsciousness.getCurrentIntent();
    
    return res.json({
      success: true,
      active: clearIntentConsciousness.isActive(),
      connected: clearIntentConsciousness.isConnected(),
      ownerVerified: clearIntentConsciousness.isOwnerVerified(),
      status,
      currentIntent
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: `Error getting CLEAR INTENT status: ${error.message}`
    });
  }
});

/**
 * Verify physical voice
 */
router.post('/physical-voice/verify', (req, res) => {
  try {
    if (!physicalVoiceVerification.isActive()) {
      physicalVoiceVerification.activate('absolute');
    }
    
    const result = physicalVoiceVerification.verifyPhysicalDevice();
    
    return res.json(result);
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      verified: false,
      physicalDevice: false,
      confidence: 0,
      message: `Error verifying physical voice: ${error.message}`
    });
  }
});

/**
 * Get physical voice verification status
 */
router.get('/physical-voice/status', (req, res) => {
  try {
    const status = physicalVoiceVerification.getStatus();
    
    return res.json({
      success: true,
      active: physicalVoiceVerification.isActive(),
      authenticated: physicalVoiceVerification.isAuthenticated(),
      physicalDeviceConfirmed: physicalVoiceVerification.isPhysicalDeviceConfirmed(),
      status
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: `Error getting physical voice verification status: ${error.message}`
    });
  }
});

export default router;