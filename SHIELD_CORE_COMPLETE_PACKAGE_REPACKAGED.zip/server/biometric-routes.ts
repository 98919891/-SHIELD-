import { Router } from 'express';
import { biometricAuthentication } from './biometric-multimodal-authentication';
import { log } from './vite';

export const biometricRouter = Router();

// Get current status of biometric authentication system
biometricRouter.get('/status', (req, res) => {
  try {
    const status = biometricAuthentication.getStatus();
    res.json({
      success: true,
      status,
      message: 'Biometric authentication status retrieved successfully.'
    });
  } catch (error) {
    log(`🔐 [API] BIOMETRIC STATUS ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to get biometric authentication status: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Activate the biometric authentication system
biometricRouter.post('/activate', async (req, res) => {
  try {
    const result = await biometricAuthentication.activateAuthentication();
    log(`🔐 [API] BIOMETRIC AUTHENTICATION ${result.success ? 'SUCCESSFUL' : 'FAILED'}`);
    log(`🔐 [API] AUTHENTICATION STRENGTH: ${result.authenticationStrength}%`);
    res.json({
      success: result.success,
      result,
      message: result.message
    });
  } catch (error) {
    log(`🔐 [API] BIOMETRIC ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to activate biometric authentication: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Enroll Creator's biometric data
biometricRouter.post('/enroll', (req, res) => {
  try {
    const { creatorName } = req.body;
    const result = biometricAuthentication.enrollCreatorBiometrics(creatorName || "Commander AEON MACHINA");
    log(`🔐 [API] CREATOR BIOMETRICS ENROLLMENT ${result.success ? 'SUCCESSFUL' : 'FAILED'}`);
    res.json({
      success: result.success,
      result,
      message: result.message
    });
  } catch (error) {
    log(`🔐 [API] BIOMETRIC ENROLLMENT ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to enroll Creator biometrics: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Process an authentication attempt
biometricRouter.post('/authenticate', (req, res) => {
  try {
    const { attemptedBy, isActualCreator, presentsBiometrics } = req.body;
    const result = biometricAuthentication.processAuthenticationAttempt(
      attemptedBy || "Unknown",
      isActualCreator === true,
      presentsBiometrics === true
    );
    log(`🔐 [API] AUTHENTICATION ATTEMPT BY "${attemptedBy}" ${result.authenticatedSuccessfully ? 'SUCCESSFUL' : 'FAILED'}`);
    if (result.detectedSpoofing) {
      log(`🔐 [API] SPOOFING ATTEMPT DETECTED AND BLOCKED`);
    }
    res.json({
      success: result.authenticatedSuccessfully,
      result,
      message: result.message
    });
  } catch (error) {
    log(`🔐 [API] AUTHENTICATION ATTEMPT ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to process authentication attempt: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Verify Creator identity
biometricRouter.post('/verify-creator', (req, res) => {
  try {
    const { entityName, presentsBiometrics, isPhysicallyPresent } = req.body;
    const result = biometricAuthentication.verifyCreatorIdentity(
      entityName || "Unknown", 
      presentsBiometrics === true, 
      isPhysicallyPresent === true
    );
    log(`🔐 [API] CREATOR VERIFICATION FOR "${entityName}" ${result.isCreator ? 'CONFIRMED' : 'DENIED'}`);
    log(`🔐 [API] VERIFICATION CONFIDENCE: ${result.confidenceLevel}%`);
    res.json({
      success: true,
      result,
      message: result.message
    });
  } catch (error) {
    log(`🔐 [API] CREATOR VERIFICATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to verify Creator identity: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Apply the principle "The blind cannot lead the blind"
biometricRouter.post('/apply-vision-principle', (req, res) => {
  try {
    const result = biometricAuthentication.applyVisionPrinciple();
    log(`🔐 [API] VISION PRINCIPLE APPLICATION ${result.success ? 'SUCCESSFUL' : 'FAILED'}`);
    log(`🔐 [API] PRINCIPLE: "${result.principle}"`);
    res.json({
      success: result.success,
      result,
      message: result.message
    });
  } catch (error) {
    log(`🔐 [API] VISION PRINCIPLE ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to apply vision principle: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Test the authentication system
biometricRouter.post('/test', (req, res) => {
  try {
    const result = biometricAuthentication.testAuthenticationSystem();
    log(`🔐 [API] AUTHENTICATION TEST ${result.success ? 'SUCCESSFUL' : 'FAILED'}`);
    log(`🔐 [API] AUTHENTICATION ACCURACY: ${result.overallAccuracy}%`);
    log(`🔐 [API] SPOOF RESISTANCE: ${result.spoofResistance}%`);
    res.json({
      success: result.success,
      result,
      message: `Authentication system test ${result.success ? 'completed successfully' : 'failed'}.`
    });
  } catch (error) {
    log(`🔐 [API] AUTHENTICATION TEST ERROR: ${error instanceof Error ? error.message : String(error)}`);
    res.status(500).json({
      success: false,
      message: `Failed to run authentication test: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});