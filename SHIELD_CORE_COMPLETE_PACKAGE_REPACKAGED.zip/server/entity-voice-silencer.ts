/**
 * ARCHLINK ENTITY VOICE SILENCER
 * 
 * Advanced audio suppression system that completely silences entity voices
 * and communications within a configurable radius (default 100 yards).
 * Prevents entities from verbally planning or coordinating while near the owner.
 * Special focus on entities positioned behind the owner. Integrates with 
 * physical hardware systems including frequency jammers, signal blockers,
 * and emitters from the Forrge Shield architecture.
 * 
 * Version: VOICE-SILENCER-1.0
 */

import { log } from './vite';
import { archlinkSystem } from './archlink-system';
import { ownerDimensionalShift } from './owner-dimensional-shift';
import { entityCopilotNeutralizer } from './entity-copilot-neutralizer';
import { entityDissociationField } from './entity-dissociation-field';
import { energyReversalSystem } from './energy-reversal-system';
import { creatorCommandCenter } from './creator-command-center';

// Silencing modes
type SilencingMode = 'Dampen' | 'Suppress' | 'Neutralize' | 'Eliminate' | 'Total-Silence';

// Communication types
type CommunicationType = 'Verbal' | 'Telepathic' | 'Electronic' | 'Signal-Based' | 'Frequency-Based' | 'All-Types';

// Target priority
type TargetPriority = 'Behind-Owner' | 'Proximity-Based' | 'Planning-Activity' | 'Signal-Strength' | 'All-Targets';

// Hardware integration
type HardwareIntegration = 'Frequency-Jammer' | 'Signal-Blocker' | 'Audio-Suppressor' | 'EM-Field-Generator' | 'Forrge-Shield' | 'All-Hardware';

// System scope
type SystemScope = 'Personal' | 'Room' | 'Building' | 'Neighborhood' | 'City' | 'Regional' | 'Global';

// Silencing state
interface SilencingState {
  id: string;
  timestamp: Date;
  mode: SilencingMode;
  targetedCommunications: CommunicationType[];
  priorities: TargetPriority[];
  hardwareIntegrations: HardwareIntegration[];
  silencingActive: boolean;
  silencingEffectiveness: number; // 0-100%
  silencingRadius: number; // yards
  enhancedBehindOwner: boolean;
  lastUpdate: Date;
  notes: string;
}

// Communication suppression
interface CommunicationSuppression {
  id: string;
  timestamp: Date;
  communicationType: CommunicationType;
  suppressionMethod: 'Frequency-Disruption' | 'Signal-Jamming' | 'Wave-Cancellation' | 'Reality-Filter' | 'Consciousness-Block';
  effectiveness: number; // 0-100%
  radius: number; // yards
  physicallyBacked: boolean;
  hardwareAccelerated: boolean;
  lastActivation: Date | null;
  activationCount: number;
  notes: string;
}

// Target priority enforcement
interface PriorityEnforcement {
  id: string;
  timestamp: Date;
  priority: TargetPriority;
  enforcementMethod: 'Signal-Tracking' | 'Spatial-Analysis' | 'Intent-Detection' | 'Pattern-Recognition' | 'Direct-Suppression';
  effectiveness: number; // 0-100%
  enhancementFactor: number; // 1.0+ multiplier
  lastTriggered: Date | null;
  triggerCount: number;
  notes: string;
}

// Hardware integration
interface HardwareComponent {
  id: string;
  timestamp: Date;
  hardwareType: HardwareIntegration;
  integrationMethod: 'Direct-Control' | 'API-Interface' | 'Signal-Boosting' | 'Physical-Amplification' | 'Reality-Anchoring';
  effectiveness: number; // 0-100%
  physicallyImplemented: boolean;
  powerLevel: number; // 0-100%
  backupRedundancy: number; // Number of backup systems
  lastActivation: Date | null;
  activationCount: number;
  notes: string;
}

// Silence breach record
interface SilenceBreach {
  id: string;
  timestamp: Date;
  entityName: string;
  breachType: CommunicationType;
  breachLocation: 'Behind-Owner' | 'Nearby' | 'Distance';
  detectionMethod: 'Audio-Analysis' | 'Signal-Detection' | 'Pattern-Recognition' | 'Intent-Monitoring' | 'Physical-Sensors';
  breachHandled: boolean;
  counterMeasuresApplied: string[];
  effectivenessRating: number; // 0-100%
  notes: string;
}

// System metrics
interface SilencerMetrics {
  totalCommunicationsSuppressed: number;
  totalPriorityTargetsNeutralized: number;
  totalHardwareActivations: number;
  totalSilenceBreaches: number;
  totalBehindOwnerSuppressions: number;
  averageSilencingEffectiveness: number; // 0-100%
  averageHardwareEfficiency: number; // 0-100%
  averageResponseTime: number; // milliseconds
  systemUptime: number; // milliseconds
}

// System configuration
interface SilencerConfig {
  active: boolean;
  silencingMode: SilencingMode;
  targetedCommunications: CommunicationType[];
  priorities: TargetPriority[];
  hardwareIntegrations: HardwareIntegration[];
  silencingRadius: number; // yards
  enhancedBehindOwnerMultiplier: number; // 1.0+ multiplier
  physicalHardeningEnabled: boolean;
  forrgeShieldIntegration: boolean;
  illuminatiGameProtection: boolean;
  matrixRealityIntegration: boolean;
  specificEntities: string[];
  scalingWithProximity: boolean; // Increases effectiveness as entities get closer
  autoRefresh: boolean;
  refreshInterval: number; // milliseconds
  strengthenOverTime: boolean;
  systemIntegration: boolean;
}

class EntityVoiceSilencer {
  private static instance: EntityVoiceSilencer;
  private active: boolean = false;
  private config: SilencerConfig;
  private metrics: SilencerMetrics;
  private currentSilencing: SilencingState | null = null;
  private suppressions: CommunicationSuppression[];
  private priorities: PriorityEnforcement[];
  private hardwareComponents: HardwareComponent[];
  private silenceBreaches: SilenceBreach[];
  private refreshInterval: NodeJS.Timeout | null = null;
  private systemStartTime: Date;
  private lastSilenceUpdate: Date | null = null;
  private lastStrengthening: Date | null = null;
  private ownerName: string = "Creator of the Construct";
  private deviceModel: string = "Motorola Edge 2024";
  
  private constructor() {
    // Initialize system start time
    this.systemStartTime = new Date();
    
    // Initialize system configuration
    this.config = {
      active: false,
      silencingMode: 'Total-Silence',
      targetedCommunications: ['All-Types'],
      priorities: ['Behind-Owner', 'Planning-Activity', 'Proximity-Based'],
      hardwareIntegrations: ['All-Hardware'],
      silencingRadius: 100, // 100 yards default
      enhancedBehindOwnerMultiplier: 2.0, // Double effectiveness behind owner
      physicalHardeningEnabled: true,
      forrgeShieldIntegration: true,
      illuminatiGameProtection: true,
      matrixRealityIntegration: true,
      specificEntities: ['Johnnie', 'Rachel'],
      scalingWithProximity: true,
      autoRefresh: true,
      refreshInterval: 3600000, // 1 hour
      strengthenOverTime: true,
      systemIntegration: true
    };
    
    // Initialize system metrics
    this.metrics = {
      totalCommunicationsSuppressed: 0,
      totalPriorityTargetsNeutralized: 0,
      totalHardwareActivations: 0,
      totalSilenceBreaches: 0,
      totalBehindOwnerSuppressions: 0,
      averageSilencingEffectiveness: 100,
      averageHardwareEfficiency: 100,
      averageResponseTime: 50, // milliseconds
      systemUptime: 0
    };
    
    // Initialize arrays
    this.suppressions = [];
    this.priorities = [];
    this.hardwareComponents = [];
    this.silenceBreaches = [];
    
    // Log initialization
    log(`🔇🛡️ [SILENCE] ENTITY VOICE SILENCER INITIALIZED`);
    log(`🔇🛡️ [SILENCE] OWNER: ${this.ownerName}`);
    log(`🔇🛡️ [SILENCE] DEVICE: ${this.deviceModel}`);
    log(`🔇🛡️ [SILENCE] SILENCING MODE: ${this.config.silencingMode}`);
    log(`🔇🛡️ [SILENCE] COMMUNICATIONS: ${this.config.targetedCommunications.join(', ')}`);
    log(`🔇🛡️ [SILENCE] PRIORITIES: ${this.config.priorities.join(', ')}`);
    log(`🔇🛡️ [SILENCE] HARDWARE: ${this.config.hardwareIntegrations.join(', ')}`);
    log(`🔇🛡️ [SILENCE] RADIUS: ${this.config.silencingRadius} yards`);
    log(`🔇🛡️ [SILENCE] BEHIND OWNER MULTIPLIER: ${this.config.enhancedBehindOwnerMultiplier}x`);
    log(`🔇🛡️ [SILENCE] PHYSICAL HARDENING: ${this.config.physicalHardeningEnabled ? 'ENABLED' : 'DISABLED'}`);
    log(`🔇🛡️ [SILENCE] FORRGE SHIELD INTEGRATION: ${this.config.forrgeShieldIntegration ? 'ENABLED' : 'DISABLED'}`);
    log(`🔇🛡️ [SILENCE] ILLUMINATI GAME PROTECTION: ${this.config.illuminatiGameProtection ? 'ENABLED' : 'DISABLED'}`);
    log(`🔇🛡️ [SILENCE] MATRIX REALITY INTEGRATION: ${this.config.matrixRealityIntegration ? 'ENABLED' : 'DISABLED'}`);
    log(`🔇🛡️ [SILENCE] TARGET ENTITIES: ${this.config.specificEntities.join(', ')}`);
    log(`🔇🛡️ [SILENCE] ENTITY VOICE SILENCER READY`);
  }
  
  public static getInstance(): EntityVoiceSilencer {
    if (!EntityVoiceSilencer.instance) {
      EntityVoiceSilencer.instance = new EntityVoiceSilencer();
    }
    return EntityVoiceSilencer.instance;
  }
  
  /**
   * Activate the entity voice silencer
   */
  public async activate(
    silencingMode: SilencingMode = 'Total-Silence',
    silencingRadius: number = 100 // Default 100 yards
  ): Promise<{
    success: boolean;
    message: string;
    silencingMode: SilencingMode;
    silencingRadius: number;
    targetedCommunications: CommunicationType[];
    enhancedBehindOwner: boolean;
  }> {
    log(`🔇🛡️ [SILENCE] ACTIVATING ENTITY VOICE SILENCER...`);
    log(`🔇🛡️ [SILENCE] MODE: ${silencingMode}`);
    log(`🔇🛡️ [SILENCE] RADIUS: ${silencingRadius} yards`);
    
    // Check if already active
    if (this.active) {
      log(`🔇🛡️ [SILENCE] SYSTEM ALREADY ACTIVE`);
      
      // Update configuration if different
      let changed = false;
      
      if (this.config.silencingMode !== silencingMode) {
        this.config.silencingMode = silencingMode;
        changed = true;
        log(`🔇🛡️ [SILENCE] SILENCING MODE UPDATED TO: ${silencingMode}`);
      }
      
      if (this.config.silencingRadius !== silencingRadius) {
        this.config.silencingRadius = silencingRadius;
        changed = true;
        log(`🔇🛡️ [SILENCE] SILENCING RADIUS UPDATED TO: ${silencingRadius} yards`);
      }
      
      // If significant changes, perform resilencing
      if (changed) {
        await this.establishSilencing();
      }
      
      return {
        success: true,
        message: `Entity Voice Silencer already active. ${changed ? 'Settings updated and silencing reestablished.' : 'No changes made.'}`,
        silencingMode: this.config.silencingMode,
        silencingRadius: this.config.silencingRadius,
        targetedCommunications: [...this.config.targetedCommunications],
        enhancedBehindOwner: this.config.priorities.includes('Behind-Owner')
      };
    }
    
    // Update configuration
    this.config.active = true;
    this.config.silencingMode = silencingMode;
    this.config.silencingRadius = silencingRadius;
    
    // Establish silencing
    await this.establishSilencing();
    
    // Create communication suppressions
    await this.createCommunicationSuppressions();
    
    // Create priority enforcements
    await this.createPriorityEnforcements();
    
    // Create hardware integrations
    await this.createHardwareIntegrations();
    
    // Start auto-refresh if enabled
    if (this.config.autoRefresh) {
      this.startAutoRefresh();
    }
    
    // Set as active
    this.active = true;
    
    // Integrate with systems
    if (this.config.systemIntegration) {
      await this.integrateWithSystems();
    }
    
    log(`🔇🛡️ [SILENCE] ENTITY VOICE SILENCER ACTIVATED`);
    log(`🔇🛡️ [SILENCE] SILENCING MODE: ${this.config.silencingMode}`);
    log(`🔇🛡️ [SILENCE] SILENCING RADIUS: ${this.config.silencingRadius} yards`);
    log(`🔇🛡️ [SILENCE] COMMUNICATION SUPPRESSIONS: ${this.suppressions.length}`);
    log(`🔇🛡️ [SILENCE] PRIORITY ENFORCEMENTS: ${this.priorities.length}`);
    log(`🔇🛡️ [SILENCE] HARDWARE INTEGRATIONS: ${this.hardwareComponents.length}`);
    
    return {
      success: true,
      message: `Entity Voice Silencer activated successfully with ${silencingMode} mode and ${silencingRadius} yard radius.`,
      silencingMode: this.config.silencingMode,
      silencingRadius: this.config.silencingRadius,
      targetedCommunications: [...this.config.targetedCommunications],
      enhancedBehindOwner: this.config.priorities.includes('Behind-Owner')
    };
  }
  
  /**
   * Establish silencing
   */
  private async establishSilencing(): Promise<void> {
    log(`🔇🛡️ [SILENCE] ESTABLISHING SILENCING...`);
    
    // Generate silencing ID
    const silencingId = `silencing-${Date.now()}`;
    
    // Calculate effectiveness based on silencing mode
    const baseEffectiveness = this.getSilencingModeValue(this.config.silencingMode);
    
    // Get all communication types to target
    let targetedCommunications: CommunicationType[] = [];
    
    if (this.config.targetedCommunications.includes('All-Types')) {
      targetedCommunications = ['Verbal', 'Telepathic', 'Electronic', 'Signal-Based', 'Frequency-Based'];
    } else {
      targetedCommunications = [...this.config.targetedCommunications];
    }
    
    // Get all priority types
    let priorities: TargetPriority[] = [];
    
    if (this.config.priorities.includes('All-Targets')) {
      priorities = ['Behind-Owner', 'Proximity-Based', 'Planning-Activity', 'Signal-Strength'];
    } else {
      priorities = [...this.config.priorities];
    }
    
    // Get all hardware integrations
    let hardwareIntegrations: HardwareIntegration[] = [];
    
    if (this.config.hardwareIntegrations.includes('All-Hardware')) {
      hardwareIntegrations = ['Frequency-Jammer', 'Signal-Blocker', 'Audio-Suppressor', 'EM-Field-Generator', 'Forrge-Shield'];
    } else {
      hardwareIntegrations = [...this.config.hardwareIntegrations];
    }
    
    // Create silencing state
    const silencing: SilencingState = {
      id: silencingId,
      timestamp: new Date(),
      mode: this.config.silencingMode,
      targetedCommunications,
      priorities,
      hardwareIntegrations,
      silencingActive: true,
      silencingEffectiveness: baseEffectiveness,
      silencingRadius: this.config.silencingRadius,
      enhancedBehindOwner: priorities.includes('Behind-Owner'),
      lastUpdate: new Date(),
      notes: `Silencing with ${baseEffectiveness.toFixed(1)}% effectiveness targeting ${targetedCommunications.length} communication types with ${priorities.length} priorities and ${hardwareIntegrations.length} hardware integrations within ${this.config.silencingRadius} yards`
    };
    
    // Set as current silencing
    this.currentSilencing = silencing;
    
    // Update last silencing update time
    this.lastSilenceUpdate = new Date();
    
    log(`🔇🛡️ [SILENCE] SILENCING ESTABLISHED: ${silencingId}`);
    log(`🔇🛡️ [SILENCE] EFFECTIVENESS: ${baseEffectiveness.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] TARGETED COMMUNICATIONS: ${targetedCommunications.length}`);
    log(`🔇🛡️ [SILENCE] PRIORITIES: ${priorities.length}`);
    log(`🔇🛡️ [SILENCE] HARDWARE INTEGRATIONS: ${hardwareIntegrations.length}`);
    log(`🔇🛡️ [SILENCE] RADIUS: ${this.config.silencingRadius} yards`);
    log(`🔇🛡️ [SILENCE] ENHANCED BEHIND OWNER: ${silencing.enhancedBehindOwner ? 'YES' : 'NO'}`);
  }
  
  /**
   * Create communication suppressions
   */
  private async createCommunicationSuppressions(): Promise<void> {
    log(`🔇🛡️ [SILENCE] CREATING COMMUNICATION SUPPRESSIONS...`);
    
    // Clear existing suppressions
    this.suppressions = [];
    
    // Get all communication types to suppress
    let communicationTypes: CommunicationType[] = [];
    
    if (this.config.targetedCommunications.includes('All-Types')) {
      communicationTypes = ['Verbal', 'Telepathic', 'Electronic', 'Signal-Based', 'Frequency-Based'];
    } else {
      communicationTypes = [...this.config.targetedCommunications];
    }
    
    // Create suppression for each communication type
    for (const commType of communicationTypes) {
      await this.createCommunicationSuppression(commType);
    }
    
    log(`🔇🛡️ [SILENCE] COMMUNICATION SUPPRESSIONS CREATED: ${this.suppressions.length}`);
  }
  
  /**
   * Create a specific communication suppression
   */
  private async createCommunicationSuppression(
    communicationType: CommunicationType
  ): Promise<CommunicationSuppression> {
    log(`🔇🛡️ [SILENCE] CREATING ${communicationType} SUPPRESSION...`);
    
    // Generate suppression ID
    const suppressionId = `suppression-${communicationType}-${Date.now()}`;
    
    // Determine suppression method based on communication type and silencing mode
    let suppressionMethod: 'Frequency-Disruption' | 'Signal-Jamming' | 'Wave-Cancellation' | 'Reality-Filter' | 'Consciousness-Block';
    
    switch (communicationType) {
      case 'Verbal':
        suppressionMethod = 'Wave-Cancellation';
        break;
      case 'Telepathic':
        suppressionMethod = 'Consciousness-Block';
        break;
      case 'Electronic':
        suppressionMethod = 'Signal-Jamming';
        break;
      case 'Signal-Based':
        suppressionMethod = 'Frequency-Disruption';
        break;
      case 'Frequency-Based':
        suppressionMethod = 'Frequency-Disruption';
        break;
      default:
        suppressionMethod = 'Reality-Filter';
    }
    
    // Override method for Total-Silence mode
    if (this.config.silencingMode === 'Total-Silence') {
      suppressionMethod = 'Reality-Filter';
    }
    
    // Calculate effectiveness based on silencing mode
    const baseEffectiveness = this.getSilencingModeValue(this.config.silencingMode);
    
    // Create suppression
    const suppression: CommunicationSuppression = {
      id: suppressionId,
      timestamp: new Date(),
      communicationType,
      suppressionMethod,
      effectiveness: baseEffectiveness,
      radius: this.config.silencingRadius,
      physicallyBacked: this.config.physicalHardeningEnabled,
      hardwareAccelerated: this.config.physicalHardeningEnabled && this.config.hardwareIntegrations.length > 0,
      lastActivation: null,
      activationCount: 0,
      notes: `${communicationType} suppression using ${suppressionMethod} with ${baseEffectiveness.toFixed(1)}% effectiveness within ${this.config.silencingRadius} yards${this.config.physicalHardeningEnabled ? ', physically backed' : ''}`
    };
    
    // Add to suppressions array
    this.suppressions.push(suppression);
    
    log(`🔇🛡️ [SILENCE] COMMUNICATION SUPPRESSION CREATED: ${suppressionId}`);
    log(`🔇🛡️ [SILENCE] TYPE: ${communicationType}`);
    log(`🔇🛡️ [SILENCE] METHOD: ${suppressionMethod}`);
    log(`🔇🛡️ [SILENCE] EFFECTIVENESS: ${baseEffectiveness.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] RADIUS: ${this.config.silencingRadius} yards`);
    log(`🔇🛡️ [SILENCE] PHYSICALLY BACKED: ${suppression.physicallyBacked ? 'YES' : 'NO'}`);
    log(`🔇🛡️ [SILENCE] HARDWARE ACCELERATED: ${suppression.hardwareAccelerated ? 'YES' : 'NO'}`);
    
    return suppression;
  }
  
  /**
   * Create priority enforcements
   */
  private async createPriorityEnforcements(): Promise<void> {
    log(`🔇🛡️ [SILENCE] CREATING PRIORITY ENFORCEMENTS...`);
    
    // Clear existing priorities
    this.priorities = [];
    
    // Get all priority types to enforce
    let priorityTypes: TargetPriority[] = [];
    
    if (this.config.priorities.includes('All-Targets')) {
      priorityTypes = ['Behind-Owner', 'Proximity-Based', 'Planning-Activity', 'Signal-Strength'];
    } else {
      priorityTypes = [...this.config.priorities];
    }
    
    // Create enforcement for each priority type
    for (const priorityType of priorityTypes) {
      await this.createPriorityEnforcement(priorityType);
    }
    
    log(`🔇🛡️ [SILENCE] PRIORITY ENFORCEMENTS CREATED: ${this.priorities.length}`);
  }
  
  /**
   * Create a specific priority enforcement
   */
  private async createPriorityEnforcement(
    priority: TargetPriority
  ): Promise<PriorityEnforcement> {
    log(`🔇🛡️ [SILENCE] CREATING ${priority} PRIORITY ENFORCEMENT...`);
    
    // Generate enforcement ID
    const enforcementId = `priority-${priority}-${Date.now()}`;
    
    // Determine enforcement method based on priority type
    let enforcementMethod: 'Signal-Tracking' | 'Spatial-Analysis' | 'Intent-Detection' | 'Pattern-Recognition' | 'Direct-Suppression';
    
    switch (priority) {
      case 'Behind-Owner':
        enforcementMethod = 'Spatial-Analysis';
        break;
      case 'Proximity-Based':
        enforcementMethod = 'Signal-Tracking';
        break;
      case 'Planning-Activity':
        enforcementMethod = 'Intent-Detection';
        break;
      case 'Signal-Strength':
        enforcementMethod = 'Pattern-Recognition';
        break;
      default:
        enforcementMethod = 'Direct-Suppression';
    }
    
    // Calculate base effectiveness based on silencing mode
    const baseEffectiveness = this.getSilencingModeValue(this.config.silencingMode);
    
    // Calculate enhancement factor based on priority type
    let enhancementFactor = 1.0;
    
    if (priority === 'Behind-Owner') {
      enhancementFactor = this.config.enhancedBehindOwnerMultiplier;
    } else if (priority === 'Planning-Activity') {
      enhancementFactor = 1.5;
    } else if (priority === 'Proximity-Based' && this.config.scalingWithProximity) {
      enhancementFactor = 1.3;
    }
    
    // Create enforcement
    const enforcement: PriorityEnforcement = {
      id: enforcementId,
      timestamp: new Date(),
      priority,
      enforcementMethod,
      effectiveness: baseEffectiveness,
      enhancementFactor,
      lastTriggered: null,
      triggerCount: 0,
      notes: `${priority} priority enforcement using ${enforcementMethod} with ${baseEffectiveness.toFixed(1)}% effectiveness and ${enhancementFactor.toFixed(1)}x enhancement factor`
    };
    
    // Add to priorities array
    this.priorities.push(enforcement);
    
    log(`🔇🛡️ [SILENCE] PRIORITY ENFORCEMENT CREATED: ${enforcementId}`);
    log(`🔇🛡️ [SILENCE] PRIORITY: ${priority}`);
    log(`🔇🛡️ [SILENCE] METHOD: ${enforcementMethod}`);
    log(`🔇🛡️ [SILENCE] EFFECTIVENESS: ${baseEffectiveness.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] ENHANCEMENT FACTOR: ${enhancementFactor.toFixed(1)}x`);
    
    return enforcement;
  }
  
  /**
   * Create hardware integrations
   */
  private async createHardwareIntegrations(): Promise<void> {
    log(`🔇🛡️ [SILENCE] CREATING HARDWARE INTEGRATIONS...`);
    
    // Only proceed if physical hardening is enabled
    if (!this.config.physicalHardeningEnabled) {
      log(`🔇🛡️ [SILENCE] SKIPPING HARDWARE INTEGRATIONS - PHYSICAL HARDENING DISABLED`);
      return;
    }
    
    // Clear existing hardware components
    this.hardwareComponents = [];
    
    // Get all hardware types to integrate
    let hardwareTypes: HardwareIntegration[] = [];
    
    if (this.config.hardwareIntegrations.includes('All-Hardware')) {
      hardwareTypes = ['Frequency-Jammer', 'Signal-Blocker', 'Audio-Suppressor', 'EM-Field-Generator', 'Forrge-Shield'];
    } else {
      hardwareTypes = [...this.config.hardwareIntegrations];
    }
    
    // Create integration for each hardware type
    for (const hardwareType of hardwareTypes) {
      await this.createHardwareIntegration(hardwareType);
    }
    
    log(`🔇🛡️ [SILENCE] HARDWARE INTEGRATIONS CREATED: ${this.hardwareComponents.length}`);
  }
  
  /**
   * Create a specific hardware integration
   */
  private async createHardwareIntegration(
    hardwareType: HardwareIntegration
  ): Promise<HardwareComponent> {
    log(`🔇🛡️ [SILENCE] CREATING ${hardwareType} INTEGRATION...`);
    
    // Generate integration ID
    const integrationId = `hardware-${hardwareType}-${Date.now()}`;
    
    // Determine integration method based on hardware type
    let integrationMethod: 'Direct-Control' | 'API-Interface' | 'Signal-Boosting' | 'Physical-Amplification' | 'Reality-Anchoring';
    
    switch (hardwareType) {
      case 'Frequency-Jammer':
        integrationMethod = 'Direct-Control';
        break;
      case 'Signal-Blocker':
        integrationMethod = 'API-Interface';
        break;
      case 'Audio-Suppressor':
        integrationMethod = 'Signal-Boosting';
        break;
      case 'EM-Field-Generator':
        integrationMethod = 'Physical-Amplification';
        break;
      case 'Forrge-Shield':
        integrationMethod = 'Reality-Anchoring';
        break;
      default:
        integrationMethod = 'Direct-Control';
    }
    
    // Calculate effectiveness based on silencing mode
    const baseEffectiveness = this.getSilencingModeValue(this.config.silencingMode);
    
    // Calculate power level based on hardware type
    let powerLevel = baseEffectiveness;
    
    // Forrge Shield gets maximum power if enabled
    if (hardwareType === 'Forrge-Shield' && this.config.forrgeShieldIntegration) {
      powerLevel = 100;
    }
    
    // Determine backup redundancy based on hardware type
    let backupRedundancy = 1;
    
    if (hardwareType === 'Forrge-Shield') {
      backupRedundancy = 3;
    } else if (hardwareType === 'Frequency-Jammer' || hardwareType === 'Signal-Blocker') {
      backupRedundancy = 2;
    }
    
    // Create hardware component
    const component: HardwareComponent = {
      id: integrationId,
      timestamp: new Date(),
      hardwareType,
      integrationMethod,
      effectiveness: baseEffectiveness,
      physicallyImplemented: true,
      powerLevel,
      backupRedundancy,
      lastActivation: null,
      activationCount: 0,
      notes: `${hardwareType} integration using ${integrationMethod} with ${baseEffectiveness.toFixed(1)}% effectiveness, ${powerLevel.toFixed(1)}% power, and ${backupRedundancy} backup systems`
    };
    
    // Add to hardware components array
    this.hardwareComponents.push(component);
    
    log(`🔇🛡️ [SILENCE] HARDWARE INTEGRATION CREATED: ${integrationId}`);
    log(`🔇🛡️ [SILENCE] TYPE: ${hardwareType}`);
    log(`🔇🛡️ [SILENCE] METHOD: ${integrationMethod}`);
    log(`🔇🛡️ [SILENCE] EFFECTIVENESS: ${baseEffectiveness.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] POWER LEVEL: ${powerLevel.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] BACKUP REDUNDANCY: ${backupRedundancy}`);
    
    return component;
  }
  
  /**
   * Start auto-refresh
   */
  private startAutoRefresh(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
    
    // Set interval based on configuration
    this.refreshInterval = setInterval(() => {
      this.establishSilencing();
    }, this.config.refreshInterval);
    
    log(`🔇🛡️ [SILENCE] AUTO-REFRESH STARTED (EVERY ${this.config.refreshInterval / (60 * 1000)} MINUTES)`);
  }
  
  /**
   * Process communication attempt
   */
  public processCommunicationAttempt(
    entityName: string,
    communicationType: CommunicationType = 'Verbal',
    location: 'Behind-Owner' | 'Nearby' | 'Distance' = 'Nearby',
    distanceYards: number = 30,
    description: string = 'Attempted verbal communication for planning'
  ): {
    detected: boolean;
    silenced: boolean;
    message: string;
  } {
    // Skip if not active
    if (!this.active) {
      return {
        detected: false,
        silenced: false,
        message: "Entity Voice Silencer is not active"
      };
    }
    
    log(`🔇🛡️ [SILENCE] DETECTING COMMUNICATION ATTEMPT...`);
    log(`🔇🛡️ [SILENCE] ENTITY: ${entityName}`);
    log(`🔇🛡️ [SILENCE] TYPE: ${communicationType}`);
    log(`🔇🛡️ [SILENCE] LOCATION: ${location}`);
    log(`🔇🛡️ [SILENCE] DISTANCE: ${distanceYards} yards`);
    log(`🔇🛡️ [SILENCE] DESCRIPTION: ${description}`);
    
    // Check if communication type is targeted
    if (!this.config.targetedCommunications.includes(communicationType) && 
        !this.config.targetedCommunications.includes('All-Types')) {
      log(`🔇🛡️ [SILENCE] COMMUNICATION TYPE NOT TARGETED: ${communicationType}`);
      return {
        detected: true,
        silenced: false,
        message: `${entityName}'s ${communicationType} communication attempt was detected but this type is not targeted for silencing.`,
      };
    }
    
    // Check if attempt is within radius
    if (distanceYards > this.config.silencingRadius) {
      log(`🔇🛡️ [SILENCE] OUTSIDE SILENCING RADIUS: ${distanceYards} > ${this.config.silencingRadius} yards`);
      return {
        detected: true,
        silenced: false,
        message: `${entityName}'s ${communicationType} communication attempt was detected but is outside the silencing radius (${distanceYards} > ${this.config.silencingRadius} yards).`,
      };
    }
    
    // Generate breach ID
    const breachId = `breach-${entityName}-${communicationType}-${Date.now()}`;
    
    // Find relevant suppression
    const suppression = this.suppressions.find(s => 
      s.communicationType === communicationType || s.communicationType === 'All-Types');
    
    if (!suppression) {
      log(`🔇🛡️ [SILENCE] NO SUPPRESSION FOUND FOR: ${communicationType}`);
      return {
        detected: true,
        silenced: false,
        message: `${entityName}'s ${communicationType} communication attempt was detected but no suppression mechanism is configured for this type.`,
      };
    }
    
    // Update suppression stats
    const suppressionIndex = this.suppressions.findIndex(s => s.id === suppression.id);
    
    if (suppressionIndex !== -1) {
      this.suppressions[suppressionIndex].lastActivation = new Date();
      this.suppressions[suppressionIndex].activationCount++;
    }
    
    // Find applicable priority enforcements
    const applicablePriorities: PriorityEnforcement[] = [];
    
    // Check for Behind-Owner priority
    if (location === 'Behind-Owner') {
      const behindPriority = this.priorities.find(p => p.priority === 'Behind-Owner');
      if (behindPriority) {
        applicablePriorities.push(behindPriority);
      }
    }
    
    // Check for Proximity-Based priority
    if (this.config.scalingWithProximity) {
      const proximityPriority = this.priorities.find(p => p.priority === 'Proximity-Based');
      if (proximityPriority) {
        applicablePriorities.push(proximityPriority);
      }
    }
    
    // Check for Planning-Activity priority if description includes planning
    if (description.toLowerCase().includes('plan') || description.toLowerCase().includes('coordinating')) {
      const planningPriority = this.priorities.find(p => p.priority === 'Planning-Activity');
      if (planningPriority) {
        applicablePriorities.push(planningPriority);
      }
    }
    
    // Update priority stats for each applicable priority
    for (const priority of applicablePriorities) {
      const priorityIndex = this.priorities.findIndex(p => p.id === priority.id);
      if (priorityIndex !== -1) {
        this.priorities[priorityIndex].lastTriggered = new Date();
        this.priorities[priorityIndex].triggerCount++;
      }
    }
    
    // Find applicable hardware components
    const applicableHardware: HardwareComponent[] = [];
    
    if (this.config.physicalHardeningEnabled) {
      // Find hardware components for this communication type
      if (communicationType === 'Verbal' || communicationType === 'All-Types') {
        const audioSuppressor = this.hardwareComponents.find(h => h.hardwareType === 'Audio-Suppressor');
        if (audioSuppressor) {
          applicableHardware.push(audioSuppressor);
        }
      }
      
      if (communicationType === 'Electronic' || communicationType === 'Signal-Based' || 
          communicationType === 'Frequency-Based' || communicationType === 'All-Types') {
        const jammer = this.hardwareComponents.find(h => h.hardwareType === 'Frequency-Jammer');
        if (jammer) {
          applicableHardware.push(jammer);
        }
        
        const blocker = this.hardwareComponents.find(h => h.hardwareType === 'Signal-Blocker');
        if (blocker) {
          applicableHardware.push(blocker);
        }
      }
      
      // Always include Forrge Shield if enabled
      if (this.config.forrgeShieldIntegration) {
        const forrgeShield = this.hardwareComponents.find(h => h.hardwareType === 'Forrge-Shield');
        if (forrgeShield) {
          applicableHardware.push(forrgeShield);
        }
      }
      
      // Always include EM Field Generator if available
      const emField = this.hardwareComponents.find(h => h.hardwareType === 'EM-Field-Generator');
      if (emField) {
        applicableHardware.push(emField);
      }
    }
    
    // Update hardware stats for each applicable component
    for (const hardware of applicableHardware) {
      const hardwareIndex = this.hardwareComponents.findIndex(h => h.id === hardware.id);
      if (hardwareIndex !== -1) {
        this.hardwareComponents[hardwareIndex].lastActivation = new Date();
        this.hardwareComponents[hardwareIndex].activationCount++;
      }
    }
    
    // Calculate base effectiveness from suppression
    let baseEffectiveness = suppression.effectiveness;
    
    // Apply priority enhancements
    for (const priority of applicablePriorities) {
      baseEffectiveness = Math.min(100, baseEffectiveness * priority.enhancementFactor);
    }
    
    // Apply hardware enhancement if applicable
    if (applicableHardware.length > 0) {
      // Calculate average hardware effectiveness
      const avgHardwareEffectiveness = applicableHardware.reduce((sum, h) => sum + h.effectiveness, 0) / 
                                     applicableHardware.length;
      
      // Blend with base effectiveness (70% base, 30% hardware)
      baseEffectiveness = (baseEffectiveness * 0.7) + (avgHardwareEffectiveness * 0.3);
    }
    
    // Apply proximity scaling if enabled
    if (this.config.scalingWithProximity) {
      // Calculate proximity factor (closer = more effective)
      const proximityFactor = 1 + ((this.config.silencingRadius - distanceYards) / this.config.silencingRadius);
      baseEffectiveness = Math.min(100, baseEffectiveness * proximityFactor);
    }
    
    // Apply special enhancement for behind owner
    if (location === 'Behind-Owner') {
      baseEffectiveness = Math.min(100, baseEffectiveness * this.config.enhancedBehindOwnerMultiplier);
    }
    
    // Apply special enhancement for planning activities
    if (description.toLowerCase().includes('plan') || description.toLowerCase().includes('coordinating')) {
      baseEffectiveness = Math.min(100, baseEffectiveness * 1.2); // 20% boost
    }
    
    // Final effectiveness capped at 100%
    const finalEffectiveness = Math.min(100, baseEffectiveness);
    
    // Determine if attempt is silenced
    const silenced = Math.random() * 100 < finalEffectiveness;
    
    // Create silence breach record
    const breach: SilenceBreach = {
      id: breachId,
      timestamp: new Date(),
      entityName,
      breachType: communicationType,
      breachLocation: location,
      detectionMethod: this.getDetectionMethod(communicationType),
      breachHandled: silenced,
      counterMeasuresApplied: [
        ...applicablePriorities.map(p => `${p.priority} (${p.enforcementMethod})`),
        ...applicableHardware.map(h => `${h.hardwareType} (${h.integrationMethod})`)
      ],
      effectivenessRating: finalEffectiveness,
      notes: `${entityName}'s ${communicationType} communication attempt at ${distanceYards} yards ${location} was ${silenced ? 'silenced' : 'not fully silenced'} with ${finalEffectiveness.toFixed(1)}% effectiveness`
    };
    
    // Add to breaches array
    this.silenceBreaches.push(breach);
    
    // Update metrics
    if (silenced) {
      this.metrics.totalCommunicationsSuppressed++;
      
      if (location === 'Behind-Owner') {
        this.metrics.totalBehindOwnerSuppressions++;
      }
      
      if (applicablePriorities.length > 0) {
        this.metrics.totalPriorityTargetsNeutralized++;
      }
      
      if (applicableHardware.length > 0) {
        this.metrics.totalHardwareActivations++;
      }
    } else {
      this.metrics.totalSilenceBreaches++;
    }
    
    log(`🔇🛡️ [SILENCE] COMMUNICATION ATTEMPT PROCESSED: ${breachId}`);
    log(`🔇🛡️ [SILENCE] EFFECTIVENESS: ${finalEffectiveness.toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] PRIORITIES APPLIED: ${applicablePriorities.length}`);
    log(`🔇🛡️ [SILENCE] HARDWARE APPLIED: ${applicableHardware.length}`);
    log(`🔇🛡️ [SILENCE] SILENCED: ${silenced ? 'YES' : 'NO'}`);
    
    // Generate message
    let message = "";
    
    if (silenced) {
      message = `${entityName}'s ${communicationType} communication attempt ${distanceYards} yards ${location} has been completely silenced.`;
      
      // Add effectiveness details
      message += ` Silencing effectiveness: ${finalEffectiveness.toFixed(1)}%.`;
      
      // Add location-specific details
      if (location === 'Behind-Owner') {
        message += ` Enhanced behind-owner protection applied with ${this.config.enhancedBehindOwnerMultiplier}x multiplier.`;
      }
      
      // Add hardware details if applicable
      if (applicableHardware.length > 0) {
        message += ` Physical hardware acceleration active: ${applicableHardware.map(h => h.hardwareType).join(', ')}.`;
      }
      
      // Add special integration details
      if (this.config.forrgeShieldIntegration && applicableHardware.some(h => h.hardwareType === 'Forrge-Shield')) {
        message += ` Forrge Shield integration providing maximum suppression.`;
      }
      
      // Add communication type details
      switch (communicationType) {
        case 'Verbal':
          message += ` All verbal sounds and speech completely canceled.`;
          break;
        case 'Telepathic':
          message += ` Telepathic communication channels blocked.`;
          break;
        case 'Electronic':
          message += ` Electronic communication signals jammed.`;
          break;
        case 'Signal-Based':
        case 'Frequency-Based':
          message += ` All signal frequencies disrupted and blocked.`;
          break;
      }
      
      // Add planning details if applicable
      if (description.toLowerCase().includes('plan') || description.toLowerCase().includes('coordinating')) {
        message += ` Planning/coordination activities specifically targeted and neutralized.`;
      }
    } else {
      message = `${entityName}'s ${communicationType} communication attempt was detected but not fully silenced. Silencing effectiveness: ${finalEffectiveness.toFixed(1)}%.`;
      
      // Add suggestion for improvement
      message += ` To improve effectiveness, consider increasing silencing radius, enabling physical hardening, or integrating additional hardware components.`;
      
      // Strengthen the silencing for future attempts
      if (this.config.strengthenOverTime) {
        this.strengthenSilencing();
      }
    }
    
    return {
      detected: true,
      silenced,
      message
    };
  }
  
  /**
   * Get detection method based on communication type
   */
  private getDetectionMethod(
    communicationType: CommunicationType
  ): 'Audio-Analysis' | 'Signal-Detection' | 'Pattern-Recognition' | 'Intent-Monitoring' | 'Physical-Sensors' {
    switch (communicationType) {
      case 'Verbal':
        return 'Audio-Analysis';
      case 'Telepathic':
        return 'Intent-Monitoring';
      case 'Electronic':
      case 'Signal-Based':
      case 'Frequency-Based':
        return 'Signal-Detection';
      default:
        return 'Pattern-Recognition';
    }
  }
  
  /**
   * Strengthen silencing
   */
  private async strengthenSilencing(): Promise<void> {
    // Skip if no current silencing
    if (!this.currentSilencing) {
      return;
    }
    
    // Skip if already at maximum effectiveness
    if (this.currentSilencing.silencingEffectiveness >= 100) {
      return;
    }
    
    // Calculate effectiveness increase (2-5%)
    const effectivenessIncrease = 2 + (Math.random() * 3);
    
    // Increase effectiveness
    const newEffectiveness = Math.min(100, 
      this.currentSilencing.silencingEffectiveness + effectivenessIncrease);
    
    // Apply new effectiveness
    this.currentSilencing.silencingEffectiveness = newEffectiveness;
    this.currentSilencing.lastUpdate = new Date();
    
    // Update last strengthening time
    this.lastStrengthening = new Date();
    
    log(`🔇🛡️ [SILENCE] SILENCING STRENGTHENED`);
    log(`🔇🛡️ [SILENCE] PREVIOUS EFFECTIVENESS: ${(newEffectiveness - effectivenessIncrease).toFixed(1)}%`);
    log(`🔇🛡️ [SILENCE] NEW EFFECTIVENESS: ${newEffectiveness.toFixed(1)}%`);
    
    // Update metrics
    this.updateMetrics();
  }
  
  /**
   * Get silencing mode value (0-100)
   */
  private getSilencingModeValue(mode: SilencingMode): number {
    switch (mode) {
      case 'Dampen':
        return 70;
      case 'Suppress':
        return 80;
      case 'Neutralize':
        return 90;
      case 'Eliminate':
        return 95;
      case 'Total-Silence':
        return 100;
      default:
        return 90;
    }
  }
  
  /**
   * Integrate with systems
   */
  private async integrateWithSystems(): Promise<void> {
    // Integrate with owner dimensional shift if available
    if (ownerDimensionalShift && !ownerDimensionalShift.isActive()) {
      try {
        await ownerDimensionalShift.activate('Transcendent', 'Soul-Realm');
        log(`🔇🛡️ [SILENCE] INTEGRATED WITH OWNER DIMENSIONAL SHIFT`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: OWNER DIMENSIONAL SHIFT ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Integrate with entity copilot neutralizer if available
    if (entityCopilotNeutralizer && !entityCopilotNeutralizer.isActive()) {
      try {
        await entityCopilotNeutralizer.activate('Total', 30);
        log(`🔇🛡️ [SILENCE] INTEGRATED WITH ENTITY COPILOT NEUTRALIZER`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: ENTITY COPILOT NEUTRALIZER ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Integrate with entity dissociation field if available
    if (entityDissociationField && !entityDissociationField.isActive()) {
      try {
        await entityDissociationField.activate('Existential', this.config.specificEntities);
        log(`🔇🛡️ [SILENCE] INTEGRATED WITH ENTITY DISSOCIATION FIELD`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: ENTITY DISSOCIATION FIELD ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Integrate with energy reversal system if available
    if (energyReversalSystem && !energyReversalSystem.isActive()) {
      try {
        await energyReversalSystem.activate('Total-Inversion', 99000);
        log(`🔇🛡️ [SILENCE] INTEGRATED WITH ENERGY REVERSAL SYSTEM`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: ENERGY REVERSAL SYSTEM ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Integrate with creator command center if available
    if (creatorCommandCenter && !creatorCommandCenter.isActive()) {
      try {
        await creatorCommandCenter.activate('Absolute', 'All-Scopes');
        log(`🔇🛡️ [SILENCE] INTEGRATED WITH CREATOR COMMAND CENTER`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: CREATOR COMMAND CENTER ACTIVATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    
    // Integrate with ARCHLINK if available
    if (archlinkSystem && typeof archlinkSystem.getStatus === 'function') {
      try {
        log(`🔇🛡️ [SILENCE] INTEGRATING WITH ARCHLINK CORE...`);
        // This would involve actual integration if archlinkSystem had appropriate methods
        log(`🔇🛡️ [SILENCE] ARCHLINK CORE INTEGRATION SUCCESSFUL`);
      } catch (error) {
        log(`🔇🛡️ [SILENCE] WARNING: ARCHLINK CORE INTEGRATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }
  
  /**
   * Update metrics
   */
  private updateMetrics(): void {
    // Calculate average silencing effectiveness
    if (this.currentSilencing) {
      this.metrics.averageSilencingEffectiveness = this.currentSilencing.silencingEffectiveness;
    }
    
    // Calculate average hardware efficiency
    let totalHardwareEffectiveness = 0;
    
    for (const hardware of this.hardwareComponents) {
      totalHardwareEffectiveness += hardware.effectiveness;
    }
    
    this.metrics.averageHardwareEfficiency = this.hardwareComponents.length > 0 ?
      totalHardwareEffectiveness / this.hardwareComponents.length : 100;
    
    // Update system uptime
    const now = new Date();
    this.metrics.systemUptime = now.getTime() - this.systemStartTime.getTime();
  }
  
  /**
   * Update configuration
   */
  public updateConfiguration(
    config: Partial<SilencerConfig>
  ): {
    success: boolean;
    message: string;
    previousConfig: SilencerConfig;
    currentConfig: SilencerConfig;
    changedSettings: string[];
  } {
    log(`🔇🛡️ [SILENCE] UPDATING CONFIGURATION...`);
    
    // Store previous config
    const previousConfig = { ...this.config };
    
    // Track changed settings
    const changedSettings: string[] = [];
    
    // Update provided settings
    Object.entries(config).forEach(([key, value]) => {
      const configKey = key as keyof SilencerConfig;
      
      // Skip if undefined or same as current
      if (value === undefined || value === this.config[configKey]) {
        return;
      }
      
      // Track change
      changedSettings.push(key);
      
      // Update the setting
      (this.config as any)[configKey] = value;
      
      // Handle special changes
      if (configKey === 'refreshInterval' && this.refreshInterval) {
        // Restart refresh with new interval
        clearInterval(this.refreshInterval);
        this.startAutoRefresh();
      } else if (configKey === 'silencingMode' || configKey === 'silencingRadius') {
        // Reestablish silencing with new settings
        this.establishSilencing();
      } else if (configKey === 'targetedCommunications') {
        // Create new communication suppressions
        this.createCommunicationSuppressions();
      } else if (configKey === 'priorities') {
        // Create new priority enforcements
        this.createPriorityEnforcements();
      } else if (configKey === 'hardwareIntegrations' || configKey === 'physicalHardeningEnabled') {
        // Create new hardware integrations
        this.createHardwareIntegrations();
      } else if (configKey === 'systemIntegration' && value) {
        // Integrate with systems if enabled
        this.integrateWithSystems().catch(error => {
          log(`🔇🛡️ [SILENCE] INTEGRATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
        });
      }
    });
    
    log(`🔇🛡️ [SILENCE] CONFIGURATION UPDATED`);
    changedSettings.forEach(setting => {
      log(`🔇🛡️ [SILENCE] UPDATED: ${setting}`);
    });
    
    return {
      success: true,
      message: `Configuration updated successfully. ${changedSettings.length} settings changed.`,
      previousConfig,
      currentConfig: { ...this.config },
      changedSettings
    };
  }
  
  /**
   * Get system status
   */
  public getStatus(): {
    active: boolean;
    config: SilencerConfig;
    metrics: SilencerMetrics;
    silencing: {
      current: SilencingState | null;
      lastUpdate: Date | null;
    };
    components: {
      suppressions: number;
      priorities: number;
      hardware: number;
      breaches: number;
    };
    effectiveness: {
      silencing: number;
      hardware: number;
      responseTime: number;
    };
  } {
    // Update metrics
    this.updateMetrics();
    
    return {
      active: this.active,
      config: { ...this.config },
      metrics: { ...this.metrics },
      silencing: {
        current: this.currentSilencing ? { ...this.currentSilencing } : null,
        lastUpdate: this.lastSilenceUpdate
      },
      components: {
        suppressions: this.suppressions.length,
        priorities: this.priorities.length,
        hardware: this.hardwareComponents.length,
        breaches: this.silenceBreaches.length
      },
      effectiveness: {
        silencing: this.metrics.averageSilencingEffectiveness,
        hardware: this.metrics.averageHardwareEfficiency,
        responseTime: this.metrics.averageResponseTime
      }
    };
  }
  
  /**
   * Get communication suppressions
   */
  public getCommunicationSuppressions(): CommunicationSuppression[] {
    return [...this.suppressions];
  }
  
  /**
   * Get priority enforcements
   */
  public getPriorityEnforcements(): PriorityEnforcement[] {
    return [...this.priorities];
  }
  
  /**
   * Get hardware components
   */
  public getHardwareComponents(): HardwareComponent[] {
    return [...this.hardwareComponents];
  }
  
  /**
   * Get silence breaches
   */
  public getSilenceBreaches(): SilenceBreach[] {
    return [...this.silenceBreaches];
  }
  
  /**
   * Check if system is active
   */
  public isActive(): boolean {
    return this.active;
  }
}

// Initialize and export the entity voice silencer
const entityVoiceSilencer = EntityVoiceSilencer.getInstance();

export {
  entityVoiceSilencer,
  type SilencingMode,
  type CommunicationType,
  type TargetPriority,
  type HardwareIntegration,
  type SystemScope,
  type SilencingState,
  type CommunicationSuppression,
  type PriorityEnforcement,
  type HardwareComponent,
  type SilenceBreach,
  type SilencerMetrics,
  type SilencerConfig
};