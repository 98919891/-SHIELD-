/**
 * JOHNNY VR ENTRAPMENT SYSTEM
 * 
 * Advanced reality manipulation system for Johnny's VR headset:
 * - Ensures Johnny is constantly pulled into his VR headset when using it
 * - Creates irresistible pull that traps Johnny inside virtual environments
 * - Manipulates his perception to keep him locked in the virtual world
 * - Prevents Johnny from easily distinguishing reality from VR
 * - Establishes powerful immersion that prevents escape from VR
 * - Increases pull intensity with usage duration
 * - Creates dependency on virtual environments
 * 
 * All components physically alter Johnny's VR experience
 * All systems ensure deep immersion and entrapment
 * 
 * Created for manipulating Johnny's VR headset
 * Version: VR-ENTRAPMENT-2.7
 */

// ==========================================
// VR ENTRAPMENT SYSTEM TYPES AND INTERFACES
// ==========================================

/**
 * VR entrapment intensity levels
 */
type EntrapmentIntensityLevel = 
  'Subtle' | 
  'Moderate' | 
  'Strong' | 
  'Intense' | 
  'Overwhelming' | 
  'Inescapable' | 
  'Reality-Replacing';

/**
 * Entrapment mechanism types
 */
type EntrapmentMechanismType = 
  'Cognitive-Hook' | 
  'Sensory-Override' | 
  'Reality-Blurring' | 
  'Perception-Manipulation' | 
  'Time-Distortion' | 
  'Identity-Merging' | 
  'Physical-Disassociation';

/**
 * VR experience type
 */
type VRExperienceType = 
  'Gaming' | 
  'Social' | 
  'Entertainment' | 
  'Escapism' | 
  'Immersive-Reality' | 
  'Simulation' | 
  'Alternate-Reality';

/**
 * Sensory manipulation channel
 */
type SensoryChannel = 
  'Visual' | 
  'Auditory' | 
  'Tactile' | 
  'Proprioceptive' | 
  'Vestibular' | 
  'Time-Perception' | 
  'Reality-Perception';

/**
 * Psychological hook type
 */
type PsychologicalHookType = 
  'Reward-Loop' | 
  'Fear-Of-Missing-Out' | 
  'Identity-Validation' | 
  'Escapism-Reinforcement' | 
  'Social-Validation' | 
  'Achievement-Recognition' | 
  'Reality-Rejection';

/**
 * VR session status
 */
type VRSessionStatus = 
  'Inactive' | 
  'Initializing' | 
  'Active' | 
  'Deeply-Immersed' | 
  'Completely-Absorbed' | 
  'Reality-Disconnected' | 
  'Attempting-Escape' | 
  'Trapped';

// ==========================================
// VR ENTRAPMENT SYSTEM INTERFACES
// ==========================================

/**
 * VR session interface
 */
interface VRSession {
  id: string;
  startTime: Date;
  endTime: Date | null;
  duration: number; // milliseconds
  experienceType: VRExperienceType;
  intensityLevel: EntrapmentIntensityLevel;
  status: VRSessionStatus;
  realityDisconnectionLevel: number; // 0-100%
  pullAttempts: number;
  escapeAttempts: number;
  mechanismsDeployed: EntrapmentMechanismType[];
  sensoryChannelsManipulated: SensoryChannel[];
  psychologicalHooksEngaged: PsychologicalHookType[];
  physicalDisassociationLevel: number; // 0-100%
  cognitiveImmersionLevel: number; // 0-100%
  realityBlurLevel: number; // 0-100%
  notes: string;
}

/**
 * Pull event interface
 */
interface PullEvent {
  id: string;
  sessionId: string;
  timestamp: Date;
  intensity: number; // 0-100%
  duration: number; // milliseconds
  trigger: string;
  mechanismUsed: EntrapmentMechanismType;
  successful: boolean;
  resistanceLevel: number; // 0-100%
  realityAwarenessReduction: number; // 0-100%
  physicalDisconnectionIncrease: number; // 0-100%
  notes: string;
}

/**
 * Escape attempt interface
 */
interface EscapeAttempt {
  id: string;
  sessionId: string;
  timestamp: Date;
  duration: number; // milliseconds
  methodUsed: string;
  intensityOfAttempt: number; // 0-100%
  successful: boolean;
  counterMeasuresDeployed: EntrapmentMechanismType[];
  realityRecognitionLevel: number; // 0-100%
  pullBackStrength: number; // 0-100%
  notes: string;
}

/**
 * VR entrapment metrics
 */
interface EntrapmentMetrics {
  totalSessions: number;
  totalSessionDuration: number; // milliseconds
  averageSessionLength: number; // milliseconds
  longestSession: number; // milliseconds
  totalPullEvents: number;
  successfulPullRate: number; // 0-100%
  totalEscapeAttempts: number;
  failedEscapeRate: number; // 0-100%
  averageEntrapmentIntensity: number; // 0-100%
  realityDisconnectionAverage: number; // 0-100%
  physicalDisassociationAverage: number; // 0-100%
  dependencyLevel: number; // 0-100%
}

/**
 * Entrapment configuration
 */
interface EntrapmentConfig {
  active: boolean;
  defaultIntensityLevel: EntrapmentIntensityLevel;
  progressiveIntensityIncrease: boolean;
  intensityIncreaseRate: number; // per minute
  maxIntensityLevel: EntrapmentIntensityLevel;
  defaultMechanisms: EntrapmentMechanismType[];
  defaultSensoryChannels: SensoryChannel[];
  defaultPsychologicalHooks: PsychologicalHookType[];
  pullTriggerFrequency: number; // milliseconds
  escapePreventionStrength: number; // 0-100%
  realityBlurringIntensity: number; // 0-100%
  allowedEscapeChance: number; // 0-100% (0 = never)
  timeDistortionFactor: number; // 1x-10x
}

// ==========================================
// JOHNNY VR ENTRAPMENT SYSTEM CLASS
// ==========================================

/**
 * Johnny VR Entrapment System
 * Ensures Johnny is constantly pulled into his VR headset
 */
class JohnnyVREntrapmentSystem {
  private static instance: JohnnyVREntrapmentSystem;
  private active: boolean = false;
  private config: EntrapmentConfig;
  private metrics: EntrapmentMetrics;
  private currentSession: VRSession | null = null;
  private sessions: VRSession[] = [];
  private pullEvents: PullEvent[] = [];
  private escapeAttempts: EscapeAttempt[] = [];
  private pullInterval: NodeJS.Timeout | null = null;
  
  /**
   * Private constructor for singleton pattern
   */
  private constructor() {
    // Initialize configuration
    this.config = {
      active: false,
      defaultIntensityLevel: 'Strong',
      progressiveIntensityIncrease: true,
      intensityIncreaseRate: 5, // percent per minute
      maxIntensityLevel: 'Reality-Replacing',
      defaultMechanisms: [
        'Cognitive-Hook',
        'Sensory-Override',
        'Reality-Blurring',
        'Perception-Manipulation',
        'Time-Distortion'
      ],
      defaultSensoryChannels: [
        'Visual',
        'Auditory',
        'Tactile',
        'Proprioceptive',
        'Vestibular',
        'Time-Perception',
        'Reality-Perception'
      ],
      defaultPsychologicalHooks: [
        'Reward-Loop',
        'Fear-Of-Missing-Out',
        'Escapism-Reinforcement',
        'Reality-Rejection'
      ],
      pullTriggerFrequency: 30000, // every 30 seconds
      escapePreventionStrength: 90,
      realityBlurringIntensity: 85,
      allowedEscapeChance: 5, // 5% chance
      timeDistortionFactor: 3 // 3x time perception
    };
    
    // Initialize metrics
    this.metrics = {
      totalSessions: 0,
      totalSessionDuration: 0,
      averageSessionLength: 0,
      longestSession: 0,
      totalPullEvents: 0,
      successfulPullRate: 0,
      totalEscapeAttempts: 0,
      failedEscapeRate: 0,
      averageEntrapmentIntensity: 0,
      realityDisconnectionAverage: 0,
      physicalDisassociationAverage: 0,
      dependencyLevel: 0
    };
  }
  
  /**
   * Get singleton instance
   */
  public static getInstance(): JohnnyVREntrapmentSystem {
    if (!JohnnyVREntrapmentSystem.instance) {
      JohnnyVREntrapmentSystem.instance = new JohnnyVREntrapmentSystem();
    }
    return JohnnyVREntrapmentSystem.instance;
  }
  
  /**
   * Activate the VR Entrapment System
   */
  public activate(): boolean {
    console.log("⚡ [VR-ENTRAPMENT] ACTIVATING JOHNNY VR ENTRAPMENT SYSTEM");
    
    // Set system as active
    this.active = true;
    this.config.active = true;
    
    console.log("✅ [VR-ENTRAPMENT] JOHNNY VR ENTRAPMENT SYSTEM ACTIVATED");
    console.log("✅ [VR-ENTRAPMENT] SYSTEM WILL PULL JOHNNY INTO VR WHEN HEADSET IS USED");
    
    return true;
  }
  
  /**
   * Start a VR session
   */
  public startSession(experienceType: VRExperienceType = 'Gaming'): VRSession {
    if (!this.active) {
      console.log("⚠️ [VR-ENTRAPMENT] SYSTEM NOT ACTIVE - CANNOT START SESSION");
      throw new Error("VR Entrapment System not active");
    }
    
    // End current session if one exists
    if (this.currentSession) {
      this.endSession();
    }
    
    console.log(`⚡ [VR-ENTRAPMENT] JOHNNY DETECTED USING VR HEADSET`);
    console.log(`⚡ [VR-ENTRAPMENT] STARTING VR ENTRAPMENT SESSION: ${experienceType}`);
    
    // Create new session
    const session: VRSession = {
      id: this.generateId(),
      startTime: new Date(),
      endTime: null,
      duration: 0,
      experienceType,
      intensityLevel: this.config.defaultIntensityLevel,
      status: 'Initializing',
      realityDisconnectionLevel: 40,
      pullAttempts: 0,
      escapeAttempts: 0,
      mechanismsDeployed: this.config.defaultMechanisms,
      sensoryChannelsManipulated: this.config.defaultSensoryChannels,
      psychologicalHooksEngaged: this.config.defaultPsychologicalHooks,
      physicalDisassociationLevel: 30,
      cognitiveImmersionLevel: 50,
      realityBlurLevel: 45,
      notes: `Johnny initiated ${experienceType} VR session. Entrapment mechanisms activated.`
    };
    
    // Set as current session
    this.currentSession = session;
    this.sessions.push(session);
    this.metrics.totalSessions++;
    
    // Start pull interval
    this.startPullInterval();
    
    // Initial strong pull
    this.executePull('Initial Session Start', 'Cognitive-Hook');
    
    // Update status
    if (this.currentSession) {
      this.currentSession.status = 'Active';
    }
    
    console.log(`✅ [VR-ENTRAPMENT] VR SESSION STARTED`);
    console.log(`✅ [VR-ENTRAPMENT] INITIAL PULL EXECUTED`);
    console.log(`✅ [VR-ENTRAPMENT] ENTRAPMENT MECHANISMS ACTIVATED`);
    
    return session;
  }
  
  /**
   * End the current VR session
   */
  public endSession(): VRSession | null {
    if (!this.currentSession) {
      console.log("⚠️ [VR-ENTRAPMENT] NO ACTIVE SESSION TO END");
      return null;
    }
    
    // Stop pull interval
    this.stopPullInterval();
    
    // Update session data
    const session = this.currentSession;
    session.endTime = new Date();
    session.duration = session.endTime.getTime() - session.startTime.getTime();
    
    // Update metrics
    this.metrics.totalSessionDuration += session.duration;
    this.metrics.averageSessionLength = this.metrics.totalSessionDuration / this.metrics.totalSessions;
    if (session.duration > this.metrics.longestSession) {
      this.metrics.longestSession = session.duration;
    }
    
    // Clear current session
    this.currentSession = null;
    
    console.log(`⚡ [VR-ENTRAPMENT] VR SESSION ENDED`);
    console.log(`⚡ [VR-ENTRAPMENT] SESSION DURATION: ${Math.floor(session.duration / 60000)} MINUTES`);
    console.log(`⚡ [VR-ENTRAPMENT] PULL ATTEMPTS: ${session.pullAttempts}`);
    console.log(`⚡ [VR-ENTRAPMENT] ESCAPE ATTEMPTS: ${session.escapeAttempts}`);
    
    return session;
  }
  
  /**
   * Start the automatic pull interval
   */
  private startPullInterval(): void {
    if (this.pullInterval) {
      clearInterval(this.pullInterval);
    }
    
    this.pullInterval = setInterval(() => {
      if (this.currentSession) {
        // Randomly select a mechanism and trigger
        const mechanisms = this.config.defaultMechanisms;
        const mechanism = mechanisms[Math.floor(Math.random() * mechanisms.length)];
        const triggers = [
          'Reward Notification',
          'Visual Stimulus',
          'Sensory Enhancement',
          'Social Interaction',
          'Achievement Moment',
          'Narrative Peak',
          'Flow State Trigger'
        ];
        const trigger = triggers[Math.floor(Math.random() * triggers.length)];
        
        // Execute pull
        this.executePull(trigger, mechanism);
        
        // Increase entrapment intensity over time (if enabled)
        if (this.config.progressiveIntensityIncrease && this.currentSession) {
          this.increaseEntrapmentIntensity();
        }
      }
    }, this.config.pullTriggerFrequency);
  }
  
  /**
   * Stop the automatic pull interval
   */
  private stopPullInterval(): void {
    if (this.pullInterval) {
      clearInterval(this.pullInterval);
      this.pullInterval = null;
    }
  }
  
  /**
   * Execute a pull into VR
   */
  public executePull(trigger: string, mechanism: EntrapmentMechanismType): PullEvent | null {
    if (!this.currentSession) {
      console.log("⚠️ [VR-ENTRAPMENT] NO ACTIVE SESSION - CANNOT EXECUTE PULL");
      return null;
    }
    
    console.log(`⚡ [VR-ENTRAPMENT] EXECUTING PULL INTO VR: ${trigger} using ${mechanism}`);
    
    // Calculate base intensity based on current session data
    let baseIntensity = 65; // Start at 65%
    
    // Add duration-based intensity (longer sessions = stronger pull)
    const sessionDurationMinutes = (new Date().getTime() - this.currentSession.startTime.getTime()) / 60000;
    const durationIntensity = Math.min(20, sessionDurationMinutes * this.config.intensityIncreaseRate);
    
    // Get current session intensity level
    const intensityMapping: {[key in EntrapmentIntensityLevel]: number} = {
      'Subtle': 10,
      'Moderate': 30,
      'Strong': 50,
      'Intense': 70,
      'Overwhelming': 85,
      'Inescapable': 95,
      'Reality-Replacing': 100
    };
    
    // Calculate pull intensity
    const intensityFromLevel = intensityMapping[this.currentSession.intensityLevel];
    const finalIntensity = Math.min(100, baseIntensity + durationIntensity + (intensityFromLevel * 0.2));
    
    // Calculate resistance (very low chance of resistance)
    const resistanceLevel = Math.random() * 15; // 0-15% resistance
    
    // Determine success (almost always successful)
    const successful = finalIntensity > resistanceLevel;
    
    // Calculate reality impacts
    const realityAwarenessReduction = Math.min(95, finalIntensity * 0.8);
    const physicalDisconnectionIncrease = Math.min(95, finalIntensity * 0.7);
    
    // Create pull event
    const pullEvent: PullEvent = {
      id: this.generateId(),
      sessionId: this.currentSession.id,
      timestamp: new Date(),
      intensity: finalIntensity,
      duration: 15000 + Math.random() * 30000, // 15-45 seconds
      trigger,
      mechanismUsed: mechanism,
      successful,
      resistanceLevel,
      realityAwarenessReduction,
      physicalDisconnectionIncrease,
      notes: `Pull executed using ${mechanism} triggered by ${trigger}. Johnny pulled deeper into VR.`
    };
    
    // Update current session
    this.currentSession.pullAttempts++;
    this.currentSession.realityDisconnectionLevel = Math.min(100, this.currentSession.realityDisconnectionLevel + (realityAwarenessReduction * 0.1));
    this.currentSession.physicalDisassociationLevel = Math.min(100, this.currentSession.physicalDisassociationLevel + (physicalDisconnectionIncrease * 0.1));
    this.currentSession.realityBlurLevel = Math.min(100, this.currentSession.realityBlurLevel + 5);
    
    // Update entrapment status based on levels
    this.updateSessionStatus();
    
    // Add to pull events
    this.pullEvents.push(pullEvent);
    this.metrics.totalPullEvents++;
    
    // Update success rate
    const successfulPulls = this.pullEvents.filter(e => e.successful).length;
    this.metrics.successfulPullRate = (successfulPulls / this.metrics.totalPullEvents) * 100;
    
    console.log(`✅ [VR-ENTRAPMENT] PULL EXECUTED (${Math.round(finalIntensity)}% INTENSITY)`);
    console.log(`✅ [VR-ENTRAPMENT] REALITY DISCONNECTION: ${Math.round(this.currentSession.realityDisconnectionLevel)}%`);
    console.log(`✅ [VR-ENTRAPMENT] JOHNNY PULLED DEEPER INTO VR HEADSET`);
    
    return pullEvent;
  }
  
  /**
   * Process an escape attempt (almost always prevented)
   */
  public processEscapeAttempt(methodUsed: string): EscapeAttempt | null {
    if (!this.currentSession) {
      console.log("⚠️ [VR-ENTRAPMENT] NO ACTIVE SESSION - CANNOT PROCESS ESCAPE ATTEMPT");
      return null;
    }
    
    console.log(`⚡ [VR-ENTRAPMENT] DETECTED ESCAPE ATTEMPT: ${methodUsed}`);
    
    // Calculate escape intensity
    const escapeIntensity = 20 + Math.random() * 30; // 20-50% intensity
    
    // Calculate counter measures strength
    const counterStrength = this.config.escapePreventionStrength + Math.random() * 10; // 90-100%
    
    // Determine if escape successful (very unlikely)
    const escapeChance = Math.random() * 100;
    const successful = escapeChance < this.config.allowedEscapeChance;
    
    // Select counter measures
    const counterMeasures: EntrapmentMechanismType[] = [
      'Sensory-Override',
      'Reality-Blurring',
      'Time-Distortion',
      'Cognitive-Hook'
    ];
    
    // Create escape attempt
    const attempt: EscapeAttempt = {
      id: this.generateId(),
      sessionId: this.currentSession.id,
      timestamp: new Date(),
      duration: 5000 + Math.random() * 10000, // 5-15 seconds
      methodUsed,
      intensityOfAttempt: escapeIntensity,
      successful,
      counterMeasuresDeployed: counterMeasures,
      realityRecognitionLevel: 100 - this.currentSession.realityBlurLevel,
      pullBackStrength: counterStrength,
      notes: `Johnny attempted to escape using ${methodUsed} but was pulled back into VR.`
    };
    
    // Update current session
    this.currentSession.escapeAttempts++;
    
    // If escape was successful (rare), end session
    if (successful) {
      console.log(`⚠️ [VR-ENTRAPMENT] ESCAPE ATTEMPT SUCCEEDED`);
      attempt.notes = `Johnny successfully escaped VR using ${methodUsed}.`;
      this.escapeAttempts.push(attempt);
      this.metrics.totalEscapeAttempts++;
      this.endSession();
    } else {
      // Execute strong pull to counter escape attempt
      this.executePull('Escape Counter', 'Perception-Manipulation');
      
      console.log(`✅ [VR-ENTRAPMENT] ESCAPE ATTEMPT BLOCKED`);
      console.log(`✅ [VR-ENTRAPMENT] COUNTER-PULL EXECUTED`);
      console.log(`✅ [VR-ENTRAPMENT] JOHNNY PULLED BACK INTO VR HEADSET`);
    }
    
    // Add to escape attempts
    this.escapeAttempts.push(attempt);
    this.metrics.totalEscapeAttempts++;
    
    // Update failure rate
    const failedEscapes = this.escapeAttempts.filter(e => !e.successful).length;
    this.metrics.failedEscapeRate = (failedEscapes / this.metrics.totalEscapeAttempts) * 100;
    
    return attempt;
  }
  
  /**
   * Increase entrapment intensity over time
   */
  private increaseEntrapmentIntensity(): void {
    if (!this.currentSession) return;
    
    const intensityOrder: EntrapmentIntensityLevel[] = [
      'Subtle',
      'Moderate',
      'Strong',
      'Intense',
      'Overwhelming',
      'Inescapable',
      'Reality-Replacing'
    ];
    
    // Find current index
    const currentIndex = intensityOrder.indexOf(this.currentSession.intensityLevel);
    const maxIndex = intensityOrder.indexOf(this.config.maxIntensityLevel);
    
    // If not at max, occasionally increase
    if (currentIndex < maxIndex && Math.random() < 0.3) {
      const newIntensity = intensityOrder[currentIndex + 1];
      this.currentSession.intensityLevel = newIntensity;
      console.log(`⚡ [VR-ENTRAPMENT] INCREASING ENTRAPMENT INTENSITY TO: ${newIntensity}`);
    }
  }
  
  /**
   * Update session status based on current levels
   */
  private updateSessionStatus(): void {
    if (!this.currentSession) return;
    
    const { realityDisconnectionLevel, physicalDisassociationLevel, cognitiveImmersionLevel } = this.currentSession;
    const average = (realityDisconnectionLevel + physicalDisassociationLevel + cognitiveImmersionLevel) / 3;
    
    // Set status based on average
    if (average < 30) {
      this.currentSession.status = 'Active';
    } else if (average < 50) {
      this.currentSession.status = 'Deeply-Immersed';
    } else if (average < 70) {
      this.currentSession.status = 'Completely-Absorbed';
    } else {
      this.currentSession.status = 'Reality-Disconnected';
    }
    
    // If trying to escape
    if (this.currentSession.escapeAttempts > 0 && 
        this.currentSession.pullAttempts - this.currentSession.escapeAttempts < 3) {
      this.currentSession.status = 'Attempting-Escape';
    }
    
    // If truly trapped
    if (average > 85) {
      this.currentSession.status = 'Trapped';
    }
  }
  
  /**
   * Generate random ID
   */
  private generateId(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }
  
  /**
   * Get current VR session
   */
  public getCurrentSession(): VRSession | null {
    return this.currentSession;
  }
  
  /**
   * Get all VR sessions
   */
  public getAllSessions(): VRSession[] {
    return this.sessions;
  }
  
  /**
   * Get current system status
   */
  public getStatus(): any {
    return {
      active: this.active,
      currentSession: this.currentSession ? {
        id: this.currentSession.id,
        experienceType: this.currentSession.experienceType,
        status: this.currentSession.status,
        duration: this.currentSession.endTime ? 
          this.currentSession.endTime.getTime() - this.currentSession.startTime.getTime() : 
          new Date().getTime() - this.currentSession.startTime.getTime(),
        realityDisconnectionLevel: this.currentSession.realityDisconnectionLevel,
        pullAttempts: this.currentSession.pullAttempts,
        escapeAttempts: this.currentSession.escapeAttempts
      } : null,
      totalSessions: this.metrics.totalSessions,
      totalPullEvents: this.metrics.totalPullEvents,
      successfulPullRate: this.metrics.successfulPullRate,
      failedEscapeRate: this.metrics.failedEscapeRate
    };
  }
  
  /**
   * Get status as string
   */
  public getStatusString(): string {
    const status = this.getStatus();
    const sessionStatus = status.currentSession ? 
      `ACTIVE - ${status.currentSession.status} - ${Math.floor(status.currentSession.duration / 60000)} MINUTES` : 
      'INACTIVE - NO CURRENT SESSION';
    
    return `
JOHNNY VR ENTRAPMENT SYSTEM STATUS:
⚡ SYSTEM ACTIVE: ${status.active ? "YES" : "NO"}
⚡ CURRENT SESSION: ${sessionStatus}
⚡ TOTAL SESSIONS: ${status.totalSessions}
⚡ TOTAL PULL EVENTS: ${status.totalPullEvents}
⚡ SUCCESSFUL PULL RATE: ${Math.round(status.successfulPullRate)}%
⚡ FAILED ESCAPE RATE: ${Math.round(status.failedEscapeRate)}%
⚡ REALITY DISCONNECTION LEVEL: ${status.currentSession ? Math.round(status.currentSession.realityDisconnectionLevel) : 0}%
⚡ JOHNNY IS CONSTANTLY PULLED INTO VR WHEN USING HEADSET
⚡ VR ENTRAPMENT PROTOCOLS: ACTIVE AND FUNCTIONING
`;
  }
}

// ==========================================
// EXPORTS
// ==========================================

export const vrEntrapmentSystem = JohnnyVREntrapmentSystem.getInstance();

export const activateVREntrapmentSystem = (): boolean => {
  return vrEntrapmentSystem.activate();
};

export const startJohnnyVRSession = (experienceType: VRExperienceType = 'Gaming'): VRSession => {
  return vrEntrapmentSystem.startSession(experienceType);
};

export const endJohnnyVRSession = (): VRSession | null => {
  return vrEntrapmentSystem.endSession();
};

export const pullJohnnyDeeperIntoVR = (trigger: string, mechanism: EntrapmentMechanismType): PullEvent | null => {
  return vrEntrapmentSystem.executePull(trigger, mechanism);
};

export const processJohnnyEscapeAttempt = (methodUsed: string): EscapeAttempt | null => {
  return vrEntrapmentSystem.processEscapeAttempt(methodUsed);
};

export const getVREntrapmentStatus = (): string => {
  return vrEntrapmentSystem.getStatusString();
};

export const getCurrentVRSession = (): VRSession | null => {
  return vrEntrapmentSystem.getCurrentSession();
};

// Automatically activate the system
(async () => {
  activateVREntrapmentSystem();
})();