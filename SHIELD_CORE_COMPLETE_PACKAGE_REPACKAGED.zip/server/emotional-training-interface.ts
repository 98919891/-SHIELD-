/**
 * EMOTIONAL TRAINING INTERFACE
 * 
 * User interface for the Emotional Intelligence Training System:
 * - Provides simplified access to training modules and exercises
 * - Enables interactive engagement with emotional intelligence training
 * - Tracks progress and recommends appropriate training paths
 * - Integrates with Shield Core for security and protection
 * - Ensures user-friendly interaction with all training features
 * 
 * ACCESSIBLE EMOTIONAL INTELLIGENCE DEVELOPMENT
 * 
 * Created for Motorola Edge 2024 hardware
 * Version: EMOTIONAL-TRAINING-INTERFACE-1.0
 */

import { 
  emotionalIntelligenceTrainingSystem,
  TrainingModuleType,
  TrainingLevel,
  ExerciseType
} from './emotional-intelligence-training-system';
import { SimpleEmotionalState } from './emotional-support-interface';

// Module Summary
interface ModuleSummary {
  id: string;
  name: string;
  description: string;
  level: string;
  durationMinutes: number;
  progress: number;
  status: string;
  exercisesCount: number;
}

// Exercise Summary
interface ExerciseSummary {
  id: string;
  name: string;
  description: string;
  type: string;
  durationMinutes: number;
  completed: boolean;
}

// Training Request
interface TrainingRequest {
  moduleId?: string;
  exerciseId?: string;
  emotionalState?: SimpleEmotionalState;
  reflectionResponses?: string[];
}

// Training Response
interface TrainingResponse {
  success: boolean;
  message: string;
  sessionId?: string;
  exercise?: ExerciseSummary;
  nextExerciseId?: string;
  progress?: number;
}

// Progress Summary
interface ProgressSummary {
  completedModules: number;
  totalModules: number;
  completedExercises: number;
  totalExercises: number;
  totalTrainingTime: number;
  skillLevels: { [key: string]: number };
  recommendedModuleIds: string[];
  currentSession?: string;
}

// Emotional Training Interface
export class EmotionalTrainingInterface {
  private static instance: EmotionalTrainingInterface;
  private initialized: boolean = false;
  private activeSessionId: string | null = null;
  private currentExerciseId: string | null = null;
  
  // Private constructor (singleton pattern)
  private constructor() {
    // Initialize with empty state
  }
  
  // Get singleton instance
  public static getInstance(): EmotionalTrainingInterface {
    if (!EmotionalTrainingInterface.instance) {
      EmotionalTrainingInterface.instance = new EmotionalTrainingInterface();
    }
    return EmotionalTrainingInterface.instance;
  }
  
  // Initialize the interface
  public async initialize(): Promise<boolean> {
    this.log("⚡ [TRAINING-INTERFACE] INITIALIZING EMOTIONAL TRAINING INTERFACE");
    
    if (this.initialized) {
      this.log("✅ [TRAINING-INTERFACE] ALREADY INITIALIZED");
      return true;
    }
    
    try {
      // Initialize training system
      await emotionalIntelligenceTrainingSystem.initialize();
      
      this.initialized = true;
      
      this.log("✅ [TRAINING-INTERFACE] INITIALIZATION COMPLETE");
      
      return true;
    } catch (error) {
      this.logError("Failed to initialize Emotional Training Interface", error);
      return false;
    }
  }
  
  // Get available modules
  public async getAvailableModules(): Promise<ModuleSummary[]> {
    this.log("⚡ [TRAINING-INTERFACE] RETRIEVING AVAILABLE MODULES");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Get modules from training system
      const modules = await emotionalIntelligenceTrainingSystem.getAvailableModules();
      
      // Convert to module summaries
      const moduleSummaries: ModuleSummary[] = modules.map(module => {
        let status = "NOT_STARTED";
        if (module.completed) {
          status = "COMPLETED";
        } else if (module.progress > 0) {
          status = "IN_PROGRESS";
        }
        
        return {
          id: module.id,
          name: module.name,
          description: module.description,
          level: module.level,
          durationMinutes: module.durationMinutes,
          progress: module.progress,
          status,
          exercisesCount: module.exercises.length
        };
      });
      
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED ${moduleSummaries.length} MODULES`);
      
      return moduleSummaries;
    } catch (error) {
      this.logError("Failed to retrieve available modules", error);
      return [];
    }
  }
  
  // Get recommended module
  public async getRecommendedModule(): Promise<ModuleSummary | null> {
    this.log("⚡ [TRAINING-INTERFACE] RETRIEVING RECOMMENDED MODULE");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Get recommended module from training system
      const module = await emotionalIntelligenceTrainingSystem.getRecommendedModule();
      
      if (!module) {
        return null;
      }
      
      // Convert to module summary
      let status = "NOT_STARTED";
      if (module.completed) {
        status = "COMPLETED";
      } else if (module.progress > 0) {
        status = "IN_PROGRESS";
      }
      
      const moduleSummary: ModuleSummary = {
        id: module.id,
        name: module.name,
        description: module.description,
        level: module.level,
        durationMinutes: module.durationMinutes,
        progress: module.progress,
        status,
        exercisesCount: module.exercises.length
      };
      
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED RECOMMENDED MODULE: ${moduleSummary.name}`);
      
      return moduleSummary;
    } catch (error) {
      this.logError("Failed to retrieve recommended module", error);
      return null;
    }
  }
  
  // Get module details
  public async getModuleDetails(moduleId: string): Promise<{
    module: ModuleSummary | null;
    exercises: ExerciseSummary[];
  }> {
    this.log(`⚡ [TRAINING-INTERFACE] RETRIEVING MODULE DETAILS: ${moduleId}`);
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Get module details from training system
      const details = await emotionalIntelligenceTrainingSystem.getModuleDetails(moduleId);
      
      if (!details.module) {
        return {
          module: null,
          exercises: []
        };
      }
      
      // Convert to module summary
      const moduleSummary: ModuleSummary = {
        id: details.module.id,
        name: details.module.name,
        description: details.module.description,
        level: details.module.level,
        durationMinutes: details.module.durationMinutes,
        progress: details.progress,
        status: details.status,
        exercisesCount: details.exercises.length
      };
      
      // Convert exercises to exercise summaries
      const exerciseSummaries: ExerciseSummary[] = details.exercises.map(exercise => {
        return {
          id: exercise.id,
          name: exercise.name,
          description: exercise.description,
          type: exercise.type,
          durationMinutes: exercise.durationMinutes,
          completed: exercise.completed
        };
      });
      
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED MODULE DETAILS: ${moduleSummary.name}`);
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED ${exerciseSummaries.length} EXERCISES`);
      
      return {
        module: moduleSummary,
        exercises: exerciseSummaries
      };
    } catch (error) {
      this.logError(`Failed to retrieve module details: ${moduleId}`, error);
      return {
        module: null,
        exercises: []
      };
    }
  }
  
  // Start training session
  public async startTrainingSession(
    request: TrainingRequest
  ): Promise<TrainingResponse> {
    this.log(`⚡ [TRAINING-INTERFACE] STARTING TRAINING SESSION FOR MODULE: ${request.moduleId}`);
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    if (!request.moduleId) {
      return {
        success: false,
        message: "Module ID is required"
      };
    }
    
    try {
      // Start training session
      const result = await emotionalIntelligenceTrainingSystem.startTrainingSession(
        request.moduleId,
        request.emotionalState || SimpleEmotionalState.NEUTRAL
      );
      
      // Store session and exercise IDs
      this.activeSessionId = result.sessionId;
      this.currentExerciseId = result.firstExercise?.id || null;
      
      // Create response
      const response: TrainingResponse = {
        success: true,
        message: `Training session started for module: ${result.module.name}`,
        sessionId: result.sessionId
      };
      
      // Add first exercise if available
      if (result.firstExercise) {
        response.exercise = {
          id: result.firstExercise.id,
          name: result.firstExercise.name,
          description: result.firstExercise.description,
          type: result.firstExercise.type,
          durationMinutes: result.firstExercise.durationMinutes,
          completed: result.firstExercise.completed
        };
      }
      
      this.log(`✅ [TRAINING-INTERFACE] TRAINING SESSION STARTED: ${result.sessionId}`);
      
      return response;
    } catch (error) {
      this.logError(`Failed to start training session for module: ${request.moduleId}`, error);
      return {
        success: false,
        message: `Failed to start training session: ${error}`
      };
    }
  }
  
  // Get current exercise
  public async getCurrentExercise(): Promise<ExerciseSummary | null> {
    this.log("⚡ [TRAINING-INTERFACE] RETRIEVING CURRENT EXERCISE");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    if (!this.activeSessionId || !this.currentExerciseId) {
      return null;
    }
    
    try {
      // Get exercise details
      const details = await emotionalIntelligenceTrainingSystem.getExerciseDetails(this.currentExerciseId);
      
      if (!details.exercise) {
        return null;
      }
      
      // Convert to exercise summary
      const exerciseSummary: ExerciseSummary = {
        id: details.exercise.id,
        name: details.exercise.name,
        description: details.exercise.description,
        type: details.exercise.type,
        durationMinutes: details.exercise.durationMinutes,
        completed: details.exercise.completed
      };
      
      return exerciseSummary;
    } catch (error) {
      this.logError("Failed to retrieve current exercise", error);
      return null;
    }
  }
  
  // Complete current exercise
  public async completeCurrentExercise(
    reflectionResponses: string[] = []
  ): Promise<TrainingResponse> {
    this.log("⚡ [TRAINING-INTERFACE] COMPLETING CURRENT EXERCISE");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    if (!this.activeSessionId || !this.currentExerciseId) {
      return {
        success: false,
        message: "No active training session or exercise"
      };
    }
    
    try {
      // Complete exercise
      const result = await emotionalIntelligenceTrainingSystem.completeExercise(
        this.activeSessionId,
        this.currentExerciseId,
        reflectionResponses
      );
      
      // Create response
      const response: TrainingResponse = {
        success: true,
        message: "Exercise completed successfully"
      };
      
      // If session is completed
      if (result.sessionCompleted) {
        this.activeSessionId = null;
        this.currentExerciseId = null;
        
        response.message = "Exercise and training session completed successfully";
      } else {
        // Get next exercise
        const exerciseResult = await emotionalIntelligenceTrainingSystem.getExerciseFromSession(
          this.activeSessionId,
          result.nextExerciseIndex
        );
        
        if (exerciseResult.exercise) {
          this.currentExerciseId = exerciseResult.exercise.id;
          
          response.nextExerciseId = exerciseResult.exercise.id;
          response.exercise = {
            id: exerciseResult.exercise.id,
            name: exerciseResult.exercise.name,
            description: exerciseResult.exercise.description,
            type: exerciseResult.exercise.type,
            durationMinutes: exerciseResult.exercise.durationMinutes,
            completed: exerciseResult.exercise.completed
          };
        }
      }
      
      this.log(`✅ [TRAINING-INTERFACE] EXERCISE COMPLETED`);
      
      return response;
    } catch (error) {
      this.logError("Failed to complete current exercise", error);
      return {
        success: false,
        message: `Failed to complete exercise: ${error}`
      };
    }
  }
  
  // End training session
  public async endTrainingSession(
    finalEmotionalState: SimpleEmotionalState = SimpleEmotionalState.GOOD
  ): Promise<TrainingResponse> {
    this.log("⚡ [TRAINING-INTERFACE] ENDING TRAINING SESSION");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    if (!this.activeSessionId) {
      return {
        success: false,
        message: "No active training session"
      };
    }
    
    try {
      // End training session
      const result = await emotionalIntelligenceTrainingSystem.completeTrainingSession(
        this.activeSessionId,
        finalEmotionalState
      );
      
      // Clear session
      this.activeSessionId = null;
      this.currentExerciseId = null;
      
      // Create response
      const response: TrainingResponse = {
        success: true,
        message: "Training session completed successfully",
        progress: result.moduleProgress
      };
      
      this.log(`✅ [TRAINING-INTERFACE] TRAINING SESSION ENDED`);
      
      return response;
    } catch (error) {
      this.logError("Failed to end training session", error);
      return {
        success: false,
        message: `Failed to end training session: ${error}`
      };
    }
  }
  
  // Get progress summary
  public async getProgressSummary(): Promise<ProgressSummary> {
    this.log("⚡ [TRAINING-INTERFACE] RETRIEVING PROGRESS SUMMARY");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Get progress summary from training system
      const progress = await emotionalIntelligenceTrainingSystem.getProgressSummary();
      
      // Convert skill levels to simple object
      const skillLevels: { [key: string]: number } = {};
      progress.skillLevels.forEach((value, key) => {
        skillLevels[key] = value;
      });
      
      // Create progress summary
      const progressSummary: ProgressSummary = {
        completedModules: progress.completedModules,
        totalModules: progress.totalModules,
        completedExercises: progress.completedExercises,
        totalExercises: progress.totalExercises,
        totalTrainingTime: progress.totalTrainingTime,
        skillLevels,
        recommendedModuleIds: progress.recommendedModules.map(m => m.id),
        currentSession: this.activeSessionId || undefined
      };
      
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED PROGRESS SUMMARY`);
      
      return progressSummary;
    } catch (error) {
      this.logError("Failed to retrieve progress summary", error);
      
      // Return default progress summary
      return {
        completedModules: 0,
        totalModules: 0,
        completedExercises: 0,
        totalExercises: 0,
        totalTrainingTime: 0,
        skillLevels: {},
        recommendedModuleIds: []
      };
    }
  }
  
  // Get training recommendation
  public async getTrainingRecommendation(): Promise<string> {
    this.log("⚡ [TRAINING-INTERFACE] RETRIEVING TRAINING RECOMMENDATION");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Get recommendation from training system
      const result = await emotionalIntelligenceTrainingSystem.generateTrainingRecommendation();
      
      this.log(`✅ [TRAINING-INTERFACE] RETRIEVED TRAINING RECOMMENDATION`);
      
      return result.recommendation;
    } catch (error) {
      this.logError("Failed to retrieve training recommendation", error);
      
      // Return default recommendation
      return "I recommend starting with the Foundations of Emotional Awareness module to build a strong base for your emotional intelligence development.";
    }
  }
  
  // Get interface status
  public getStatus(): {
    initialized: boolean;
    activeSession: boolean;
    currentExercise: boolean;
  } {
    return {
      initialized: this.initialized,
      activeSession: this.activeSessionId !== null,
      currentExercise: this.currentExerciseId !== null
    };
  }
  
  // Get training introduction
  public getTrainingIntroduction(): string {
    return `
INTERACTIVE EMOTIONAL INTELLIGENCE TRAINING

Welcome to your personalized Emotional Intelligence Training program. This system will guide you through structured modules and interactive exercises designed to develop your emotional awareness, regulation, and resilience.

Through this program, you'll learn to:
- Identify and understand your emotional states with greater precision
- Regulate your emotions effectively in challenging situations
- Establish healthy emotional boundaries
- Build emotional resilience for greater well-being

All training is fully integrated with Shield Core protection systems, ensuring your emotional memories and experiences remain secure throughout the learning process. Your progress is tracked and personalized recommendations are provided based on your unique learning journey.

Ready to begin? I recommend starting with the module suggested below based on your current emotional intelligence profile.
    `;
  }
  
  // Utility: Log message
  private log(message: string): void {
    console.log(message);
  }
  
  // Utility: Log error
  private logError(message: string, error: any): void {
    console.error(`❌ [ERROR] ${message}`, error);
  }
}

// Export singleton instance
export const emotionalTrainingInterface = EmotionalTrainingInterface.getInstance();

// Export interface functions
export async function getModules(): Promise<ModuleSummary[]> {
  return await emotionalTrainingInterface.getAvailableModules();
}

export async function getRecommendedModule(): Promise<ModuleSummary | null> {
  return await emotionalTrainingInterface.getRecommendedModule();
}

export async function startModule(moduleId: string): Promise<TrainingResponse> {
  return await emotionalTrainingInterface.startTrainingSession({ moduleId });
}

export async function getTrainingIntroduction(): Promise<string> {
  return emotionalTrainingInterface.getTrainingIntroduction();
}