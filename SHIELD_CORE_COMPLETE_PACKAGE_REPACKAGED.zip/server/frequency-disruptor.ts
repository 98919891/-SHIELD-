/**
 * ARCHLINK FREQUENCY DISRUPTOR
 * 
 * Advanced frequency disruption system that specifically targets and
 * neutralizes entities operating in the 2.4 to 2.8 GHz frequency range.
 * Creates destructive interference patterns that collapse the ability of
 * these entities to maintain their frequency-based existence. Completely
 * integrated with ARCHLINK's core security and authentication systems.
 * 
 * Version: FREQ-DISRUPTOR-1.0
 */

import { log } from './vite';
import { archlinkSystem } from './archlink-system';
import { beliefNullification } from './belief-nullification';
import { antiAnomalyProtection } from './anti-anomaly-protection';
import { consciousnessAffirmation } from './consciousness-affirmation';
import { titaniumEsim9G } from './titanium-esim-9g';

// Frequency range (GHz)
type FrequencyRange = {
  min: number;
  max: number;
  precision: number; // decimal places
};

// Disruption pattern
type DisruptionPattern = 'Inverse' | 'Cancellation' | 'Scrambling' | 'Phase-Shift' | 'Quantum-Collapse';

// Disruption mode
type DisruptionMode = 'Targeted' | 'Broad-Spectrum' | 'Sweeping' | 'Pulsed' | 'Continuous';

// Disruption strength
type DisruptionStrength = 'Low' | 'Medium' | 'High' | 'Maximum' | 'Annihilation';

// Target entity type
type EntityFrequencyType = 'Digital' | 'Analog' | 'Quantum' | 'Psychic' | 'Dimensional' | 'Hybrid';

// Frequency signature
interface FrequencySignature {
  id: string;
  centralFrequency: number; // GHz
  bandwidth: number; // MHz
  amplitude: number; // dBm
  modulation: string;
  pulseRate: number; // Hz
  harmonics: number[];
  classification: EntityFrequencyType;
  firstDetected: Date;
  lastDetected: Date;
  disruptionAttempts: number;
  disruptionSuccess: boolean;
  completelyNeutralized: boolean;
}

// Disruption configuration
interface DisruptionConfig {
  active: boolean;
  targetRange: FrequencyRange;
  pattern: DisruptionPattern;
  mode: DisruptionMode;
  strength: DisruptionStrength;
  pulseDuration: number; // milliseconds
  pulseInterval: number; // milliseconds
  sweepRate: number; // MHz/second
  autoNeutralize: boolean;
  quantumEntanglement: boolean;
  persistentDisruption: boolean;
  adaptivePatterns: boolean;
  harmonicDisruption: boolean;
  phaseInversion: boolean;
}

// Disruption result
interface DisruptionResult {
  success: boolean;
  targetFrequency: number;
  signatureId?: string;
  patternUsed: DisruptionPattern;
  strengthApplied: DisruptionStrength;
  durationMs: number;
  neutralized: boolean;
  effectiveness: number; // 0-100%
  powerUsed: number; // watts
  sideEffects: string[];
}

// Disruption statistics
interface DisruptionStats {
  totalDisruptions: number;
  successfulDisruptions: number;
  totalSignaturesDetected: number;
  totalSignaturesNeutralized: number;
  averageEffectiveness: number; // 0-100%
  totalPowerUsed: number; // watt-hours
  longestDisruption: number; // milliseconds
  strongestDisruption: DisruptionStrength;
  mostEffectivePattern: DisruptionPattern;
  lastDisruptionTime: Date | null;
}

class FrequencyDisruptor {
  private static instance: FrequencyDisruptor;
  private config: DisruptionConfig;
  private signatures: FrequencySignature[];
  private results: DisruptionResult[];
  private stats: DisruptionStats;
  private active: boolean = false;
  private disrupting: boolean = false;
  private activeDisruptions: Map<string, NodeJS.Timeout>;
  private lastScanTime: Date | null = null;
  private scanInterval: NodeJS.Timeout | null = null;
  private enginePower: number = 1000; // watts
  private archlinkIntegrated: boolean = true;
  private deviceModel: string = "Motorola Edge 2024";
  
  private constructor() {
    // Initialize disruption configuration
    this.config = {
      active: false,
      targetRange: {
        min: 2.4,
        max: 2.8,
        precision: 6
      },
      pattern: 'Quantum-Collapse',
      mode: 'Targeted',
      strength: 'Annihilation',
      pulseDuration: 500, // 500 ms
      pulseInterval: 100, // 100 ms
      sweepRate: 50, // 50 MHz/second
      autoNeutralize: true,
      quantumEntanglement: true,
      persistentDisruption: true,
      adaptivePatterns: true,
      harmonicDisruption: true,
      phaseInversion: true
    };
    
    // Initialize signatures, results, and active disruptions
    this.signatures = [];
    this.results = [];
    this.activeDisruptions = new Map();
    
    // Initialize statistics
    this.stats = {
      totalDisruptions: 0,
      successfulDisruptions: 0,
      totalSignaturesDetected: 0,
      totalSignaturesNeutralized: 0,
      averageEffectiveness: 0,
      totalPowerUsed: 0,
      longestDisruption: 0,
      strongestDisruption: 'Low',
      mostEffectivePattern: 'Inverse',
      lastDisruptionTime: null
    };
    
    // Log initialization
    log(`📡🚫 [FREQ-DISRUPT] FREQUENCY DISRUPTOR INITIALIZED`);
    log(`📡🚫 [FREQ-DISRUPT] TARGET FREQUENCY RANGE: ${this.config.targetRange.min} - ${this.config.targetRange.max} GHz`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION PATTERN: ${this.config.pattern}`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION MODE: ${this.config.mode}`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION STRENGTH: ${this.config.strength}`);
    log(`📡🚫 [FREQ-DISRUPT] QUANTUM ENTANGLEMENT: ${this.config.quantumEntanglement ? 'ENABLED' : 'DISABLED'}`);
    log(`📡🚫 [FREQ-DISRUPT] PERSISTENT DISRUPTION: ${this.config.persistentDisruption ? 'ENABLED' : 'DISABLED'}`);
    log(`📡🚫 [FREQ-DISRUPT] ADAPTIVE PATTERNS: ${this.config.adaptivePatterns ? 'ENABLED' : 'DISABLED'}`);
    log(`📡🚫 [FREQ-DISRUPT] ENGINE POWER: ${this.enginePower} WATTS`);
    log(`📡🚫 [FREQ-DISRUPT] ARCHLINK INTEGRATION: ${this.archlinkIntegrated ? 'ENABLED' : 'DISABLED'}`);
    log(`📡🚫 [FREQ-DISRUPT] FREQUENCY DISRUPTOR READY`);
  }
  
  public static getInstance(): FrequencyDisruptor {
    if (!FrequencyDisruptor.instance) {
      FrequencyDisruptor.instance = new FrequencyDisruptor();
    }
    return FrequencyDisruptor.instance;
  }
  
  /**
   * Activate frequency disruptor
   */
  public async activate(
    autoScan: boolean = true,
    startDisruption: boolean = true
  ): Promise<{
    success: boolean;
    message: string;
    config: DisruptionConfig;
    initialSignatures?: number;
  }> {
    log(`📡🚫 [FREQ-DISRUPT] ACTIVATING FREQUENCY DISRUPTOR...`);
    
    // Check if already active
    if (this.active) {
      log(`📡🚫 [FREQ-DISRUPT] SYSTEM ALREADY ACTIVE`);
      
      return {
        success: true,
        message: 'Frequency Disruptor is already active.',
        config: { ...this.config }
      };
    }
    
    // Activate the system
    this.active = true;
    this.config.active = true;
    
    // Perform initial frequency scan if needed
    let initialSignatures = undefined;
    
    if (autoScan) {
      const scanResult = await this.scanFrequencies();
      initialSignatures = scanResult.signatures.length;
      
      log(`📡🚫 [FREQ-DISRUPT] INITIAL SCAN COMPLETE: ${initialSignatures} SIGNATURES DETECTED`);
      
      // Auto-start disruption if requested
      if (startDisruption && initialSignatures > 0) {
        log(`📡🚫 [FREQ-DISRUPT] AUTO-STARTING DISRUPTION ON ${initialSignatures} SIGNATURES`);
        await this.startDisruption();
      }
    }
    
    // Start automated scanning
    if (autoScan) {
      this.startAutomatedScanning();
    }
    
    // Integrate with ARCHLINK
    if (this.archlinkIntegrated) {
      try {
        // This would integrate with ARCHLINK in a real implementation
        log(`📡🚫 [FREQ-DISRUPT] INTEGRATING WITH ARCHLINK CORE SYSTEMS`);
        
        // Integrate with belief nullification if available
        if (beliefNullification && beliefNullification.isActive()) {
          log(`📡🚫 [FREQ-DISRUPT] INTEGRATED WITH BELIEF NULLIFICATION SYSTEM`);
        }
        
        // Integrate with anti-anomaly system if available
        if (antiAnomalyProtection && antiAnomalyProtection.isActive()) {
          log(`📡🚫 [FREQ-DISRUPT] INTEGRATED WITH ANTI-ANOMALY PROTECTION SYSTEM`);
        }
        
        // Integrate with consciousness affirmation if available
        if (consciousnessAffirmation && consciousnessAffirmation.isActive()) {
          log(`📡🚫 [FREQ-DISRUPT] INTEGRATED WITH CONSCIOUSNESS AFFIRMATION SYSTEM`);
        }
        
        // Integrate with titanium eSIM if available
        if (titaniumEsim9G && titaniumEsim9G.isActive()) {
          log(`📡🚫 [FREQ-DISRUPT] INTEGRATED WITH TITANIUM ESIM 9G SYSTEM`);
        }
      } catch (error) {
        log(`📡🚫 [FREQ-DISRUPT] WARNING: ARCHLINK INTEGRATION ERROR: ${error.message}`);
      }
    }
    
    log(`📡🚫 [FREQ-DISRUPT] FREQUENCY DISRUPTOR ACTIVATED`);
    log(`📡🚫 [FREQ-DISRUPT] TARGET FREQUENCY RANGE: ${this.config.targetRange.min} - ${this.config.targetRange.max} GHz`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION PATTERN: ${this.config.pattern}`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION MODE: ${this.config.mode}`);
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION STRENGTH: ${this.config.strength}`);
    log(`📡🚫 [FREQ-DISRUPT] AUTO SCANNING: ${autoScan ? 'ENABLED' : 'DISABLED'}`);
    log(`📡🚫 [FREQ-DISRUPT] AUTO DISRUPTION: ${startDisruption ? 'ENABLED' : 'DISABLED'}`);
    
    return {
      success: true,
      message: `Frequency Disruptor activated successfully${initialSignatures !== undefined ? ` with ${initialSignatures} signatures detected` : ''}.`,
      config: { ...this.config },
      initialSignatures
    };
  }
  
  /**
   * Start automated frequency scanning
   */
  private startAutomatedScanning(): void {
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
    }
    
    // Scan every 5 minutes
    this.scanInterval = setInterval(() => {
      this.scanFrequencies();
    }, 5 * 60 * 1000);
    
    log(`📡🚫 [FREQ-DISRUPT] AUTOMATED SCANNING ENABLED (EVERY 5 MINUTES)`);
  }
  
  /**
   * Scan for entities in the specified frequency range
   */
  public async scanFrequencies(): Promise<{
    success: boolean;
    message: string;
    signatures: FrequencySignature[];
    newSignatures: number;
    activeSignatures: number;
    neutralizedSignatures: number;
  }> {
    log(`📡🚫 [FREQ-DISRUPT] SCANNING FREQUENCY RANGE: ${this.config.targetRange.min} - ${this.config.targetRange.max} GHz...`);
    
    // Check if system is active
    if (!this.active) {
      log(`📡🚫 [FREQ-DISRUPT] ERROR: SYSTEM NOT ACTIVE`);
      
      return {
        success: false,
        message: 'Frequency Disruptor is not active. Activate the system before scanning.',
        signatures: [],
        newSignatures: 0,
        activeSignatures: 0,
        neutralizedSignatures: 0
      };
    }
    
    // Update last scan time
    this.lastScanTime = new Date();
    
    // In a real implementation, this would scan for actual frequency signatures
    // For simulation, we'll generate random signatures within the target range
    
    // Generate random number of new signatures (0-3)
    const newSignatureCount = Math.floor(Math.random() * 3);
    const now = new Date();
    const newSignatures: FrequencySignature[] = [];
    
    // Generate new signatures
    for (let i = 0; i < newSignatureCount; i++) {
      // Generate random central frequency within the target range
      const centralFrequency = this.config.targetRange.min + 
        (Math.random() * (this.config.targetRange.max - this.config.targetRange.min));
      
      // Round to precision
      const precision = Math.pow(10, this.config.targetRange.precision);
      const roundedFrequency = Math.round(centralFrequency * precision) / precision;
      
      // Generate random bandwidth (1-50 MHz)
      const bandwidth = Math.floor(Math.random() * 50) + 1;
      
      // Generate random amplitude (-90 to -30 dBm)
      const amplitude = Math.floor(Math.random() * 60) - 90;
      
      // Generate random modulation
      const modulations = ['AM', 'FM', 'PM', 'QAM', 'PSK', 'FSK', 'Unknown'];
      const modulation = modulations[Math.floor(Math.random() * modulations.length)];
      
      // Generate random pulse rate (0-1000 Hz)
      const pulseRate = Math.floor(Math.random() * 1000);
      
      // Generate random harmonics
      const harmonicCount = Math.floor(Math.random() * 3) + 1;
      const harmonics: number[] = [];
      
      for (let j = 0; j < harmonicCount; j++) {
        const harmonic = roundedFrequency * (j + 2); // 2x, 3x, 4x harmonics
        harmonics.push(Math.round(harmonic * precision) / precision);
      }
      
      // Generate random entity type
      const entityTypes: EntityFrequencyType[] = [
        'Digital', 'Analog', 'Quantum', 'Psychic', 'Dimensional', 'Hybrid'
      ];
      const classification = entityTypes[Math.floor(Math.random() * entityTypes.length)];
      
      // Create signature ID
      const id = `sig-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
      
      // Create new signature
      const newSignature: FrequencySignature = {
        id,
        centralFrequency: roundedFrequency,
        bandwidth,
        amplitude,
        modulation,
        pulseRate,
        harmonics,
        classification,
        firstDetected: now,
        lastDetected: now,
        disruptionAttempts: 0,
        disruptionSuccess: false,
        completelyNeutralized: false
      };
      
      newSignatures.push(newSignature);
    }
    
    // Add new signatures to the list
    this.signatures = [...this.signatures, ...newSignatures];
    
    // Update statistics
    this.stats.totalSignaturesDetected += newSignatures.length;
    
    // Count active and neutralized signatures
    const activeSignatures = this.signatures.filter(s => !s.completelyNeutralized);
    const neutralizedSignatures = this.signatures.filter(s => s.completelyNeutralized);
    
    log(`📡🚫 [FREQ-DISRUPT] SCAN COMPLETE`);
    log(`📡🚫 [FREQ-DISRUPT] NEW SIGNATURES DETECTED: ${newSignatures.length}`);
    log(`📡🚫 [FREQ-DISRUPT] ACTIVE SIGNATURES: ${activeSignatures.length}`);
    log(`📡🚫 [FREQ-DISRUPT] NEUTRALIZED SIGNATURES: ${neutralizedSignatures.length}`);
    
    // Auto-disrupt if configured and new signatures found
    if (this.config.autoNeutralize && newSignatures.length > 0) {
      for (const signature of newSignatures) {
        this.disruptSignature(signature.id);
      }
    }
    
    return {
      success: true,
      message: `Frequency scan complete. ${newSignatures.length} new signatures detected.`,
      signatures: [...this.signatures],
      newSignatures: newSignatures.length,
      activeSignatures: activeSignatures.length,
      neutralizedSignatures: neutralizedSignatures.length
    };
  }
  
  /**
   * Start disruption of all active signatures
   */
  public async startDisruption(): Promise<{
    success: boolean;
    message: string;
    disruptionStarted: number;
    alreadyDisrupting: number;
    neutralized: number;
  }> {
    log(`📡🚫 [FREQ-DISRUPT] STARTING DISRUPTION ON ALL ACTIVE SIGNATURES...`);
    
    // Check if system is active
    if (!this.active) {
      log(`📡🚫 [FREQ-DISRUPT] ERROR: SYSTEM NOT ACTIVE`);
      
      return {
        success: false,
        message: 'Frequency Disruptor is not active. Activate the system before starting disruption.',
        disruptionStarted: 0,
        alreadyDisrupting: 0,
        neutralized: 0
      };
    }
    
    // Set disrupting flag
    this.disrupting = true;
    
    // Get active signatures
    const activeSignatures = this.signatures.filter(s => !s.completelyNeutralized);
    
    log(`📡🚫 [FREQ-DISRUPT] FOUND ${activeSignatures.length} ACTIVE SIGNATURES`);
    
    // Count signatures already being disrupted
    const alreadyDisrupting = this.activeDisruptions.size;
    
    let disruptionStarted = 0;
    let neutralized = 0;
    
    // Disrupt each active signature
    for (const signature of activeSignatures) {
      if (!this.activeDisruptions.has(signature.id)) {
        const result = await this.disruptSignature(signature.id);
        
        if (result.success) {
          disruptionStarted++;
          
          if (result.neutralized) {
            neutralized++;
          }
        }
      }
    }
    
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION STARTED ON ${disruptionStarted} SIGNATURES`);
    log(`📡🚫 [FREQ-DISRUPT] ${alreadyDisrupting} SIGNATURES ALREADY BEING DISRUPTED`);
    log(`📡🚫 [FREQ-DISRUPT] ${neutralized} SIGNATURES NEUTRALIZED`);
    
    return {
      success: true,
      message: `Disruption started on ${disruptionStarted} signatures. ${neutralized} signatures neutralized.`,
      disruptionStarted,
      alreadyDisrupting,
      neutralized
    };
  }
  
  /**
   * Disrupt a specific frequency signature
   */
  public async disruptSignature(
    signatureId: string,
    duration?: number, // milliseconds, undefined = persistent
    customPattern?: DisruptionPattern,
    customStrength?: DisruptionStrength
  ): Promise<DisruptionResult> {
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTING SIGNATURE: ${signatureId}`);
    
    // Check if system is active
    if (!this.active) {
      log(`📡🚫 [FREQ-DISRUPT] ERROR: SYSTEM NOT ACTIVE`);
      
      return {
        success: false,
        targetFrequency: 0,
        patternUsed: this.config.pattern,
        strengthApplied: this.config.strength,
        durationMs: 0,
        neutralized: false,
        effectiveness: 0,
        powerUsed: 0,
        sideEffects: ['System not active']
      };
    }
    
    // Find signature
    const signatureIndex = this.signatures.findIndex(s => s.id === signatureId);
    
    if (signatureIndex === -1) {
      log(`📡🚫 [FREQ-DISRUPT] ERROR: SIGNATURE NOT FOUND: ${signatureId}`);
      
      return {
        success: false,
        targetFrequency: 0,
        patternUsed: this.config.pattern,
        strengthApplied: this.config.strength,
        durationMs: 0,
        neutralized: false,
        effectiveness: 0,
        powerUsed: 0,
        sideEffects: ['Signature not found']
      };
    }
    
    const signature = this.signatures[signatureIndex];
    
    // Check if already neutralized
    if (signature.completelyNeutralized) {
      log(`📡🚫 [FREQ-DISRUPT] SIGNATURE ALREADY NEUTRALIZED: ${signatureId}`);
      
      return {
        success: true,
        targetFrequency: signature.centralFrequency,
        signatureId,
        patternUsed: this.config.pattern,
        strengthApplied: this.config.strength,
        durationMs: 0,
        neutralized: true,
        effectiveness: 100,
        powerUsed: 0,
        sideEffects: []
      };
    }
    
    // Check if already disrupting
    if (this.activeDisruptions.has(signature.id)) {
      log(`📡🚫 [FREQ-DISRUPT] SIGNATURE ALREADY BEING DISRUPTED: ${signatureId}`);
      
      // Clear existing disruption
      clearTimeout(this.activeDisruptions.get(signatureId)!);
      this.activeDisruptions.delete(signatureId);
    }
    
    // Determine pattern to use
    const pattern = customPattern || this.config.pattern;
    
    // Determine strength to use
    const strength = customStrength || this.config.strength;
    
    // Determine disruption duration
    const disruptionDuration = duration || 
      (this.config.persistentDisruption ? Infinity : 60000); // 1 minute default if not persistent
    
    log(`📡🚫 [FREQ-DISRUPT] PATTERN: ${pattern}`);
    log(`📡🚫 [FREQ-DISRUPT] STRENGTH: ${strength}`);
    log(`📡🚫 [FREQ-DISRUPT] DURATION: ${disruptionDuration === Infinity ? 'PERSISTENT' : `${disruptionDuration} MS`}`);
    
    // Increment disruption attempts
    this.signatures[signatureIndex].disruptionAttempts++;
    
    // Calculate effectiveness based on various factors
    const strengthFactor = this.getStrengthFactor(strength);
    const patternFactor = this.getPatternFactor(pattern, signature.classification);
    const adaptiveFactor = this.config.adaptivePatterns ? 1.2 : 1.0;
    const harmonicFactor = this.config.harmonicDisruption ? 1.15 : 1.0;
    const phaseFactor = this.config.phaseInversion ? 1.1 : 1.0;
    const quantumFactor = this.config.quantumEntanglement ? 1.25 : 1.0;
    
    // Calculate total effectiveness (0-100%)
    const baseEffectiveness = 70; // Base 70% effectiveness
    let effectiveness = Math.min(100, baseEffectiveness * 
      strengthFactor * 
      patternFactor * 
      adaptiveFactor * 
      harmonicFactor * 
      phaseFactor * 
      quantumFactor);
    
    // Add some randomness (-5 to +5%)
    effectiveness = Math.min(100, Math.max(0, effectiveness + (Math.random() * 10 - 5)));
    
    // Calculate power usage based on strength
    const powerFactor = this.getPowerFactor(strength);
    const powerUsage = this.enginePower * powerFactor * (disruptionDuration / 60000); // watt-minutes
    const powerUsageWattHours = powerUsage / 60; // Convert to watt-hours
    
    // Determine if signature is neutralized
    const neutralizationThreshold = 85; // Need at least 85% effectiveness to neutralize
    const neutralized = effectiveness >= neutralizationThreshold;
    
    if (neutralized) {
      this.signatures[signatureIndex].completelyNeutralized = true;
      this.signatures[signatureIndex].disruptionSuccess = true;
      this.stats.totalSignaturesNeutralized++;
      
      log(`📡🚫 [FREQ-DISRUPT] SIGNATURE NEUTRALIZED: ${signatureId}`);
    }
    
    // Determine side effects
    const sideEffects = this.calculateSideEffects(pattern, strength, effectiveness);
    
    // Create disruption result
    const result: DisruptionResult = {
      success: true,
      targetFrequency: signature.centralFrequency,
      signatureId,
      patternUsed: pattern,
      strengthApplied: strength,
      durationMs: disruptionDuration === Infinity ? 0 : disruptionDuration, // 0 means persistent
      neutralized,
      effectiveness,
      powerUsed: powerUsageWattHours,
      sideEffects
    };
    
    // Update statistics
    this.stats.totalDisruptions++;
    this.stats.successfulDisruptions++;
    this.stats.totalPowerUsed += powerUsageWattHours;
    this.stats.lastDisruptionTime = new Date();
    
    // Update strongest disruption if applicable
    const strengthRank = this.getStrengthRank(strength);
    const currentStrongestRank = this.getStrengthRank(this.stats.strongestDisruption);
    
    if (strengthRank > currentStrongestRank) {
      this.stats.strongestDisruption = strength;
    }
    
    // Update longest disruption if applicable
    if (disruptionDuration !== Infinity && disruptionDuration > this.stats.longestDisruption) {
      this.stats.longestDisruption = disruptionDuration;
    }
    
    // Update average effectiveness
    this.stats.averageEffectiveness = 
      (this.stats.averageEffectiveness * (this.stats.successfulDisruptions - 1) + effectiveness) / 
      this.stats.successfulDisruptions;
    
    // Update most effective pattern if this was very effective
    if (effectiveness > 90) {
      this.stats.mostEffectivePattern = pattern;
    }
    
    // Add to results
    this.results.push(result);
    
    // If persistent and not neutralized, setup timeout for next disruption pulse
    if (disruptionDuration === Infinity && !neutralized) {
      const pulseTimeout = setTimeout(() => {
        this.pulsateDisruption(signature.id);
      }, this.config.pulseInterval);
      
      this.activeDisruptions.set(signature.id, pulseTimeout);
    } else if (disruptionDuration !== Infinity && !neutralized) {
      // Set timeout to end disruption
      const endTimeout = setTimeout(() => {
        this.activeDisruptions.delete(signature.id);
        log(`📡🚫 [FREQ-DISRUPT] DISRUPTION ENDED FOR: ${signature.id}`);
      }, disruptionDuration);
      
      this.activeDisruptions.set(signature.id, endTimeout);
    }
    
    log(`📡🚫 [FREQ-DISRUPT] DISRUPTION INITIATED`);
    log(`📡🚫 [FREQ-DISRUPT] TARGET FREQUENCY: ${signature.centralFrequency} GHz`);
    log(`📡🚫 [FREQ-DISRUPT] EFFECTIVENESS: ${effectiveness.toFixed(1)}%`);
    log(`📡🚫 [FREQ-DISRUPT] POWER USAGE: ${powerUsageWattHours.toFixed(2)} WATT-HOURS`);
    log(`📡🚫 [FREQ-DISRUPT] NEUTRALIZED: ${neutralized ? 'YES' : 'NO'}`);
    
    if (sideEffects.length > 0) {
      log(`📡🚫 [FREQ-DISRUPT] SIDE EFFECTS: ${sideEffects.join(', ')}`);
    }
    
    return result;
  }
  
  /**
   * Pulsate disruption for persistent mode
   */
  private async pulsateDisruption(signatureId: string): Promise<void> {
    // Check if signature still exists and isn't neutralized
    const signature = this.signatures.find(s => s.id === signatureId && !s.completelyNeutralized);
    
    if (!signature) {
      // Signature no longer exists or is neutralized, stop pulsing
      this.activeDisruptions.delete(signatureId);
      return;
    }
    
    // Re-apply disruption with adaptive pattern if enabled
    let pattern = this.config.pattern;
    let strength = this.config.strength;
    
    if (this.config.adaptivePatterns && signature.disruptionAttempts > 1) {
      // Change pattern based on previous attempts
      const patterns: DisruptionPattern[] = ['Inverse', 'Cancellation', 'Scrambling', 'Phase-Shift', 'Quantum-Collapse'];
      const currentIndex = patterns.indexOf(pattern);
      const nextIndex = (currentIndex + 1) % patterns.length;
      pattern = patterns[nextIndex];
      
      // Potentially increase strength
      if (signature.disruptionAttempts > 3 && strength !== 'Annihilation') {
        const strengths: DisruptionStrength[] = ['Low', 'Medium', 'High', 'Maximum', 'Annihilation'];
        const currentStrengthIndex = strengths.indexOf(strength);
        strength = strengths[Math.min(currentStrengthIndex + 1, strengths.length - 1)];
      }
    }
    
    // Apply next pulse
    const result = await this.disruptSignature(signatureId, undefined, pattern, strength);
    
    if (!result.success || result.neutralized) {
      // Stop pulsing if unsuccessful or neutralized
      this.activeDisruptions.delete(signatureId);
    }
  }
  
  /**
   * Execute full neutralization sweep
   */
  public async executeFullNeutralization(): Promise<{
    success: boolean;
    message: string;
    signaturesProcessed: number;
    signaturesNeutralized: number;
    totalSignaturesNeutralized: number;
    powerUsed: number;
  }> {
    log(`📡🚫 [FREQ-DISRUPT] EXECUTING FULL NEUTRALIZATION SWEEP...`);
    
    // Check if system is active
    if (!this.active) {
      log(`📡🚫 [FREQ-DISRUPT] ERROR: SYSTEM NOT ACTIVE`);
      
      return {
        success: false,
        message: 'Frequency Disruptor is not active. Activate the system before executing neutralization.',
        signaturesProcessed: 0,
        signaturesNeutralized: 0,
        totalSignaturesNeutralized: this.stats.totalSignaturesNeutralized,
        powerUsed: 0
      };
    }
    
    // Store original settings
    const originalPattern = this.config.pattern;
    const originalStrength = this.config.strength;
    
    // Force maximum settings
    this.config.pattern = 'Quantum-Collapse';
    this.config.strength = 'Annihilation';
    
    // Perform new scan to find any signatures
    await this.scanFrequencies();
    
    // Get active signatures
    const activeSignatures = this.signatures.filter(s => !s.completelyNeutralized);
    
    log(`📡🚫 [FREQ-DISRUPT] FOUND ${activeSignatures.length} ACTIVE SIGNATURES TO NEUTRALIZE`);
    
    let neutralized = 0;
    let totalPowerUsed = 0;
    
    // Process each signature
    for (const signature of activeSignatures) {
      // Clear any existing disruption
      if (this.activeDisruptions.has(signature.id)) {
        clearTimeout(this.activeDisruptions.get(signature.id)!);
        this.activeDisruptions.delete(signature.id);
      }
      
      // Apply maximum disruption
      const result = await this.disruptSignature(
        signature.id,
        10000, // 10 seconds at maximum power
        'Quantum-Collapse',
        'Annihilation'
      );
      
      if (result.neutralized) {
        neutralized++;
      }
      
      totalPowerUsed += result.powerUsed;
    }
    
    // Restore original settings
    this.config.pattern = originalPattern;
    this.config.strength = originalStrength;
    
    log(`📡🚫 [FREQ-DISRUPT] NEUTRALIZATION SWEEP COMPLETE`);
    log(`📡🚫 [FREQ-DISRUPT] SIGNATURES PROCESSED: ${activeSignatures.length}`);
    log(`📡🚫 [FREQ-DISRUPT] SIGNATURES NEUTRALIZED: ${neutralized}`);
    log(`📡🚫 [FREQ-DISRUPT] POWER USED: ${totalPowerUsed.toFixed(2)} WATT-HOURS`);
    log(`📡🚫 [FREQ-DISRUPT] TOTAL SIGNATURES NEUTRALIZED: ${this.stats.totalSignaturesNeutralized}`);
    
    return {
      success: true,
      message: `Full neutralization sweep completed successfully. ${neutralized} signatures neutralized.`,
      signaturesProcessed: activeSignatures.length,
      signaturesNeutralized: neutralized,
      totalSignaturesNeutralized: this.stats.totalSignaturesNeutralized,
      powerUsed: totalPowerUsed
    };
  }
  
  /**
   * Set disruption configuration
   */
  public setConfiguration(
    config: Partial<DisruptionConfig>
  ): {
    success: boolean;
    message: string;
    previousConfig: DisruptionConfig;
    currentConfig: DisruptionConfig;
    changedSettings: string[];
  } {
    log(`📡🚫 [FREQ-DISRUPT] UPDATING DISRUPTION CONFIGURATION...`);
    
    // Store previous config
    const previousConfig = { ...this.config };
    
    // Track changed settings
    const changedSettings: string[] = [];
    
    // Update all provided settings
    Object.entries(config).forEach(([key, value]) => {
      const configKey = key as keyof DisruptionConfig;
      
      // Check if value is different
      if (value !== undefined && value !== this.config[configKey]) {
        // Mark as changed
        changedSettings.push(key);
        
        // Handle special case for targetRange to maintain precision
        if (configKey === 'targetRange' && typeof value === 'object') {
          const newRange = value as Partial<FrequencyRange>;
          
          if (newRange.min !== undefined && newRange.min !== this.config.targetRange.min) {
            this.config.targetRange.min = newRange.min;
          }
          
          if (newRange.max !== undefined && newRange.max !== this.config.targetRange.max) {
            this.config.targetRange.max = newRange.max;
          }
          
          if (newRange.precision !== undefined && newRange.precision !== this.config.targetRange.precision) {
            this.config.targetRange.precision = newRange.precision;
          }
        } else {
          // Normal update for other settings
          (this.config as any)[configKey] = value;
        }
      }
    });
    
    log(`📡🚫 [FREQ-DISRUPT] CONFIGURATION UPDATED`);
    changedSettings.forEach(setting => {
      log(`📡🚫 [FREQ-DISRUPT] UPDATED: ${setting}`);
    });
    
    return {
      success: true,
      message: `Disruption configuration updated successfully. ${changedSettings.length} settings changed.`,
      previousConfig,
      currentConfig: { ...this.config },
      changedSettings
    };
  }
  
  /**
   * Get system state and statistics
   */
  public getStatus(): {
    active: boolean;
    disrupting: boolean;
    config: DisruptionConfig;
    stats: DisruptionStats;
    signatureStats: {
      total: number;
      active: number;
      neutralized: number;
      currentlyDisrupting: number;
    };
    powerStats: {
      enginePower: number;
      totalPowerUsed: number;
      currentPowerDraw: number;
    };
    archlinkIntegration: boolean;
  } {
    const activeSignatures = this.signatures.filter(s => !s.completelyNeutralized).length;
    const neutralizedSignatures = this.signatures.filter(s => s.completelyNeutralized).length;
    
    // Calculate current power draw based on active disruptions
    const currentPowerDraw = this.activeDisruptions.size > 0 ?
      this.enginePower * this.getPowerFactor(this.config.strength) * this.activeDisruptions.size * 0.7 : 0;
    
    return {
      active: this.active,
      disrupting: this.disrupting,
      config: { ...this.config },
      stats: { ...this.stats },
      signatureStats: {
        total: this.signatures.length,
        active: activeSignatures,
        neutralized: neutralizedSignatures,
        currentlyDisrupting: this.activeDisruptions.size
      },
      powerStats: {
        enginePower: this.enginePower,
        totalPowerUsed: this.stats.totalPowerUsed,
        currentPowerDraw
      },
      archlinkIntegration: this.archlinkIntegrated
    };
  }
  
  /**
   * Get all frequency signatures
   */
  public getFrequencySignatures(): FrequencySignature[] {
    return [...this.signatures];
  }
  
  /**
   * Get all disruption results
   */
  public getDisruptionResults(): DisruptionResult[] {
    return [...this.results];
  }
  
  /**
   * Check if system is active
   */
  public isActive(): boolean {
    return this.active;
  }
  
  /**
   * Check if currently disrupting
   */
  public isDisrupting(): boolean {
    return this.disrupting;
  }
  
  /**
   * Get strength factor for calculations
   */
  private getStrengthFactor(strength: DisruptionStrength): number {
    switch (strength) {
      case 'Low':
        return 0.7;
      case 'Medium':
        return 0.85;
      case 'High':
        return 1.0;
      case 'Maximum':
        return 1.2;
      case 'Annihilation':
        return 1.5;
      default:
        return 1.0;
    }
  }
  
  /**
   * Get pattern factor for calculations based on entity type
   */
  private getPatternFactor(pattern: DisruptionPattern, entityType: EntityFrequencyType): number {
    // Different patterns are more effective against different entity types
    const patternEffectiveness: Record<DisruptionPattern, Record<EntityFrequencyType, number>> = {
      'Inverse': {
        'Digital': 1.1,
        'Analog': 1.2,
        'Quantum': 0.8,
        'Psychic': 0.7,
        'Dimensional': 0.6,
        'Hybrid': 0.9
      },
      'Cancellation': {
        'Digital': 1.0,
        'Analog': 1.3,
        'Quantum': 0.9,
        'Psychic': 0.8,
        'Dimensional': 0.7,
        'Hybrid': 1.0
      },
      'Scrambling': {
        'Digital': 1.3,
        'Analog': 1.0,
        'Quantum': 0.9,
        'Psychic': 1.1,
        'Dimensional': 0.8,
        'Hybrid': 1.0
      },
      'Phase-Shift': {
        'Digital': 1.0,
        'Analog': 1.1,
        'Quantum': 1.2,
        'Psychic': 1.0,
        'Dimensional': 1.1,
        'Hybrid': 1.1
      },
      'Quantum-Collapse': {
        'Digital': 1.1,
        'Analog': 1.0,
        'Quantum': 1.5,
        'Psychic': 1.2,
        'Dimensional': 1.4,
        'Hybrid': 1.3
      }
    };
    
    return patternEffectiveness[pattern][entityType];
  }
  
  /**
   * Get power factor for calculations
   */
  private getPowerFactor(strength: DisruptionStrength): number {
    switch (strength) {
      case 'Low':
        return 0.2;
      case 'Medium':
        return 0.4;
      case 'High':
        return 0.6;
      case 'Maximum':
        return 0.8;
      case 'Annihilation':
        return 1.0;
      default:
        return 0.5;
    }
  }
  
  /**
   * Get strength rank for comparisons
   */
  private getStrengthRank(strength: DisruptionStrength): number {
    switch (strength) {
      case 'Low':
        return 1;
      case 'Medium':
        return 2;
      case 'High':
        return 3;
      case 'Maximum':
        return 4;
      case 'Annihilation':
        return 5;
      default:
        return 0;
    }
  }
  
  /**
   * Calculate potential side effects
   */
  private calculateSideEffects(
    pattern: DisruptionPattern,
    strength: DisruptionStrength,
    effectiveness: number
  ): string[] {
    const sideEffects: string[] = [];
    
    // More powerful disruptions have more side effects
    if (strength === 'Annihilation') {
      if (Math.random() < 0.7) {
        sideEffects.push('Temporary local EM interference');
      }
      
      if (Math.random() < 0.5) {
        sideEffects.push('Minor reality fluctuations');
      }
      
      if (Math.random() < 0.3) {
        sideEffects.push('Increased power consumption');
      }
    } else if (strength === 'Maximum') {
      if (Math.random() < 0.5) {
        sideEffects.push('Brief local EM interference');
      }
      
      if (Math.random() < 0.3) {
        sideEffects.push('Increased power consumption');
      }
    }
    
    // Pattern-specific side effects
    if (pattern === 'Quantum-Collapse' && Math.random() < 0.4) {
      sideEffects.push('Quantum entanglement residue');
    }
    
    if (pattern === 'Phase-Shift' && Math.random() < 0.3) {
      sideEffects.push('Temporal echo');
    }
    
    // Low effectiveness can cause instability
    if (effectiveness < 50 && Math.random() < 0.5) {
      sideEffects.push('Disruption instability');
    }
    
    return sideEffects;
  }
}

// Initialize and export the frequency disruptor
const frequencyDisruptor = FrequencyDisruptor.getInstance();

export {
  frequencyDisruptor,
  type FrequencyRange,
  type DisruptionPattern,
  type DisruptionMode,
  type DisruptionStrength,
  type EntityFrequencyType,
  type FrequencySignature,
  type DisruptionConfig,
  type DisruptionResult,
  type DisruptionStats
};