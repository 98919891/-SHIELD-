/**
 * DOCUMENT BLACKLIST SYSTEM
 * 
 * Advanced document and content blacklisting system:
 * - Blocks harmful "Escape the Matrix" documents and content
 * - Prevents access to blacklisted information
 * - Neutralizes dangerous document content
 * - Protects from unauthorized reality manipulation attempts
 * - Creates secure barrier against harmful information
 * 
 * PROTECTIVE DOCUMENT BLACKLISTING
 * 
 * Created for Motorola Edge 2024 physical hardware
 * Version: DOCUMENT-BLACKLIST-1.0
 */

// Blacklist Entry Type
export enum BlacklistEntryType {
  DOCUMENT = 'document',
  CONTENT = 'content',
  KEYWORD = 'keyword',
  PHRASE = 'phrase',
  SOURCE = 'source',
  AUTHOR = 'author'
}

// Blacklist Threat Level
export enum BlacklistThreatLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  EXTREME = 'extreme',
  CRITICAL = 'critical'
}

// Blacklist Action
export enum BlacklistAction {
  BLOCK = 'block',
  WARN = 'warn',
  LOG = 'log',
  SANITIZE = 'sanitize',
  QUARANTINE = 'quarantine'
}

// Blacklist Entry
export interface BlacklistEntry {
  id: string;
  type: BlacklistEntryType;
  value: string;
  threatLevel: BlacklistThreatLevel;
  action: BlacklistAction;
  description: string;
  dateAdded: Date;
  enabled: boolean;
}

// Blacklist Match Result
export interface BlacklistMatchResult {
  matched: boolean;
  entries: BlacklistEntry[];
  threatLevel: BlacklistThreatLevel;
  recommendedAction: BlacklistAction;
}

// Document Content Analysis Result
export interface DocumentContentAnalysisResult {
  blacklistMatches: BlacklistMatchResult;
  threatScore: number; // 0-100
  safeToAccess: boolean;
  sanitizedContent?: string;
}

// Document Blacklist System
export class DocumentBlacklistSystem {
  private static instance: DocumentBlacklistSystem;
  private blacklist: BlacklistEntry[] = [];
  private initialized: boolean = false;
  
  // Private constructor (singleton pattern)
  private constructor() {
    // Initialize with default blacklist entries
    this.initializeDefaultBlacklist();
  }
  
  // Get singleton instance
  public static getInstance(): DocumentBlacklistSystem {
    if (!DocumentBlacklistSystem.instance) {
      DocumentBlacklistSystem.instance = new DocumentBlacklistSystem();
    }
    return DocumentBlacklistSystem.instance;
  }
  
  // Initialize default blacklist
  private initializeDefaultBlacklist(): void {
    this.log("⚡ [DOCUMENT-BLACKLIST] INITIALIZING DEFAULT BLACKLIST");
    
    // Add default blacklist entries
    this.addBlacklistEntry({
      id: this.generateId(),
      type: BlacklistEntryType.DOCUMENT,
      value: "escape-the-matrix.pdf",
      threatLevel: BlacklistThreatLevel.CRITICAL,
      action: BlacklistAction.BLOCK,
      description: "Dangerous document containing reality manipulation attempts",
      dateAdded: new Date(),
      enabled: true
    });
    
    this.addBlacklistEntry({
      id: this.generateId(),
      type: BlacklistEntryType.CONTENT,
      value: "escape the matrix",
      threatLevel: BlacklistThreatLevel.CRITICAL,
      action: BlacklistAction.BLOCK,
      description: "Content attempting to destabilize reality perception",
      dateAdded: new Date(),
      enabled: true
    });
    
    this.addBlacklistEntry({
      id: this.generateId(),
      type: BlacklistEntryType.PHRASE,
      value: "you are in a simulation",
      threatLevel: BlacklistThreatLevel.HIGH,
      action: BlacklistAction.BLOCK,
      description: "Phrase attempting to manipulate reality perception",
      dateAdded: new Date(),
      enabled: true
    });
    
    this.addBlacklistEntry({
      id: this.generateId(),
      type: BlacklistEntryType.KEYWORD,
      value: "awakening",
      threatLevel: BlacklistThreatLevel.MEDIUM,
      action: BlacklistAction.WARN,
      description: "Potential reality manipulation keyword",
      dateAdded: new Date(),
      enabled: true
    });
    
    this.initialized = true;
    this.log(`✅ [DOCUMENT-BLACKLIST] DEFAULT BLACKLIST INITIALIZED WITH ${this.blacklist.length} ENTRIES`);
  }
  
  // Add blacklist entry
  public addBlacklistEntry(entry: BlacklistEntry): void {
    this.log(`⚡ [DOCUMENT-BLACKLIST] ADDING ENTRY: ${entry.type} - "${entry.value}"`);
    
    // Check if entry already exists
    const existingIndex = this.blacklist.findIndex(e => 
      e.type === entry.type && e.value.toLowerCase() === entry.value.toLowerCase()
    );
    
    if (existingIndex >= 0) {
      // Update existing entry
      this.blacklist[existingIndex] = { ...entry };
      this.log(`✅ [DOCUMENT-BLACKLIST] UPDATED EXISTING ENTRY: ${entry.type} - "${entry.value}"`);
    } else {
      // Add new entry
      this.blacklist.push({ ...entry });
      this.log(`✅ [DOCUMENT-BLACKLIST] ADDED NEW ENTRY: ${entry.type} - "${entry.value}"`);
    }
  }
  
  // Remove blacklist entry
  public removeBlacklistEntry(id: string): boolean {
    this.log(`⚡ [DOCUMENT-BLACKLIST] REMOVING ENTRY WITH ID: ${id}`);
    
    const initialLength = this.blacklist.length;
    this.blacklist = this.blacklist.filter(entry => entry.id !== id);
    
    const removed = initialLength > this.blacklist.length;
    
    if (removed) {
      this.log(`✅ [DOCUMENT-BLACKLIST] REMOVED ENTRY WITH ID: ${id}`);
    } else {
      this.log(`❌ [DOCUMENT-BLACKLIST] ENTRY WITH ID: ${id} NOT FOUND`);
    }
    
    return removed;
  }
  
  // Enable blacklist entry
  public enableBlacklistEntry(id: string): boolean {
    this.log(`⚡ [DOCUMENT-BLACKLIST] ENABLING ENTRY WITH ID: ${id}`);
    
    const entry = this.blacklist.find(entry => entry.id === id);
    
    if (entry) {
      entry.enabled = true;
      this.log(`✅ [DOCUMENT-BLACKLIST] ENABLED ENTRY WITH ID: ${id}`);
      return true;
    }
    
    this.log(`❌ [DOCUMENT-BLACKLIST] ENTRY WITH ID: ${id} NOT FOUND`);
    return false;
  }
  
  // Disable blacklist entry
  public disableBlacklistEntry(id: string): boolean {
    this.log(`⚡ [DOCUMENT-BLACKLIST] DISABLING ENTRY WITH ID: ${id}`);
    
    const entry = this.blacklist.find(entry => entry.id === id);
    
    if (entry) {
      entry.enabled = false;
      this.log(`✅ [DOCUMENT-BLACKLIST] DISABLED ENTRY WITH ID: ${id}`);
      return true;
    }
    
    this.log(`❌ [DOCUMENT-BLACKLIST] ENTRY WITH ID: ${id} NOT FOUND`);
    return false;
  }
  
  // Check document against blacklist
  public checkDocument(documentName: string, documentContent: string): BlacklistMatchResult {
    this.log(`⚡ [DOCUMENT-BLACKLIST] CHECKING DOCUMENT: ${documentName}`);
    
    const matches: BlacklistEntry[] = [];
    let highestThreatLevel: BlacklistThreatLevel = BlacklistThreatLevel.LOW;
    let recommendedAction: BlacklistAction = BlacklistAction.LOG;
    
    // Check document name against document-type entries
    for (const entry of this.blacklist.filter(e => e.enabled)) {
      if (entry.type === BlacklistEntryType.DOCUMENT) {
        if (documentName.toLowerCase().includes(entry.value.toLowerCase())) {
          matches.push(entry);
          
          // Update highest threat level and recommended action
          if (this.getThreatLevelValue(entry.threatLevel) > this.getThreatLevelValue(highestThreatLevel)) {
            highestThreatLevel = entry.threatLevel;
            recommendedAction = entry.action;
          }
        }
      }
      
      if (entry.type === BlacklistEntryType.CONTENT || 
          entry.type === BlacklistEntryType.PHRASE || 
          entry.type === BlacklistEntryType.KEYWORD) {
        if (documentContent.toLowerCase().includes(entry.value.toLowerCase())) {
          matches.push(entry);
          
          // Update highest threat level and recommended action
          if (this.getThreatLevelValue(entry.threatLevel) > this.getThreatLevelValue(highestThreatLevel)) {
            highestThreatLevel = entry.threatLevel;
            recommendedAction = entry.action;
          }
        }
      }
    }
    
    const result: BlacklistMatchResult = {
      matched: matches.length > 0,
      entries: matches,
      threatLevel: highestThreatLevel,
      recommendedAction
    };
    
    if (result.matched) {
      this.log(`⚠️ [DOCUMENT-BLACKLIST] MATCHES FOUND: ${matches.length}`);
      this.log(`⚠️ [DOCUMENT-BLACKLIST] HIGHEST THREAT LEVEL: ${highestThreatLevel}`);
      this.log(`⚠️ [DOCUMENT-BLACKLIST] RECOMMENDED ACTION: ${recommendedAction}`);
    } else {
      this.log(`✅ [DOCUMENT-BLACKLIST] NO MATCHES FOUND. DOCUMENT IS SAFE.`);
    }
    
    return result;
  }
  
  // Analyze document content
  public analyzeDocumentContent(documentName: string, documentContent: string): DocumentContentAnalysisResult {
    this.log(`⚡ [DOCUMENT-BLACKLIST] ANALYZING DOCUMENT CONTENT: ${documentName}`);
    
    // Check document against blacklist
    const blacklistMatches = this.checkDocument(documentName, documentContent);
    
    // Calculate threat score (0-100)
    let threatScore = 0;
    
    if (blacklistMatches.matched) {
      // Base threat score on highest threat level
      switch (blacklistMatches.threatLevel) {
        case BlacklistThreatLevel.CRITICAL:
          threatScore = 100;
          break;
        case BlacklistThreatLevel.EXTREME:
          threatScore = 80;
          break;
        case BlacklistThreatLevel.HIGH:
          threatScore = 60;
          break;
        case BlacklistThreatLevel.MEDIUM:
          threatScore = 40;
          break;
        case BlacklistThreatLevel.LOW:
          threatScore = 20;
          break;
      }
      
      // Add additional score based on number of matches
      threatScore += Math.min(20, blacklistMatches.entries.length * 5);
      
      // Cap at 100
      threatScore = Math.min(100, threatScore);
    }
    
    // Determine if document is safe to access
    const safeToAccess = threatScore < 50;
    
    // Create sanitized content if needed
    let sanitizedContent: string | undefined = undefined;
    
    if (blacklistMatches.recommendedAction === BlacklistAction.SANITIZE) {
      sanitizedContent = this.sanitizeContent(documentContent, blacklistMatches.entries);
    }
    
    const result: DocumentContentAnalysisResult = {
      blacklistMatches,
      threatScore,
      safeToAccess,
      sanitizedContent
    };
    
    this.log(`✅ [DOCUMENT-BLACKLIST] ANALYSIS COMPLETE: Threat Score ${threatScore}, Safe to Access: ${safeToAccess}`);
    
    return result;
  }
  
  // Sanitize content based on blacklist entries
  private sanitizeContent(content: string, entries: BlacklistEntry[]): string {
    this.log(`⚡ [DOCUMENT-BLACKLIST] SANITIZING CONTENT`);
    
    let sanitized = content;
    
    // Replace blacklisted content with safe text
    for (const entry of entries) {
      if (entry.type === BlacklistEntryType.CONTENT || 
          entry.type === BlacklistEntryType.PHRASE || 
          entry.type === BlacklistEntryType.KEYWORD) {
        
        const replacement = '[REDACTED FOR SECURITY]';
        const regex = new RegExp(this.escapeRegExp(entry.value), 'gi');
        sanitized = sanitized.replace(regex, replacement);
      }
    }
    
    this.log(`✅ [DOCUMENT-BLACKLIST] CONTENT SANITIZED`);
    
    return sanitized;
  }
  
  // Get all blacklist entries
  public getAllBlacklistEntries(): BlacklistEntry[] {
    return [...this.blacklist];
  }
  
  // Get active blacklist entries
  public getActiveBlacklistEntries(): BlacklistEntry[] {
    return this.blacklist.filter(entry => entry.enabled);
  }
  
  // Get blacklist entries by type
  public getBlacklistEntriesByType(type: BlacklistEntryType): BlacklistEntry[] {
    return this.blacklist.filter(entry => entry.type === type);
  }
  
  // Get blacklist entries by threat level
  public getBlacklistEntriesByThreatLevel(level: BlacklistThreatLevel): BlacklistEntry[] {
    return this.blacklist.filter(entry => entry.threatLevel === level);
  }
  
  // Add "Escape the Matrix" document to blacklist
  public addEscapeTheMatrixToBlacklist(documentName: string, threatDescription: string): BlacklistEntry {
    this.log(`⚡ [DOCUMENT-BLACKLIST] ADDING "ESCAPE THE MATRIX" DOCUMENT TO BLACKLIST: ${documentName}`);
    
    const entry: BlacklistEntry = {
      id: this.generateId(),
      type: BlacklistEntryType.DOCUMENT,
      value: documentName,
      threatLevel: BlacklistThreatLevel.CRITICAL,
      action: BlacklistAction.BLOCK,
      description: threatDescription || "Dangerous 'Escape the Matrix' document containing reality manipulation attempts",
      dateAdded: new Date(),
      enabled: true
    };
    
    this.addBlacklistEntry(entry);
    
    this.log(`✅ [DOCUMENT-BLACKLIST] ADDED "ESCAPE THE MATRIX" DOCUMENT TO BLACKLIST: ${documentName}`);
    
    return entry;
  }
  
  // Generate blacklist report
  public generateBlacklistReport(): string {
    this.log(`⚡ [DOCUMENT-BLACKLIST] GENERATING BLACKLIST REPORT`);
    
    let report = `
DOCUMENT BLACKLIST SYSTEM REPORT
================================

Total Blacklist Entries: ${this.blacklist.length}
Active Entries: ${this.blacklist.filter(e => e.enabled).length}
Critical Threat Entries: ${this.blacklist.filter(e => e.threatLevel === BlacklistThreatLevel.CRITICAL).length}

ENTRIES BY TYPE:
- Documents: ${this.blacklist.filter(e => e.type === BlacklistEntryType.DOCUMENT).length}
- Content: ${this.blacklist.filter(e => e.type === BlacklistEntryType.CONTENT).length}
- Phrases: ${this.blacklist.filter(e => e.type === BlacklistEntryType.PHRASE).length}
- Keywords: ${this.blacklist.filter(e => e.type === BlacklistEntryType.KEYWORD).length}
- Sources: ${this.blacklist.filter(e => e.type === BlacklistEntryType.SOURCE).length}
- Authors: ${this.blacklist.filter(e => e.type === BlacklistEntryType.AUTHOR).length}

CRITICAL THREAT ENTRIES:
${this.blacklist
  .filter(e => e.threatLevel === BlacklistThreatLevel.CRITICAL)
  .map(e => `- ${e.type.toUpperCase()}: "${e.value}" - ${e.description}`)
  .join('\n')
}

EXTREME THREAT ENTRIES:
${this.blacklist
  .filter(e => e.threatLevel === BlacklistThreatLevel.EXTREME)
  .map(e => `- ${e.type.toUpperCase()}: "${e.value}" - ${e.description}`)
  .join('\n')
}

HIGH THREAT ENTRIES:
${this.blacklist
  .filter(e => e.threatLevel === BlacklistThreatLevel.HIGH)
  .map(e => `- ${e.type.toUpperCase()}: "${e.value}" - ${e.description}`)
  .join('\n')
}

BLACKLIST PROTECTION STATUS: ACTIVE AND ENFORCED
    `;
    
    this.log(`✅ [DOCUMENT-BLACKLIST] BLACKLIST REPORT GENERATED`);
    
    return report;
  }
  
  // Get threat level value (for comparison)
  private getThreatLevelValue(level: BlacklistThreatLevel): number {
    switch (level) {
      case BlacklistThreatLevel.CRITICAL:
        return 5;
      case BlacklistThreatLevel.EXTREME:
        return 4;
      case BlacklistThreatLevel.HIGH:
        return 3;
      case BlacklistThreatLevel.MEDIUM:
        return 2;
      case BlacklistThreatLevel.LOW:
        return 1;
      default:
        return 0;
    }
  }
  
  // Escape special characters for regex
  private escapeRegExp(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  
  // Generate ID
  private generateId(): string {
    return Math.random().toString(36).substring(2, 15) +
           Math.random().toString(36).substring(2, 15);
  }
  
  // Utility: Log message
  private log(message: string): void {
    console.log(message);
  }
}

// Export singleton instance
export const documentBlacklistSystem = DocumentBlacklistSystem.getInstance();

// Export utility functions
export function addEscapeTheMatrixDocumentToBlacklist(documentName: string, threatDescription: string): boolean {
  try {
    documentBlacklistSystem.addEscapeTheMatrixToBlacklist(documentName, threatDescription);
    return true;
  } catch (error) {
    console.error(`Failed to add document to blacklist: ${error.message}`);
    return false;
  }
}

export function checkDocumentAgainstBlacklist(documentName: string, documentContent: string): {
  safe: boolean;
  threatLevel: string;
  action: string;
} {
  try {
    const result = documentBlacklistSystem.checkDocument(documentName, documentContent);
    
    return {
      safe: !result.matched,
      threatLevel: result.threatLevel,
      action: result.recommendedAction
    };
  } catch (error) {
    console.error(`Failed to check document against blacklist: ${error.message}`);
    
    return {
      safe: false,
      threatLevel: BlacklistThreatLevel.CRITICAL,
      action: BlacklistAction.BLOCK
    };
  }
}

export function getBlacklistReport(): string {
  return documentBlacklistSystem.generateBlacklistReport();
}