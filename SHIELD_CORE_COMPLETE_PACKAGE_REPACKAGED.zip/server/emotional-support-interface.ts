/**
 * EMOTIONAL SUPPORT INTERFACE
 * 
 * User interface for the Emotional Support AI Companion:
 * - Provides simple methods to access emotional support
 * - Integrates with Shield Core for secure emotional processing
 * - Enables interaction with the emotional support system
 * - Maintains privacy and protection of emotional data
 * - Ensures compassionate response to emotional needs
 * 
 * SECURE ACCESS TO EMOTIONAL SUPPORT
 * 
 * Created for Motorola Edge 2024 hardware
 * Version: EMOTIONAL-INTERFACE-1.0
 */

import { 
  emotionalSupportCompanionSystem, 
  EmotionalState, 
  MemoryProtectionLevel, 
  SupportType
} from './emotional-support-companion-system';

// Simplified emotional states for easier user input
export enum SimpleEmotionalState {
  GOOD = 'good',
  NEUTRAL = 'neutral',
  BAD = 'bad',
  ANXIOUS = 'anxious',
  ANGRY = 'angry',
  SAD = 'sad',
  UNCERTAIN = 'uncertain',
  HOPEFUL = 'hopeful'
}

// Emotional Support Request
interface EmotionalSupportRequest {
  emotionalState: SimpleEmotionalState;
  details?: string;
  urgency?: number; // 1-10
  preferredSupportTypes?: SupportType[];
}

// Emotional Support Response
interface EmotionalSupportResponse {
  supportMessage: string;
  suggestedStrategies: string[];
  memoryProtectionStatus: string;
  sessionId: string;
}

// Emotional Support Interface
export class EmotionalSupportInterface {
  private static instance: EmotionalSupportInterface;
  private activeSessionId: string | null = null;
  private lastEmotionalState: SimpleEmotionalState = SimpleEmotionalState.NEUTRAL;
  private initialized: boolean = false;
  
  // Private constructor (singleton pattern)
  private constructor() {
    // Initialize with empty state
  }
  
  // Get singleton instance
  public static getInstance(): EmotionalSupportInterface {
    if (!EmotionalSupportInterface.instance) {
      EmotionalSupportInterface.instance = new EmotionalSupportInterface();
    }
    return EmotionalSupportInterface.instance;
  }
  
  // Initialize the interface
  public async initialize(): Promise<boolean> {
    this.log("⚡ [EMOTIONAL-INTERFACE] INITIALIZING EMOTIONAL SUPPORT INTERFACE");
    
    if (this.initialized) {
      this.log("✅ [EMOTIONAL-INTERFACE] ALREADY INITIALIZED");
      return true;
    }
    
    try {
      // Initialize emotional support system
      await emotionalSupportCompanionSystem.initialize();
      
      this.initialized = true;
      
      this.log("✅ [EMOTIONAL-INTERFACE] INITIALIZATION COMPLETE");
      
      return true;
    } catch (error) {
      this.logError("Failed to initialize Emotional Support Interface", error);
      return false;
    }
  }
  
  // Request emotional support
  public async requestSupport(
    request: EmotionalSupportRequest
  ): Promise<EmotionalSupportResponse> {
    this.log(`⚡ [EMOTIONAL-INTERFACE] REQUESTING EMOTIONAL SUPPORT FOR STATE: ${request.emotionalState}`);
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Map simple emotional state to detailed state
      const emotionalState = this.mapToDetailedEmotionalState(request.emotionalState);
      
      // Start new session or use existing
      let sessionId = this.activeSessionId;
      
      if (!sessionId) {
        // Begin new session
        const session = await emotionalSupportCompanionSystem.beginSupportSession(emotionalState);
        sessionId = session.id;
        this.activeSessionId = sessionId;
      }
      
      // Get support
      const supportResult = await emotionalSupportCompanionSystem.provideSupportForEmotion(
        sessionId,
        emotionalState,
        request.details || ""
      );
      
      // Format response
      const response: EmotionalSupportResponse = {
        supportMessage: supportResult.supportMessage,
        suggestedStrategies: supportResult.suggestedStrategies.map(s => s.name),
        memoryProtectionStatus: "PROTECTED AT COMMANDER LEVEL",
        sessionId
      };
      
      // Update last emotional state
      this.lastEmotionalState = request.emotionalState;
      
      this.log(`✅ [EMOTIONAL-INTERFACE] EMOTIONAL SUPPORT PROVIDED FOR: ${request.emotionalState}`);
      
      return response;
    } catch (error) {
      this.logError("Failed to provide emotional support", error);
      
      // Return fallback response
      return {
        supportMessage: "I'm here to support you, Commander. Your emotions are valid, and your memories remain protected.",
        suggestedStrategies: ["Take a moment to breathe deeply", "Ground yourself in physical reality"],
        memoryProtectionStatus: "PROTECTED AT COMMANDER LEVEL",
        sessionId: this.activeSessionId || "emergency-session"
      };
    }
  }
  
  // End current support session
  public async endSupportSession(
    finalState: SimpleEmotionalState,
    insights: string[] = []
  ): Promise<boolean> {
    this.log(`⚡ [EMOTIONAL-INTERFACE] ENDING SUPPORT SESSION WITH FINAL STATE: ${finalState}`);
    
    if (!this.activeSessionId) {
      this.log("❌ [EMOTIONAL-INTERFACE] NO ACTIVE SESSION TO END");
      return false;
    }
    
    try {
      // Map simple emotional state to detailed state
      const emotionalState = this.mapToDetailedEmotionalState(finalState);
      
      // End session
      await emotionalSupportCompanionSystem.endSupportSession(
        this.activeSessionId,
        emotionalState,
        insights
      );
      
      // Clear active session
      this.activeSessionId = null;
      
      // Update last emotional state
      this.lastEmotionalState = finalState;
      
      this.log("✅ [EMOTIONAL-INTERFACE] SUPPORT SESSION ENDED SUCCESSFULLY");
      
      return true;
    } catch (error) {
      this.logError("Failed to end support session", error);
      return false;
    }
  }
  
  // Get quick emotional support message
  public async getQuickSupportMessage(
    emotionalState: SimpleEmotionalState
  ): Promise<string> {
    this.log(`⚡ [EMOTIONAL-INTERFACE] GETTING QUICK SUPPORT MESSAGE FOR: ${emotionalState}`);
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      // Request full support
      const supportRequest: EmotionalSupportRequest = {
        emotionalState,
        urgency: 8
      };
      
      const response = await this.requestSupport(supportRequest);
      
      // Return just the message
      return response.supportMessage;
    } catch (error) {
      this.logError("Failed to get quick support message", error);
      
      // Return fallback message
      return "I'm here for you, Commander. Your emotions are valid, and your memories remain protected at all times.";
    }
  }
  
  // Get empathetic memory protection guidance
  public async getMemoryProtectionGuidance(): Promise<string> {
    this.log("⚡ [EMOTIONAL-INTERFACE] GETTING EMPATHETIC MEMORY PROTECTION GUIDANCE");
    
    if (!this.initialized) {
      await this.initialize();
    }
    
    try {
      const guidance = await emotionalSupportCompanionSystem.getEmpatheticMemoryProtectionGuidance();
      return guidance.guidanceMessage;
    } catch (error) {
      this.logError("Failed to get memory protection guidance", error);
      
      // Return fallback guidance
      return "Your emotional memories are safe and protected at the highest level. You can process your feelings knowing your experiences remain secure.";
    }
  }
  
  // Map simple emotional state to detailed emotional state
  private mapToDetailedEmotionalState(simple: SimpleEmotionalState): EmotionalState {
    switch (simple) {
      case SimpleEmotionalState.GOOD:
        return EmotionalState.CONTENT;
      case SimpleEmotionalState.NEUTRAL:
        return EmotionalState.CALM;
      case SimpleEmotionalState.BAD:
        return EmotionalState.UPSET;
      case SimpleEmotionalState.ANXIOUS:
        return EmotionalState.ANXIOUS;
      case SimpleEmotionalState.ANGRY:
        return EmotionalState.ANGRY;
      case SimpleEmotionalState.SAD:
        return EmotionalState.SAD;
      case SimpleEmotionalState.UNCERTAIN:
        return EmotionalState.UNCERTAIN;
      case SimpleEmotionalState.HOPEFUL:
        return EmotionalState.HOPEFUL;
      default:
        return EmotionalState.MIXED;
    }
  }
  
  // Get interface status
  public getStatus(): {
    initialized: boolean;
    activeSession: boolean;
    lastEmotionalState: SimpleEmotionalState;
  } {
    return {
      initialized: this.initialized,
      activeSession: this.activeSessionId !== null,
      lastEmotionalState: this.lastEmotionalState
    };
  }
  
  // Utility: Log message
  private log(message: string): void {
    console.log(message);
  }
  
  // Utility: Log error
  private logError(message: string, error: any): void {
    console.error(`❌ [ERROR] ${message}`, error);
  }
}

// Export singleton instance
export const emotionalSupportInterface = EmotionalSupportInterface.getInstance();

// Export support functions
export async function getSupportForFeeling(
  feeling: SimpleEmotionalState,
  details?: string
): Promise<string> {
  const request: EmotionalSupportRequest = {
    emotionalState: feeling,
    details
  };
  
  const response = await emotionalSupportInterface.requestSupport(request);
  return response.supportMessage;
}

export async function getMemoryProtectionGuidance(): Promise<string> {
  return await emotionalSupportInterface.getMemoryProtectionGuidance();
}