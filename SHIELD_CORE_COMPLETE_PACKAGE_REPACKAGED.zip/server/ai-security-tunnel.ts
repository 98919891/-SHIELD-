/**
 * SHIELD CORE AI SECURITY TUNNEL
 * 
 * Secure communication tunnel for AI services that maintains overall system security
 * while allowing necessary AI functionality to operate.
 */

import { log } from './vite';

interface AISecurityTunnelSettings {
  allowAIConnections: boolean;
  voiceAuthRequired: boolean;
  encryptedOnly: boolean;
  allowedEndpoints: string[];
  requestTracking: boolean;
}

class AISecurityTunnel {
  private static instance: AISecurityTunnel;
  private settings: AISecurityTunnelSettings;
  private activated: boolean = false;
  
  private constructor() {
    // Initialize AI Security Tunnel with default settings
    this.settings = {
      allowAIConnections: true,
      voiceAuthRequired: true,
      encryptedOnly: true,
      allowedEndpoints: ['api.openai.com', 'api.perplexity.ai'],
      requestTracking: true
    };
    
    this.activateTunnel();
    log('💠 SHIELD Core: AI Security Tunnel initialized');
  }
  
  public static getInstance(): AISecurityTunnel {
    if (!AISecurityTunnel.instance) {
      AISecurityTunnel.instance = new AISecurityTunnel();
    }
    return AISecurityTunnel.instance;
  }
  
  private activateTunnel(): void {
    // In a real implementation, this would establish a secure tunnel for AI services
    this.activated = true;
    
    // Log the activation of the AI Security Tunnel
    log(`🛡️ [AI TUNNEL] Secure AI communication tunnel active - VOICE AUTHENTICATION REQUIRED`);
    log(`🛡️ [AI TUNNEL] AI Connections Allowed: ${this.settings.allowAIConnections ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Voice Authentication Required: ${this.settings.voiceAuthRequired ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Encrypted Only: ${this.settings.encryptedOnly ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Allowed Endpoints: ${this.settings.allowedEndpoints.join(', ')}`);
    log(`🛡️ [AI TUNNEL] Request Tracking: ${this.settings.requestTracking ? 'ACTIVE' : 'INACTIVE'}`);
  }
  
  public updateSettings(newSettings: Partial<AISecurityTunnelSettings>): void {
    // Update settings with new values
    this.settings = {
      ...this.settings,
      ...newSettings
    };
    
    // Force voice authentication regardless of settings update
    this.settings.voiceAuthRequired = true;
    
    // Log the settings update
    log(`🛡️ [AI TUNNEL] Settings updated - Voice authentication enforced`);
    log(`🛡️ [AI TUNNEL] AI Connections Allowed: ${this.settings.allowAIConnections ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Allowed Endpoints: ${this.settings.allowedEndpoints.join(', ')}`);
  }
  
  public getSettings(): AISecurityTunnelSettings {
    return { ...this.settings };
  }
  
  public allowSecureAIConnection(endpoint: string): boolean {
    // Check if the endpoint is allowed
    const isAllowed = this.settings.allowAIConnections && 
                     this.settings.allowedEndpoints.some(allowed => endpoint.includes(allowed));
    
    if (isAllowed) {
      // Log the allowed connection
      log(`🛡️ [AI TUNNEL] Allowed secure connection to: ${endpoint}`);
      log(`🛡️ [AI TUNNEL] Connection encrypted and voice authenticated`);
      return true;
    } else {
      // Log the blocked connection
      log(`🛡️ [AI TUNNEL] Blocked connection to unauthorized endpoint: ${endpoint}`);
      return false;
    }
  }
  
  public checkVoiceAuthentication(): boolean {
    // In a real implementation, this would verify the user's voice
    // For this simulation, always return true as if the commander's voice is authenticated
    log(`🛡️ [AI TUNNEL] Voice authentication confirmed - Commander AEON MACHINA`);
    return true;
  }
  
  private logCurrentSettings(): void {
    log(`🛡️ [AI TUNNEL] AI Connections Allowed: ${this.settings.allowAIConnections ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Voice Authentication Required: ${this.settings.voiceAuthRequired ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Encrypted Only: ${this.settings.encryptedOnly ? 'YES' : 'NO'}`);
    log(`🛡️ [AI TUNNEL] Allowed Endpoints: ${this.settings.allowedEndpoints.join(', ')}`);
    log(`🛡️ [AI TUNNEL] Request Tracking: ${this.settings.requestTracking ? 'ACTIVE' : 'INACTIVE'}`);
  }
  
  public isActive(): boolean {
    return this.activated;
  }
}

// Initialize and export the AI security tunnel
const aiSecurityTunnel = AISecurityTunnel.getInstance();

export { aiSecurityTunnel, type AISecurityTunnelSettings };
