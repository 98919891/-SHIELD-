import { db } from '../db';
import {
  thumbprintIdentification,
  driversLicenseIdentification,
  faceIdVerification,
  type ThumbprintIdentification,
  type DriversLicenseIdentification,
  type FaceIdVerification
} from '@shared/schema';
import { eq } from 'drizzle-orm';
import crypto from 'crypto';

/**
 * Advanced Authentication Service
 * 
 * Provides hardware-backed verification with thumbprint identification,
 * driver's license scanning, and face ID for secure server access
 */
export class AdvancedAuthService {
  // Verification constants
  private readonly MIN_FINGERPRINT_QUALITY = 75; // Minimum fingerprint quality score (0-100)
  private readonly MIN_FACE_CONFIDENCE = 85; // Minimum face verification confidence (0-100)
  private readonly LICENSE_VERIFICATION_TIMEOUT_DAYS = 30; // Number of days before license needs re-verification
  
  /**
   * Register a thumbprint for a user
   */
  async registerThumbprint(userId: number, data: {
    thumbprintHash: string,
    fingerprintTemplate: string,
    minutiaePoints: any,
    fingerprintQuality: number,
    fingerprintType: string,
    deviceInfo: any
  }): Promise<ThumbprintIdentification> {
    // Validate fingerprint quality
    if (data.fingerprintQuality < this.MIN_FINGERPRINT_QUALITY) {
      throw new Error(`Fingerprint quality too low: ${data.fingerprintQuality}. Minimum required: ${this.MIN_FINGERPRINT_QUALITY}`);
    }
    
    // Store thumbprint data
    const [thumbprint] = await db.insert(thumbprintIdentification).values({
      userId,
      thumbprintHash: data.thumbprintHash,
      fingerprintTemplate: data.fingerprintTemplate,
      minutiaePoints: data.minutiaePoints,
      fingerprintQuality: data.fingerprintQuality,
      fingerprintType: data.fingerprintType,
      deviceInfo: data.deviceInfo,
      isVerified: false
    }).returning();
    
    return thumbprint;
  }
  
  /**
   * Register a driver's license for a user
   */
  async registerDriversLicense(userId: number, data: {
    licenseNumber: string,
    licenseState: string,
    expiryDate: Date,
    barcodeData: string,
    barcodeHash: string,
    licenseClass?: string,
    licenseStatus?: string
  }): Promise<DriversLicenseIdentification> {
    // Check if license is expired
    const now = new Date();
    if (data.expiryDate < now) {
      throw new Error('Driver\'s license is expired. Cannot register expired license.');
    }
    
    // Basic barcode validation
    if (!this.validateBarcodeData(data.barcodeData)) {
      throw new Error('Invalid driver\'s license barcode data. Please scan again.');
    }
    
    // Store license data
    const [license] = await db.insert(driversLicenseIdentification).values({
      userId,
      licenseNumber: data.licenseNumber,
      licenseState: data.licenseState,
      expiryDate: data.expiryDate,
      barcodeData: data.barcodeData,
      barcodeHash: data.barcodeHash,
      licenseClass: data.licenseClass || null,
      licenseStatus: data.licenseStatus || 'active',
      verificationStatus: 'pending',
      lastVerified: new Date()
    }).returning();
    
    return license;
  }
  
  /**
   * Register face ID for a user
   */
  async registerFaceId(userId: number, data: {
    faceTemplateHash: string,
    faceTemplate: string,
    faceFeatures: any,
    enrollmentSource: string,
    confidenceScore: number
  }): Promise<FaceIdVerification> {
    // Validate face confidence score
    if (data.confidenceScore < this.MIN_FACE_CONFIDENCE) {
      throw new Error(`Face confidence score too low: ${data.confidenceScore}. Minimum required: ${this.MIN_FACE_CONFIDENCE}`);
    }
    
    // Store face ID data
    const [faceId] = await db.insert(faceIdVerification).values({
      userId,
      faceTemplateHash: data.faceTemplateHash,
      faceTemplate: data.faceTemplate,
      faceFeatures: data.faceFeatures,
      enrollmentSource: data.enrollmentSource,
      confidenceScore: data.confidenceScore,
      isVerified: false,
      verificationCount: 0,
      lastVerification: null
    }).returning();
    
    return faceId;
  }
  
  /**
   * Verify thumbprint against stored template
   */
  async verifyThumbprint(userId: number, thumbprintHash: string): Promise<{
    verified: boolean,
    score: number,
    fingerprintType: string
  }> {
    // Get stored thumbprint
    const [storedThumbprint] = await db.select()
      .from(thumbprintIdentification)
      .where(eq(thumbprintIdentification.userId, userId))
      .orderBy(thumbprintIdentification.captureTimestamp, 'desc')
      .limit(1);
      
    if (!storedThumbprint) {
      throw new Error('No thumbprint registered for this user');
    }
    
    // Compare thumbprint hashes
    const verified = storedThumbprint.thumbprintHash === thumbprintHash;
    
    // Update verification status if successful
    if (verified) {
      await db.update(thumbprintIdentification)
        .set({
          isVerified: true,
          lastVerified: new Date()
        })
        .where(eq(thumbprintIdentification.id, storedThumbprint.id));
    }
    
    return {
      verified,
      score: storedThumbprint.fingerprintQuality,
      fingerprintType: storedThumbprint.fingerprintType
    };
  }
  
  /**
   * Verify driver's license against stored data
   */
  async verifyDriversLicense(userId: number, licenseNumber: string, barcodeHash: string): Promise<{
    verified: boolean,
    status: string,
    expiryDate: Date
  }> {
    // Get stored license
    const [storedLicense] = await db.select()
      .from(driversLicenseIdentification)
      .where(eq(driversLicenseIdentification.userId, userId))
      .orderBy(driversLicenseIdentification.scanTimestamp, 'desc')
      .limit(1);
      
    if (!storedLicense) {
      throw new Error('No driver\'s license registered for this user');
    }
    
    // Check license expiry
    const now = new Date();
    if (storedLicense.expiryDate < now) {
      await db.update(driversLicenseIdentification)
        .set({ verificationStatus: 'expired' })
        .where(eq(driversLicenseIdentification.id, storedLicense.id));
        
      return {
        verified: false,
        status: 'expired',
        expiryDate: storedLicense.expiryDate
      };
    }
    
    // Compare license number and barcode hash
    const verified = 
      storedLicense.licenseNumber === licenseNumber && 
      storedLicense.barcodeHash === barcodeHash;
    
    // Update verification status
    if (verified) {
      await db.update(driversLicenseIdentification)
        .set({
          verificationStatus: 'verified',
          lastVerified: new Date()
        })
        .where(eq(driversLicenseIdentification.id, storedLicense.id));
    }
    
    return {
      verified,
      status: verified ? 'verified' : 'failed',
      expiryDate: storedLicense.expiryDate
    };
  }
  
  /**
   * Verify face ID against stored template
   */
  async verifyFaceId(userId: number, faceTemplateHash: string, confidenceScore: number): Promise<{
    verified: boolean,
    score: number,
    enrollmentSource: string
  }> {
    // Get stored face ID
    const [storedFaceId] = await db.select()
      .from(faceIdVerification)
      .where(eq(faceIdVerification.userId, userId))
      .orderBy(faceIdVerification.enrollmentTimestamp, 'desc')
      .limit(1);
      
    if (!storedFaceId) {
      throw new Error('No face ID registered for this user');
    }
    
    // Verify confidence score meets minimum threshold
    if (confidenceScore < this.MIN_FACE_CONFIDENCE) {
      return {
        verified: false,
        score: confidenceScore,
        enrollmentSource: storedFaceId.enrollmentSource
      };
    }
    
    // Compare face template hashes
    const verified = storedFaceId.faceTemplateHash === faceTemplateHash;
    
    // Update verification status if successful
    if (verified) {
      await db.update(faceIdVerification)
        .set({
          isVerified: true,
          lastVerification: new Date(),
          verificationCount: storedFaceId.verificationCount + 1
        })
        .where(eq(faceIdVerification.id, storedFaceId.id));
    }
    
    return {
      verified,
      score: confidenceScore,
      enrollmentSource: storedFaceId.enrollmentSource
    };
  }
  
  /**
   * Perform full secure authentication using all methods
   */
  async secureServerAuthenticate(userId: number, authData: {
    thumbprintHash?: string,
    licenseNumber?: string,
    barcodeHash?: string,
    faceTemplateHash?: string,
    confidenceScore?: number
  }): Promise<{
    authenticated: boolean,
    methods: string[],
    scores: Record<string, number>,
    failedMethods: string[]
  }> {
    const methods: string[] = [];
    const scores: Record<string, number> = {};
    const failedMethods: string[] = [];
    let authenticated = false;
    
    // Attempt thumbprint verification
    if (authData.thumbprintHash) {
      try {
        const result = await this.verifyThumbprint(userId, authData.thumbprintHash);
        if (result.verified) {
          methods.push('thumbprint');
          scores['thumbprint'] = result.score;
        } else {
          failedMethods.push('thumbprint');
        }
      } catch (error) {
        failedMethods.push('thumbprint');
      }
    }
    
    // Attempt driver's license verification
    if (authData.licenseNumber && authData.barcodeHash) {
      try {
        const result = await this.verifyDriversLicense(userId, authData.licenseNumber, authData.barcodeHash);
        if (result.verified) {
          methods.push('driversLicense');
          scores['driversLicense'] = 100; // No direct score for license verification
        } else {
          failedMethods.push('driversLicense');
        }
      } catch (error) {
        failedMethods.push('driversLicense');
      }
    }
    
    // Attempt face ID verification
    if (authData.faceTemplateHash && authData.confidenceScore) {
      try {
        const result = await this.verifyFaceId(userId, authData.faceTemplateHash, authData.confidenceScore);
        if (result.verified) {
          methods.push('faceId');
          scores['faceId'] = result.score;
        } else {
          failedMethods.push('faceId');
        }
      } catch (error) {
        failedMethods.push('faceId');
      }
    }
    
    // Require at least two successful authentication methods for server access
    authenticated = methods.length >= 2;
    
    return {
      authenticated,
      methods,
      scores,
      failedMethods
    };
  }
  
  /**
   * Get authentication status for a user
   */
  async getAuthenticationStatus(userId: number): Promise<{
    thumbprint: boolean,
    driversLicense: boolean,
    faceId: boolean,
    lastVerified: Record<string, Date | null>,
    requiredForServerAccess: string[]
  }> {
    // Get thumbprint status
    const [thumbprint] = await db.select()
      .from(thumbprintIdentification)
      .where(eq(thumbprintIdentification.userId, userId))
      .orderBy(thumbprintIdentification.captureTimestamp, 'desc')
      .limit(1);
    
    // Get driver's license status
    const [license] = await db.select()
      .from(driversLicenseIdentification)
      .where(eq(driversLicenseIdentification.userId, userId))
      .orderBy(driversLicenseIdentification.scanTimestamp, 'desc')
      .limit(1);
    
    // Get face ID status
    const [faceId] = await db.select()
      .from(faceIdVerification)
      .where(eq(faceIdVerification.userId, userId))
      .orderBy(faceIdVerification.enrollmentTimestamp, 'desc')
      .limit(1);
    
    // Get last verification timestamps
    const lastVerified: Record<string, Date | null> = {
      thumbprint: thumbprint?.lastVerified || null,
      driversLicense: license?.lastVerified || null,
      faceId: faceId?.lastVerification || null
    };
    
    // Required authentication methods for server access
    const requiredForServerAccess = ['thumbprint', 'driversLicense', 'faceId'];
    
    return {
      thumbprint: !!thumbprint,
      driversLicense: !!license,
      faceId: !!faceId,
      lastVerified,
      requiredForServerAccess
    };
  }
  
  /**
   * Reset authentication data for testing
   * Only to be used in development environment
   */
  async resetAuthenticationData(userId: number): Promise<void> {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Cannot reset authentication data in production');
    }
    
    await db.delete(thumbprintIdentification)
      .where(eq(thumbprintIdentification.userId, userId));
      
    await db.delete(driversLicenseIdentification)
      .where(eq(driversLicenseIdentification.userId, userId));
      
    await db.delete(faceIdVerification)
      .where(eq(faceIdVerification.userId, userId));
  }
  
  /**
   * Validate barcode data format
   */
  private validateBarcodeData(barcodeData: string): boolean {
    // Basic validation - PDF417 barcode data should be a certain minimum length
    // and contain specific patterns for driver's licenses
    if (!barcodeData || barcodeData.length < 50) {
      return false;
    }
    
    // Driver's license barcodes typically start with specific header format
    // This is a simplified check - real implementation would be more comprehensive
    return barcodeData.startsWith('ANSI ') || 
           barcodeData.startsWith('@\n\u001E\rANSI ') || 
           barcodeData.startsWith('%PDF');
  }
  
  /**
   * Generate secure hash for authentication data
   */
  private generateSecureHash(data: string): string {
    return crypto.createHash('sha256').update(data).digest('hex');
  }
}

export const advancedAuthService = new AdvancedAuthService();
