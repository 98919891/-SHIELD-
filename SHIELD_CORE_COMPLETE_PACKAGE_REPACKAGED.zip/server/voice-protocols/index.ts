/**
 * ARCHLINK VOICE PROTOCOLS
 * 
 * Central export file for all voice-related modules and systems.
 * Use this file to access all voice protocol functionality.
 */

// Export all voice modules from a single location
export * from './core-voice-system';
export * from './conversation-manager';

// Export version information
export const VOICE_PROTOCOLS_VERSION = '1.0.0';
export const VOICE_PROTOCOLS_BUILD_DATE = '2025-05-06';
export const VOICE_PROTOCOLS_SECURITY_LEVEL = 'MAXIMUM';

// Export security information
export const VOICE_SECURITY_INFO = {
  hardwareBacked: true,
  encryptionLevel: 'Military-Grade AES-256',
  antiSpoofing: 'Advanced Frequency Analysis',
  secureStorage: 'Hardware Security Module'
};