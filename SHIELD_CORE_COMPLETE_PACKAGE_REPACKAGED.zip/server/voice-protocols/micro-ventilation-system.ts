/**
 * SHIELD CORE - MICRO VENTILATION SYSTEM
 * 
 * Specialized micro-ventilation system that utilizes existing device ports
 * (speaker grills and headphone jack) for enhanced airflow without
 * compromising audio performance or requiring external modifications.
 * 
 * Version: MICRO-VENT-1.0
 */

import { log } from '../vite';
import { integratedPhoneCooling } from './integrated-phone-cooling';
import { customHeatsinkSystem } from './custom-heatsink';

// Ventilation port types
type VentilationPort = 'SpeakerGrill' | 'HeadphoneJack' | 'UsbPort' | 'MicrophoneHole';

// Airflow direction
type AirflowDirection = 'Intake' | 'Exhaust' | 'Bidirectional';

// Ventilation port specification
interface VentPortSpecification {
  portType: VentilationPort;
  location: 'Top' | 'Bottom' | 'Side';
  direction: AirflowDirection;
  diameter: number; // mm
  maxAirflow: number; // CFM
  soundImpact: number; // dB reduction
  restrictionFactor: number; // percentage (higher = more restriction)
  heatDissipation: number; // Watts
}

// Micro-fan specification
interface MicroFanSpecification {
  diameter: number; // mm
  height: number; // mm
  maxRPM: number;
  maxAirflow: number; // CFM
  maxNoise: number; // dBA
  powerConsumption: number; // Watts
  bearingType: 'FluidDynamic' | 'Sleeve' | 'Ball' | 'MagLev';
  bladeCount: number;
  designOptimization: 'Airflow' | 'StaticPressure' | 'Noise' | 'Hybrid';
}

// Air channel specification
interface AirChannelSpecification {
  length: number; // mm
  diameter: number; // mm
  material: 'Silicone' | 'PTFE' | 'Copper' | 'Carbon Fiber';
  heatTransfer: number; // W/(m·K)
  bendCount: number;
  maxAirflow: number; // CFM
  flowRestriction: number; // percentage
}

// Ventilation system performance
interface VentilationPerformance {
  totalAirflow: number; // CFM
  heatDissipation: number; // Watts
  noiseLevel: number; // dBA
  audioPerformanceImpact: number; // percentage reduction
  inletTemperature: number; // Celsius
  outletTemperature: number; // Celsius
  temperatureReduction: number; // Celsius
}

/**
 * Micro Ventilation System
 * 
 * Uses existing ports on the device (speaker grills, headphone jack)
 * to create a ventilation system for improved cooling without
 * compromising device functionality or aesthetics.
 */
class MicroVentilationSystem {
  private static instance: MicroVentilationSystem;
  private active: boolean = false;
  
  // Ventilation ports
  private ventilationPorts: VentPortSpecification[] = [
    {
      portType: 'SpeakerGrill',
      location: 'Bottom',
      direction: 'Intake',
      diameter: 1.5, // mm
      maxAirflow: 0.8, // CFM
      soundImpact: 1.5, // dB reduction
      restrictionFactor: 70, // percentage
      heatDissipation: 0.5 // Watts
    },
    {
      portType: 'SpeakerGrill',
      location: 'Bottom',
      direction: 'Intake',
      diameter: 1.5, // mm
      maxAirflow: 0.8, // CFM
      soundImpact: 1.5, // dB reduction
      restrictionFactor: 70, // percentage
      heatDissipation: 0.5 // Watts
    },
    {
      portType: 'HeadphoneJack',
      location: 'Top',
      direction: 'Exhaust',
      diameter: 2.5, // mm
      maxAirflow: 1.2, // CFM
      soundImpact: 0, // No impact when not in use
      restrictionFactor: 40, // percentage
      heatDissipation: 0.8 // Watts
    },
    {
      portType: 'MicrophoneHole',
      location: 'Top',
      direction: 'Exhaust',
      diameter: 0.8, // mm
      maxAirflow: 0.3, // CFM
      soundImpact: 2, // dB reduction
      restrictionFactor: 85, // percentage
      heatDissipation: 0.2 // Watts
    }
  ];
  
  // Micro fans
  private microFans: MicroFanSpecification[] = [
    {
      diameter: 5, // mm
      height: 1.2, // mm
      maxRPM: 8000,
      maxAirflow: 0.6, // CFM
      maxNoise: 15, // dBA
      powerConsumption: 0.1, // Watts
      bearingType: 'FluidDynamic',
      bladeCount: 7,
      designOptimization: 'StaticPressure'
    },
    {
      diameter: 8, // mm
      height: 1.5, // mm
      maxRPM: 10000,
      maxAirflow: 1.2, // CFM
      maxNoise: 18, // dBA
      powerConsumption: 0.15, // Watts
      bearingType: 'MagLev',
      bladeCount: 9,
      designOptimization: 'Hybrid'
    }
  ];
  
  // Air channels
  private airChannels: AirChannelSpecification[] = [
    {
      length: 35, // mm
      diameter: 1.2, // mm
      material: 'Copper',
      heatTransfer: 385, // W/(m·K)
      bendCount: 1,
      maxAirflow: 0.7, // CFM
      flowRestriction: 35 // percentage
    },
    {
      length: 65, // mm
      diameter: 1.8, // mm
      material: 'Copper',
      heatTransfer: 385, // W/(m·K)
      bendCount: 2,
      maxAirflow: 1.1, // CFM
      flowRestriction: 45 // percentage
    }
  ];
  
  // System performance
  private performance: VentilationPerformance = {
    totalAirflow: 0,
    heatDissipation: 0,
    noiseLevel: 0,
    audioPerformanceImpact: 0,
    inletTemperature: 25,
    outletTemperature: 25,
    temperatureReduction: 0
  };
  
  // Cooling system integration
  private integratedWithCoolingSystem: boolean = false;
  
  // Fan speed
  private fanSpeed: number = 0; // percentage
  
  // Headphone use state
  private headphonesConnected: boolean = false;
  
  // Monitoring interval
  private monitoringInterval: NodeJS.Timeout | null = null;
  
  private constructor() {
    log('🌬️ [MICRO-VENT] Initializing micro ventilation system');
  }
  
  public static getInstance(): MicroVentilationSystem {
    if (!MicroVentilationSystem.instance) {
      MicroVentilationSystem.instance = new MicroVentilationSystem();
    }
    return MicroVentilationSystem.instance;
  }
  
  /**
   * Activate micro ventilation system
   */
  public activate(initialFanSpeed: number = 50): {
    success: boolean;
    airflow: number;
    heatDissipation: number;
    audioImpact: number;
    message: string;
  } {
    if (this.active) {
      return {
        success: true,
        airflow: this.performance.totalAirflow,
        heatDissipation: this.performance.heatDissipation,
        audioImpact: this.performance.audioPerformanceImpact,
        message: 'Micro ventilation system already active'
      };
    }
    
    log(`🌬️ [MICRO-VENT] Activating micro ventilation system at ${initialFanSpeed}% fan speed`);
    
    // Check for integrated cooling
    const coolingAvailable = typeof integratedPhoneCooling !== 'undefined' && 
                            integratedPhoneCooling.isActive();
    
    if (coolingAvailable) {
      log('🌬️ [MICRO-VENT] Integrating with phone cooling system');
      this.integratedWithCoolingSystem = true;
    } else {
      log('🌬️ [MICRO-VENT] Phone cooling system not available, operating standalone');
      this.integratedWithCoolingSystem = false;
    }
    
    // Set initial fan speed
    this.setFanSpeed(initialFanSpeed);
    
    // Start monitoring
    this.startMonitoring();
    
    this.active = true;
    
    log('🌬️ [MICRO-VENT] Micro ventilation system activated');
    log(`🌬️ [MICRO-VENT] Current airflow: ${this.performance.totalAirflow.toFixed(2)} CFM`);
    log(`🌬️ [MICRO-VENT] Heat dissipation: ${this.performance.heatDissipation.toFixed(2)} Watts`);
    
    if (this.performance.audioPerformanceImpact > 5) {
      log(`🌬️ [MICRO-VENT] Warning: Audio performance reduced by ${this.performance.audioPerformanceImpact.toFixed(1)}%`);
    }
    
    return {
      success: true,
      airflow: this.performance.totalAirflow,
      heatDissipation: this.performance.heatDissipation,
      audioImpact: this.performance.audioPerformanceImpact,
      message: 'Micro ventilation system activated successfully'
    };
  }
  
  /**
   * Deactivate micro ventilation system
   */
  public deactivate(): boolean {
    if (!this.active) {
      return false;
    }
    
    log('🌬️ [MICRO-VENT] Deactivating micro ventilation system');
    
    // Stop monitoring
    this.stopMonitoring();
    
    // Stop fans
    this.setFanSpeed(0);
    
    this.active = false;
    
    log('🌬️ [MICRO-VENT] Micro ventilation system deactivated');
    
    return true;
  }
  
  /**
   * Set fan speed
   */
  public setFanSpeed(speed: number): {
    success: boolean;
    speed: number;
    airflow: number;
    noise: number;
    message: string;
  } {
    // Constrain speed to valid range
    speed = Math.max(0, Math.min(100, speed));
    
    log(`🌬️ [MICRO-VENT] Setting fan speed to ${speed}%`);
    
    this.fanSpeed = speed;
    
    // Calculate performance metrics based on fan speed
    this.updatePerformanceMetrics();
    
    return {
      success: true,
      speed: this.fanSpeed,
      airflow: this.performance.totalAirflow,
      noise: this.performance.noiseLevel,
      message: `Fan speed set to ${speed}%`
    };
  }
  
  /**
   * Notify system of headphone connection state
   */
  public setHeadphoneState(connected: boolean): {
    success: boolean;
    headphonesConnected: boolean;
    ventilationImpact: number;
    message: string;
  } {
    const previousState = this.headphonesConnected;
    this.headphonesConnected = connected;
    
    log(`🌬️ [MICRO-VENT] Headphones ${connected ? 'connected' : 'disconnected'}`);
    
    // Recalculate ventilation performance
    this.updatePerformanceMetrics();
    
    // Calculate ventilation impact
    const ventilationImpact = connected ? -15 : 0; // 15% reduction when headphones connected
    
    if (connected && this.active) {
      log('🌬️ [MICRO-VENT] Adjusting airflow paths due to headphone jack blockage');
      log(`🌬️ [MICRO-VENT] Ventilation capacity reduced by ${Math.abs(ventilationImpact)}%`);
    } else if (!connected && previousState && this.active) {
      log('🌬️ [MICRO-VENT] Restoring full ventilation capacity through headphone port');
    }
    
    return {
      success: true,
      headphonesConnected: connected,
      ventilationImpact,
      message: `Headphone state set to ${connected ? 'connected' : 'disconnected'}`
    };
  }
  
  /**
   * Start performance monitoring
   */
  private startMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
    
    log('🌬️ [MICRO-VENT] Starting ventilation performance monitoring');
    
    // Set monitoring interval (every 5 seconds)
    this.monitoringInterval = setInterval(() => {
      this.updatePerformanceMetrics();
      this.optimizeVentilation();
    }, 5000);
  }
  
  /**
   * Stop performance monitoring
   */
  private stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      log('🌬️ [MICRO-VENT] Ventilation performance monitoring stopped');
    }
  }
  
  /**
   * Update performance metrics
   */
  private updatePerformanceMetrics(): void {
    if (!this.active && this.fanSpeed === 0) {
      this.performance = {
        totalAirflow: 0,
        heatDissipation: 0,
        noiseLevel: 0,
        audioPerformanceImpact: 0,
        inletTemperature: 25,
        outletTemperature: 25,
        temperatureReduction: 0
      };
      return;
    }
    
    // Calculate total airflow capacity
    let maxAirflow = 0;
    
    // Add fan airflow contributions
    for (const fan of this.microFans) {
      maxAirflow += fan.maxAirflow;
    }
    
    // Adjust for port restrictions
    let effectiveAirflow = maxAirflow;
    
    // Speaker grills are always available
    const speakerPorts = this.ventilationPorts.filter(port => port.portType === 'SpeakerGrill');
    for (const port of speakerPorts) {
      effectiveAirflow = Math.min(effectiveAirflow, port.maxAirflow * (1 - port.restrictionFactor / 100));
    }
    
    // Check headphone port availability
    if (this.headphonesConnected) {
      // Headphone jack is not available for ventilation
      const headphonePort = this.ventilationPorts.find(port => port.portType === 'HeadphoneJack');
      if (headphonePort) {
        effectiveAirflow *= 0.7; // Reduce overall airflow by 30% due to blocked exhaust
      }
    }
    
    // Adjust for channel restrictions
    let channelRestriction = 0;
    for (const channel of this.airChannels) {
      channelRestriction = Math.max(channelRestriction, channel.flowRestriction);
    }
    effectiveAirflow *= (1 - channelRestriction / 100);
    
    // Apply fan speed factor
    const actualAirflow = effectiveAirflow * (this.fanSpeed / 100);
    
    // Calculate heat dissipation
    let baseHeatDissipation = 0;
    for (const port of this.ventilationPorts) {
      baseHeatDissipation += port.heatDissipation;
    }
    const actualHeatDissipation = baseHeatDissipation * (this.fanSpeed / 100) * (actualAirflow / effectiveAirflow);
    
    // Calculate noise level
    let maxNoise = 0;
    for (const fan of this.microFans) {
      const fanNoise = fan.maxNoise * (this.fanSpeed / 100);
      maxNoise = Math.max(maxNoise, fanNoise);
    }
    
    // Calculate audio performance impact
    let audioImpact = 0;
    for (const port of this.ventilationPorts) {
      if (port.portType === 'SpeakerGrill') {
        audioImpact += port.soundImpact * (this.fanSpeed / 100);
      }
    }
    
    // Get temperatures from other systems if available
    let inletTemp = 25;
    let outletTemp = 35;
    
    if (this.integratedWithCoolingSystem && integratedPhoneCooling) {
      const metrics = integratedPhoneCooling.getThermalMetrics();
      inletTemp = metrics.ambientTemperature;
      outletTemp = metrics.internalTemperature;
    } else if (customHeatsinkSystem && customHeatsinkSystem.isActive()) {
      const processorPerf = customHeatsinkSystem.getProcessorThermalPerformance();
      outletTemp = processorPerf.loadTemperature;
    } else {
      // Simulate random temperature variations
      inletTemp = 22 + (Math.random() * 4);
      outletTemp = inletTemp + 10 + (Math.random() * 5);
    }
    
    // Calculate temperature reduction from ventilation
    const tempReduction = actualHeatDissipation * 0.8; // Each Watt reduces temp by ~0.8°C
    
    // Update performance metrics
    this.performance = {
      totalAirflow: actualAirflow,
      heatDissipation: actualHeatDissipation,
      noiseLevel: maxNoise,
      audioPerformanceImpact: audioImpact,
      inletTemperature: inletTemp,
      outletTemperature: outletTemp - tempReduction,
      temperatureReduction: tempReduction
    };
    
    // Log performance updates
    if (this.active && this.fanSpeed > 0) {
      log(`🌬️ [MICRO-VENT] Airflow: ${actualAirflow.toFixed(2)} CFM, Heat dissipation: ${actualHeatDissipation.toFixed(2)}W`);
      log(`🌬️ [MICRO-VENT] Temperature reduction: ${tempReduction.toFixed(1)}°C, Audio impact: ${audioImpact.toFixed(1)}%`);
    }
  }
  
  /**
   * Optimize ventilation based on current state
   */
  private optimizeVentilation(): void {
    if (!this.active) {
      return;
    }
    
    // Get current temperature
    const currentTemp = this.performance.outletTemperature + this.performance.temperatureReduction;
    
    // Determine optimal fan speed based on temperature
    let optimalSpeed = this.fanSpeed;
    
    if (currentTemp > 75) {
      optimalSpeed = 100; // Maximum cooling
    } else if (currentTemp > 65) {
      optimalSpeed = 80;
    } else if (currentTemp > 55) {
      optimalSpeed = 60;
    } else if (currentTemp > 45) {
      optimalSpeed = 40;
    } else {
      optimalSpeed = 20; // Minimum cooling
    }
    
    // Adjust speed if audio impact is too high
    if (this.performance.audioPerformanceImpact > 10 && !this.headphonesConnected) {
      optimalSpeed = Math.min(optimalSpeed, 80); // Cap at 80% to reduce audio impact
    }
    
    // Only update if the change is significant
    if (Math.abs(optimalSpeed - this.fanSpeed) >= 10) {
      log(`🌬️ [MICRO-VENT] Auto-adjusting fan speed to ${optimalSpeed}% based on temperature`);
      this.setFanSpeed(optimalSpeed);
    }
  }
  
  /**
   * Get ventilation ports specifications
   */
  public getVentilationPorts(): VentPortSpecification[] {
    return [...this.ventilationPorts];
  }
  
  /**
   * Get micro fan specifications
   */
  public getMicroFans(): MicroFanSpecification[] {
    return [...this.microFans];
  }
  
  /**
   * Get air channel specifications
   */
  public getAirChannels(): AirChannelSpecification[] {
    return [...this.airChannels];
  }
  
  /**
   * Get performance metrics
   */
  public getPerformanceMetrics(): VentilationPerformance {
    return { ...this.performance };
  }
  
  /**
   * Get fan speed
   */
  public getFanSpeed(): number {
    return this.fanSpeed;
  }
  
  /**
   * Check if ventilation system is active
   */
  public isActive(): boolean {
    return this.active;
  }
  
  /**
   * Check if headphones are connected
   */
  public areHeadphonesConnected(): boolean {
    return this.headphonesConnected;
  }
}

// Create and export instance
const microVentilationSystem = MicroVentilationSystem.getInstance();

export {
  microVentilationSystem,
  type VentilationPort,
  type AirflowDirection,
  type VentPortSpecification,
  type MicroFanSpecification,
  type AirChannelSpecification,
  type VentilationPerformance
};