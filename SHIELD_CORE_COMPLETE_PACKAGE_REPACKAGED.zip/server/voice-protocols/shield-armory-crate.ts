/**
 * SHIELD CORE - ARMORY CRATE
 * 
 * Comprehensive control center inspired by ROG Armory Crate
 * but enhanced for Shield Core systems. Provides centralized
 * management of all hardware, cooling, memory, security and
 * performance settings through a unified interface.
 * 
 * Version: ARMORY-1.0
 */

import { log } from '../vite';
import { shieldCoreMasterController, type ShieldCoreLevel } from './shield-core-master-controller';
import { physicalPhoneLockdown, type SecurityLevel } from './physical-phone-lockdown';
import { rogGameCool8, type GameCool8Mode } from './rog-gamecool-8';
import { lpddr5xMemoryEnhancement } from './lpddr5x-memory-enhancement';
import { physicalRamModule } from './physical-ram-module';
import { compactDdrIntegration } from './compact-ddr-integration';
import { bulletproofSystem } from './bulletproof-system';
import { quantumMiniaturization } from './quantum-miniaturization';

// UI themes
type ArmoryTheme = 'Dark' | 'Light' | 'Stealth' | 'Quantum' | 'Aura' | 'ROG' | 'Shield Core';

// Lighting effects
type LightingEffect = 'Static' | 'Breathing' | 'Strobing' | 'Rainbow' | 'Reactive' | 'Quantum';

// Performance modes
type ArmoryPerformanceMode = 'Silent' | 'Balanced' | 'Turbo' | 'X-Mode' | 'Ultimate' | 'Custom';

// Feature categories
type FeatureCategory = 
  'System' | 
  'Performance' | 
  'Memory' | 
  'Cooling' | 
  'Security' | 
  'Lighting' | 
  'Storage' | 
  'Network' | 
  'Quantum' | 
  'Shield' | 
  'Audio';

// System metrics
interface SystemMetrics {
  cpuTemperature: number; // Celsius
  gpuTemperature: number; // Celsius
  batteryTemperature: number; // Celsius
  ramUsage: number; // percentage
  storageUsage: number; // percentage
  cpuUsage: number; // percentage
  gpuUsage: number; // percentage
  batteryLevel: number; // percentage
  networkSpeed: number; // Mbps
  availableRam: number; // GB
  totalRam: number; // GB
  fanSpeed: number; // percentage
  securityLevel: number; // 0-100
  quantumStability: number; // 0-100
  temperatureColor: string; // CSS color
  lastUpdated: Date;
}

// Armory Crate settings
interface ArmorySettings {
  theme: ArmoryTheme;
  lightingEffect: LightingEffect;
  accentColor: string; // CSS color
  performanceMode: ArmoryPerformanceMode;
  fanSpeedControl: 'Auto' | 'Manual';
  manualFanSpeed: number; // percentage
  cpuBoost: boolean;
  gpuBoost: boolean;
  dynamicBoost: boolean;
  autoStartup: boolean;
  notificationsEnabled: boolean;
  monitoringInterval: number; // milliseconds
  quickAccessFeatures: FeatureCategory[];
  showAdvancedSettings: boolean;
  compactMode: boolean;
  lockscreenWidget: boolean;
  useQuantumFeatures: boolean;
}

// Current status
interface ArmoryStatus {
  active: boolean;
  performanceMode: ArmoryPerformanceMode;
  metrics: SystemMetrics;
  shieldCoreActive: boolean;
  shieldCoreLevel: ShieldCoreLevel;
  miniaturizationActive: boolean;
  temperatureWarning: boolean;
  batteryWarning: boolean;
  securityWarning: boolean;
  quantumWarning: boolean;
  lastRefreshed: Date;
}

/**
 * Shield Armory Crate
 * 
 * Comprehensive control center for Shield Core systems.
 * Inspired by ROG Armory Crate but enhanced for advanced features.
 */
class ShieldArmoryCrate {
  private static instance: ShieldArmoryCrate;
  private active: boolean = false;
  
  // Default settings
  private settings: ArmorySettings = {
    theme: 'Shield Core',
    lightingEffect: 'Quantum',
    accentColor: '#00e5ff',
    performanceMode: 'Balanced',
    fanSpeedControl: 'Auto',
    manualFanSpeed: 60,
    cpuBoost: true,
    gpuBoost: true,
    dynamicBoost: true,
    autoStartup: true,
    notificationsEnabled: true,
    monitoringInterval: 3000, // 3 seconds
    quickAccessFeatures: ['Performance', 'Cooling', 'Memory', 'Security', 'Shield'],
    showAdvancedSettings: true,
    compactMode: false,
    lockscreenWidget: true,
    useQuantumFeatures: true
  };
  
  // Current status
  private status: ArmoryStatus = {
    active: false,
    performanceMode: 'Balanced',
    metrics: {
      cpuTemperature: 35,
      gpuTemperature: 33,
      batteryTemperature: 30,
      ramUsage: 25,
      storageUsage: 45,
      cpuUsage: 8,
      gpuUsage: 5,
      batteryLevel: 85,
      networkSpeed: 250,
      availableRam: 12,
      totalRam: 16,
      fanSpeed: 0,
      securityLevel: 85,
      quantumStability: 100,
      temperatureColor: '#44ff44', // Green = cool
      lastUpdated: new Date()
    },
    shieldCoreActive: false,
    shieldCoreLevel: 'Basic',
    miniaturizationActive: false,
    temperatureWarning: false,
    batteryWarning: false,
    securityWarning: false,
    quantumWarning: false,
    lastRefreshed: new Date()
  };
  
  // Performance presets
  private performancePresets: { [key in ArmoryPerformanceMode]: {
    cpuBoost: boolean;
    gpuBoost: boolean;
    dynamicBoost: boolean;
    fanProfile: 'Silent' | 'Standard' | 'Turbo' | 'Max' | 'Adaptive';
    memoryProfile: 'Default' | 'Balanced' | 'Performance' | 'Extreme' | 'Security' | 'Custom';
    powerMode: 'PowerSaver' | 'Balanced' | 'Performance' | 'Ultimate';
    cpuTdp: number; // Watts
    gpuTdp: number; // Watts
  }} = {
    'Silent': {
      cpuBoost: false,
      gpuBoost: false,
      dynamicBoost: false,
      fanProfile: 'Silent',
      memoryProfile: 'Default',
      powerMode: 'PowerSaver',
      cpuTdp: 15,
      gpuTdp: 10
    },
    'Balanced': {
      cpuBoost: false,
      gpuBoost: true,
      dynamicBoost: true,
      fanProfile: 'Standard',
      memoryProfile: 'Balanced',
      powerMode: 'Balanced',
      cpuTdp: 25,
      gpuTdp: 15
    },
    'Turbo': {
      cpuBoost: true,
      gpuBoost: true,
      dynamicBoost: true,
      fanProfile: 'Turbo',
      memoryProfile: 'Performance',
      powerMode: 'Performance',
      cpuTdp: 35,
      gpuTdp: 20
    },
    'X-Mode': {
      cpuBoost: true,
      gpuBoost: true,
      dynamicBoost: true,
      fanProfile: 'Max',
      memoryProfile: 'Performance',
      powerMode: 'Ultimate',
      cpuTdp: 45,
      gpuTdp: 25
    },
    'Ultimate': {
      cpuBoost: true,
      gpuBoost: true,
      dynamicBoost: true,
      fanProfile: 'Max',
      memoryProfile: 'Extreme',
      powerMode: 'Ultimate',
      cpuTdp: 50,
      gpuTdp: 30
    },
    'Custom': {
      cpuBoost: true,
      gpuBoost: true,
      dynamicBoost: true,
      fanProfile: 'Adaptive',
      memoryProfile: 'Custom',
      powerMode: 'Performance',
      cpuTdp: 35,
      gpuTdp: 20
    }
  };
  
  // Monitoring interval
  private monitoringInterval: NodeJS.Timeout | null = null;
  
  // Available profiles
  private profiles: string[] = ['Default', 'Gaming', 'Content Creation', 'Battery Saver', 'Ultimate Performance', 'Stealth'];
  
  // Current profile
  private currentProfile: string = 'Default';
  
  private constructor() {
    log('🎮 [ARMORY] Initializing Shield Armory Crate');
    log('🎮 [ARMORY] Loading ROG-inspired control center');
  }
  
  public static getInstance(): ShieldArmoryCrate {
    if (!ShieldArmoryCrate.instance) {
      ShieldArmoryCrate.instance = new ShieldArmoryCrate();
    }
    return ShieldArmoryCrate.instance;
  }
  
  /**
   * Launch Armory Crate
   */
  public launch(): {
    success: boolean;
    theme: ArmoryTheme;
    performanceMode: ArmoryPerformanceMode;
    message: string;
  } {
    if (this.active) {
      return {
        success: true,
        theme: this.settings.theme,
        performanceMode: this.status.performanceMode,
        message: 'Shield Armory Crate already active'
      };
    }
    
    log('🎮 [ARMORY] Launching Shield Armory Crate');
    log(`🎮 [ARMORY] Applying ${this.settings.theme} theme`);
    
    // Initialize subsystems
    this.initializeSubsystems();
    
    // Start monitoring
    this.startMonitoring();
    
    // Update current status based on connected systems
    this.updateSystemStatus();
    
    this.active = true;
    this.status.active = true;
    
    log('🎮 [ARMORY] Shield Armory Crate launched successfully');
    log(`🎮 [ARMORY] Current performance mode: ${this.status.performanceMode}`);
    log(`🎮 [ARMORY] RAM: ${this.status.metrics.availableRam}/${this.status.metrics.totalRam}GB (${this.status.metrics.ramUsage}% used)`);
    log(`🎮 [ARMORY] Temperature: CPU ${this.status.metrics.cpuTemperature}°C, GPU ${this.status.metrics.gpuTemperature}°C`);
    
    return {
      success: true,
      theme: this.settings.theme,
      performanceMode: this.status.performanceMode,
      message: 'Shield Armory Crate launched successfully'
    };
  }
  
  /**
   * Close Armory Crate
   */
  public close(): boolean {
    if (!this.active) {
      return false;
    }
    
    log('🎮 [ARMORY] Closing Shield Armory Crate');
    
    // Stop monitoring
    this.stopMonitoring();
    
    this.active = false;
    this.status.active = false;
    
    log('🎮 [ARMORY] Shield Armory Crate closed');
    
    return true;
  }
  
  /**
   * Initialize integrated subsystems
   */
  private initializeSubsystems(): void {
    log('🎮 [ARMORY] Initializing integrated subsystems');
    
    // Check Shield Core
    if (shieldCoreMasterController && shieldCoreMasterController.isActive()) {
      const shieldStatus = shieldCoreMasterController.getStatus();
      this.status.shieldCoreActive = true;
      this.status.shieldCoreLevel = shieldStatus.level;
      log(`🎮 [ARMORY] Connected to Shield Core (Level: ${shieldStatus.level})`);
    } else {
      this.status.shieldCoreActive = false;
      log('🎮 [ARMORY] Shield Core not active');
    }
    
    // Check Quantum Miniaturization
    if (quantumMiniaturization && quantumMiniaturization.isActive()) {
      this.status.miniaturizationActive = true;
      const miniStatus = quantumMiniaturization.getStatus();
      this.status.metrics.quantumStability = miniStatus.stabilityRating;
      log(`🎮 [ARMORY] Connected to Quantum Miniaturization (Reduction: ${(1-miniStatus.overallReductionRatio)*100}%)`);
    } else {
      this.status.miniaturizationActive = false;
    }
    
    // Map current cooling system state to performance mode
    if (rogGameCool8 && rogGameCool8.isActive()) {
      const coolingStatus = rogGameCool8.getStatus();
      
      // Map cooling mode to performance mode
      let performanceMode: ArmoryPerformanceMode;
      switch (coolingStatus.mode) {
        case 'Balanced': performanceMode = 'Balanced'; break;
        case 'Performance': performanceMode = 'Turbo'; break;
        case 'X-Mode': performanceMode = 'X-Mode'; break;
        case 'Extreme': performanceMode = 'Ultimate'; break;
        case 'Custom': performanceMode = 'Custom'; break;
        default: performanceMode = 'Balanced';
      }
      
      this.status.performanceMode = performanceMode;
      log(`🎮 [ARMORY] Detected active cooling system in ${performanceMode} mode`);
    }
    
    // Calculate total system memory
    let totalMemory = 16; // Base system memory
    
    if (physicalRamModule && physicalRamModule.isActive()) {
      const ramSpec = physicalRamModule.getRamSpecifications();
      totalMemory += ramSpec.size;
      log(`🎮 [ARMORY] Detected active physical RAM module (${ramSpec.size}GB)`);
    }
    
    if (compactDdrIntegration && compactDdrIntegration.isActive()) {
      const compactSpec = compactDdrIntegration.getSpecifications();
      totalMemory += compactSpec.capacity;
      log(`🎮 [ARMORY] Detected active compact DDR module (${compactSpec.capacity}GB)`);
    }
    
    // Update memory metrics
    this.status.metrics.totalRam = totalMemory;
    this.status.metrics.availableRam = Math.round(totalMemory * (1 - (this.status.metrics.ramUsage / 100)));
    
    log(`🎮 [ARMORY] Total system memory: ${totalMemory}GB`);
  }
  
  /**
   * Update current system status
   */
  private updateSystemStatus(): void {
    // Update metrics based on current system state
    if (rogGameCool8 && rogGameCool8.isActive()) {
      const coolingStatus = rogGameCool8.getStatus();
      this.status.metrics.cpuTemperature = coolingStatus.cpuTemperature;
      this.status.metrics.gpuTemperature = coolingStatus.gpuTemperature;
      this.status.metrics.fanSpeed = 
        coolingStatus.mode === 'Balanced' ? 30 :
        coolingStatus.mode === 'Performance' ? 60 :
        coolingStatus.mode === 'X-Mode' ? 80 :
        coolingStatus.mode === 'Extreme' ? 100 : 50;
    }
    
    // Update security level
    if (physicalPhoneLockdown && physicalPhoneLockdown.isActive()) {
      const lockdownStatus = physicalPhoneLockdown.getStatus();
      const securityLevelMap = {
        'Standard': 60,
        'Enhanced': 75,
        'Military': 85,
        'Quantum': 95,
        'Absolute': 100
      };
      this.status.metrics.securityLevel = securityLevelMap[lockdownStatus.securityLevel] || 50;
      
      // Check for security warnings
      this.status.securityWarning = lockdownStatus.lastVerification ? 
        !lockdownStatus.lastVerification.verified : false;
    }
    
    // Update quantum stability
    if (quantumMiniaturization && quantumMiniaturization.isActive()) {
      const miniStatus = quantumMiniaturization.getStatus();
      this.status.metrics.quantumStability = miniStatus.stabilityRating;
      this.status.quantumWarning = miniStatus.stabilityRating < 96;
    }
    
    // Update temperature warnings
    this.status.temperatureWarning = 
      this.status.metrics.cpuTemperature > 80 || 
      this.status.metrics.gpuTemperature > 85 ||
      this.status.metrics.batteryTemperature > 40;
      
    // Update temperature color
    const maxTemp = Math.max(
      this.status.metrics.cpuTemperature,
      this.status.metrics.gpuTemperature
    );
    
    if (maxTemp < 50) {
      this.status.metrics.temperatureColor = '#44ff44'; // Green (cool)
    } else if (maxTemp < 70) {
      this.status.metrics.temperatureColor = '#ffff44'; // Yellow (warm)
    } else if (maxTemp < 85) {
      this.status.metrics.temperatureColor = '#ff8844'; // Orange (hot)
    } else {
      this.status.metrics.temperatureColor = '#ff4444'; // Red (critical)
    }
    
    // Update last refreshed timestamp
    this.status.lastRefreshed = new Date();
    this.status.metrics.lastUpdated = new Date();
  }
  
  /**
   * Start system monitoring
   */
  private startMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
    
    log('🎮 [ARMORY] Starting system monitoring');
    
    // Set monitoring interval based on settings
    this.monitoringInterval = setInterval(() => {
      this.updateSystemStatus();
      this.checkWarnings();
    }, this.settings.monitoringInterval);
  }
  
  /**
   * Stop system monitoring
   */
  private stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      log('🎮 [ARMORY] System monitoring stopped');
    }
  }
  
  /**
   * Check for system warnings
   */
  private checkWarnings(): void {
    // Only log warnings if monitoring has been running for a while
    if (this.status.lastRefreshed.getTime() < Date.now() - 10000) {
      if (this.status.temperatureWarning) {
        log('🎮 [ARMORY] WARNING: High temperature detected');
        log(`🎮 [ARMORY] CPU: ${this.status.metrics.cpuTemperature}°C, GPU: ${this.status.metrics.gpuTemperature}°C`);
      }
      
      if (this.status.securityWarning) {
        log('🎮 [ARMORY] WARNING: Security verification issue detected');
      }
      
      if (this.status.quantumWarning) {
        log('🎮 [ARMORY] WARNING: Quantum stability below optimal levels');
        log(`🎮 [ARMORY] Current stability: ${this.status.metrics.quantumStability}%`);
      }
      
      if (this.status.batteryWarning) {
        log('🎮 [ARMORY] WARNING: Battery level low');
        log(`🎮 [ARMORY] Current battery: ${this.status.metrics.batteryLevel}%`);
      }
    }
  }
  
  /**
   * Set performance mode
   */
  public setPerformanceMode(mode: ArmoryPerformanceMode): {
    success: boolean;
    previousMode: ArmoryPerformanceMode;
    newMode: ArmoryPerformanceMode;
    message: string;
  } {
    const previousMode = this.status.performanceMode;
    
    log(`🎮 [ARMORY] Changing performance mode from ${previousMode} to ${mode}`);
    
    // Apply changes to integrated systems
    
    // Update cooling system
    if (rogGameCool8 && rogGameCool8.isActive()) {
      let coolingMode: GameCool8Mode;
      switch (mode) {
        case 'Silent': coolingMode = 'Balanced'; break;
        case 'Balanced': coolingMode = 'Balanced'; break;
        case 'Turbo': coolingMode = 'Performance'; break;
        case 'X-Mode': coolingMode = 'X-Mode'; break;
        case 'Ultimate': coolingMode = 'Extreme'; break;
        case 'Custom': coolingMode = 'Custom'; break;
        default: coolingMode = 'Balanced';
      }
      
      rogGameCool8.setCoolingMode(coolingMode);
      log(`🎮 [ARMORY] Cooling system set to ${coolingMode} mode`);
    }
    
    // Update memory enhancement
    if (lpddr5xMemoryEnhancement && lpddr5xMemoryEnhancement.isActive()) {
      const memProfile = this.performancePresets[mode].memoryProfile;
      lpddr5xMemoryEnhancement.applyTimingProfile(memProfile);
      log(`🎮 [ARMORY] Memory enhancement set to ${memProfile} profile`);
    }
    
    // Update Shield Core if active
    if (this.status.shieldCoreActive && shieldCoreMasterController) {
      let coreLevel: ShieldCoreLevel;
      switch (mode) {
        case 'Silent': coreLevel = 'Basic'; break;
        case 'Balanced': coreLevel = 'Basic'; break;
        case 'Turbo': coreLevel = 'Advanced'; break;
        case 'X-Mode': coreLevel = 'Military'; break;
        case 'Ultimate': coreLevel = 'Ultimate'; break;
        case 'Custom': coreLevel = 'Advanced'; break;
        default: coreLevel = 'Basic';
      }
      
      // Only change if different
      if (coreLevel !== this.status.shieldCoreLevel) {
        shieldCoreMasterController.changeLevel(coreLevel);
        this.status.shieldCoreLevel = coreLevel;
        log(`🎮 [ARMORY] Shield Core level set to ${coreLevel}`);
      }
    }
    
    // Update settings
    this.settings.performanceMode = mode;
    this.settings.cpuBoost = this.performancePresets[mode].cpuBoost;
    this.settings.gpuBoost = this.performancePresets[mode].gpuBoost;
    this.settings.dynamicBoost = this.performancePresets[mode].dynamicBoost;
    
    if (mode !== 'Custom') {
      // Set fan profile if not in custom mode
      const fanProfile = this.performancePresets[mode].fanProfile;
      this.settings.fanSpeedControl = fanProfile === 'Adaptive' ? 'Auto' : 'Manual';
      this.settings.manualFanSpeed = 
        fanProfile === 'Silent' ? 20 :
        fanProfile === 'Standard' ? 40 :
        fanProfile === 'Turbo' ? 70 :
        fanProfile === 'Max' ? 100 : 50;
    }
    
    // Update status
    this.status.performanceMode = mode;
    
    log(`🎮 [ARMORY] Performance mode changed to ${mode}`);
    log(`🎮 [ARMORY] CPU Boost: ${this.settings.cpuBoost ? 'Enabled' : 'Disabled'}`);
    log(`🎮 [ARMORY] GPU Boost: ${this.settings.gpuBoost ? 'Enabled' : 'Disabled'}`);
    log(`🎮 [ARMORY] Fan Control: ${this.settings.fanSpeedControl}, Speed: ${this.settings.manualFanSpeed}%`);
    
    return {
      success: true,
      previousMode,
      newMode: mode,
      message: `Performance mode changed from ${previousMode} to ${mode}`
    };
  }
  
  /**
   * Set theme
   */
  public setTheme(theme: ArmoryTheme): {
    success: boolean;
    previousTheme: ArmoryTheme;
    newTheme: ArmoryTheme;
    message: string;
  } {
    const previousTheme = this.settings.theme;
    
    log(`🎮 [ARMORY] Changing theme from ${previousTheme} to ${theme}`);
    
    this.settings.theme = theme;
    
    // Set appropriate accent color based on theme
    switch (theme) {
      case 'Dark': this.settings.accentColor = '#9966ff'; break;
      case 'Light': this.settings.accentColor = '#3399ff'; break;
      case 'Stealth': this.settings.accentColor = '#66ff99'; break;
      case 'Quantum': this.settings.accentColor = '#ff66cc'; break;
      case 'Aura': this.settings.accentColor = '#ff3366'; break;
      case 'ROG': this.settings.accentColor = '#ff0000'; break;
      case 'Shield Core': this.settings.accentColor = '#00e5ff'; break;
    }
    
    log(`🎮 [ARMORY] Theme changed to ${theme}`);
    log(`🎮 [ARMORY] Accent color set to ${this.settings.accentColor}`);
    
    return {
      success: true,
      previousTheme,
      newTheme: theme,
      message: `Theme changed from ${previousTheme} to ${theme}`
    };
  }
  
  /**
   * Set lighting effect
   */
  public setLightingEffect(effect: LightingEffect): {
    success: boolean;
    previousEffect: LightingEffect;
    newEffect: LightingEffect;
    message: string;
  } {
    const previousEffect = this.settings.lightingEffect;
    
    log(`🎮 [ARMORY] Changing lighting effect from ${previousEffect} to ${effect}`);
    
    this.settings.lightingEffect = effect;
    
    log(`🎮 [ARMORY] Lighting effect changed to ${effect}`);
    
    return {
      success: true,
      previousEffect,
      newEffect: effect,
      message: `Lighting effect changed from ${previousEffect} to ${effect}`
    };
  }
  
  /**
   * Set manual fan speed
   */
  public setManualFanSpeed(speed: number): {
    success: boolean;
    previousSpeed: number;
    newSpeed: number;
    message: string;
  } {
    if (speed < 0 || speed > 100) {
      return {
        success: false,
        previousSpeed: this.settings.manualFanSpeed,
        newSpeed: this.settings.manualFanSpeed,
        message: 'Invalid fan speed. Must be between 0 and 100'
      };
    }
    
    const previousSpeed = this.settings.manualFanSpeed;
    
    log(`🎮 [ARMORY] Changing manual fan speed from ${previousSpeed}% to ${speed}%`);
    
    this.settings.manualFanSpeed = speed;
    this.settings.fanSpeedControl = 'Manual';
    
    // Apply to cooling system if active
    if (rogGameCool8 && rogGameCool8.isActive()) {
      const fanProfile = 
        speed < 25 ? 'Silent' :
        speed < 50 ? 'Standard' :
        speed < 75 ? 'Turbo' : 'Max';
        
      rogGameCool8.setFanProfile(fanProfile);
      log(`🎮 [ARMORY] Applied ${fanProfile} fan profile (${speed}%)`);
    }
    
    log(`🎮 [ARMORY] Manual fan speed set to ${speed}%`);
    
    return {
      success: true,
      previousSpeed,
      newSpeed: speed,
      message: `Manual fan speed changed from ${previousSpeed}% to ${speed}%`
    };
  }
  
  /**
   * Toggle CPU boost
   */
  public toggleCpuBoost(): {
    success: boolean;
    enabled: boolean;
    message: string;
  } {
    const previousState = this.settings.cpuBoost;
    this.settings.cpuBoost = !previousState;
    
    log(`🎮 [ARMORY] CPU boost ${this.settings.cpuBoost ? 'enabled' : 'disabled'}`);
    
    // If we're in a predefined mode, switch to custom
    if (this.status.performanceMode !== 'Custom') {
      this.status.performanceMode = 'Custom';
      log('🎮 [ARMORY] Switched to Custom performance mode due to manual changes');
    }
    
    return {
      success: true,
      enabled: this.settings.cpuBoost,
      message: `CPU boost ${this.settings.cpuBoost ? 'enabled' : 'disabled'}`
    };
  }
  
  /**
   * Toggle GPU boost
   */
  public toggleGpuBoost(): {
    success: boolean;
    enabled: boolean;
    message: string;
  } {
    const previousState = this.settings.gpuBoost;
    this.settings.gpuBoost = !previousState;
    
    log(`🎮 [ARMORY] GPU boost ${this.settings.gpuBoost ? 'enabled' : 'disabled'}`);
    
    // If we're in a predefined mode, switch to custom
    if (this.status.performanceMode !== 'Custom') {
      this.status.performanceMode = 'Custom';
      log('🎮 [ARMORY] Switched to Custom performance mode due to manual changes');
    }
    
    return {
      success: true,
      enabled: this.settings.gpuBoost,
      message: `GPU boost ${this.settings.gpuBoost ? 'enabled' : 'disabled'}`
    };
  }
  
  /**
   * Save current settings as profile
   */
  public saveProfile(profileName: string): {
    success: boolean;
    profileName: string;
    message: string;
  } {
    if (!profileName) {
      return {
        success: false,
        profileName: '',
        message: 'Invalid profile name'
      };
    }
    
    log(`🎮 [ARMORY] Saving current settings as profile "${profileName}"`);
    
    // Check if profile already exists
    const profileExists = this.profiles.includes(profileName);
    
    if (!profileExists) {
      this.profiles.push(profileName);
    }
    
    // Set as current profile
    this.currentProfile = profileName;
    
    log(`🎮 [ARMORY] Profile "${profileName}" ${profileExists ? 'updated' : 'created'}`);
    log(`🎮 [ARMORY] Current profile set to "${profileName}"`);
    
    return {
      success: true,
      profileName,
      message: `Profile "${profileName}" ${profileExists ? 'updated' : 'created'} and activated`
    };
  }
  
  /**
   * Load profile
   */
  public loadProfile(profileName: string): {
    success: boolean;
    profileName: string;
    message: string;
  } {
    if (!this.profiles.includes(profileName)) {
      return {
        success: false,
        profileName: this.currentProfile,
        message: `Profile "${profileName}" not found`
      };
    }
    
    log(`🎮 [ARMORY] Loading profile "${profileName}"`);
    
    // In a real implementation, this would load saved settings
    // Here we'll simulate with some predefined settings
    
    let performanceMode: ArmoryPerformanceMode;
    let theme: ArmoryTheme;
    
    switch (profileName) {
      case 'Gaming':
        performanceMode = 'X-Mode';
        theme = 'ROG';
        break;
      case 'Content Creation':
        performanceMode = 'Turbo';
        theme = 'Aura';
        break;
      case 'Battery Saver':
        performanceMode = 'Silent';
        theme = 'Dark';
        break;
      case 'Ultimate Performance':
        performanceMode = 'Ultimate';
        theme = 'Quantum';
        break;
      case 'Stealth':
        performanceMode = 'Balanced';
        theme = 'Stealth';
        break;
      default:
        performanceMode = 'Balanced';
        theme = 'Shield Core';
    }
    
    // Apply settings
    this.setPerformanceMode(performanceMode);
    this.setTheme(theme);
    
    // Set as current profile
    this.currentProfile = profileName;
    
    log(`🎮 [ARMORY] Profile "${profileName}" loaded`);
    log(`🎮 [ARMORY] Performance mode set to ${performanceMode}`);
    log(`🎮 [ARMORY] Theme set to ${theme}`);
    
    return {
      success: true,
      profileName,
      message: `Profile "${profileName}" loaded successfully`
    };
  }
  
  /**
   * Get available profiles
   */
  public getProfiles(): string[] {
    return [...this.profiles];
  }
  
  /**
   * Get current profile
   */
  public getCurrentProfile(): string {
    return this.currentProfile;
  }
  
  /**
   * Get current settings
   */
  public getSettings(): ArmorySettings {
    return { ...this.settings };
  }
  
  /**
   * Get current status
   */
  public getStatus(): ArmoryStatus {
    // Update metrics before returning
    this.updateSystemStatus();
    return { ...this.status };
  }
  
  /**
   * Get system metrics
   */
  public getSystemMetrics(): SystemMetrics {
    // Update metrics before returning
    this.updateSystemStatus();
    return { ...this.status.metrics };
  }
  
  /**
   * Check if Armory Crate is active
   */
  public isActive(): boolean {
    return this.active;
  }
}

// Create and export instance
const shieldArmoryCrate = ShieldArmoryCrate.getInstance();

export {
  shieldArmoryCrate,
  type ArmoryTheme,
  type LightingEffect,
  type ArmoryPerformanceMode,
  type FeatureCategory,
  type SystemMetrics,
  type ArmorySettings,
  type ArmoryStatus
};