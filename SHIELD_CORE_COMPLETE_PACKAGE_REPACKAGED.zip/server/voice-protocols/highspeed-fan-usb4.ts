/**
 * SHIELD CORE - HIGHSPEED FAN SYSTEM
 * 
 * Advanced USB 4.0 powered high-speed fan module with
 * integrated cooling channels for M.3 NVMe SSD and Ryzen processor.
 * Features variable speed control and multi-zone cooling.
 * 
 * Version: FAN-SYS-1.0
 */

import { log } from '../vite';
import { customHeatsinkSystem } from './custom-heatsink';
import { advancedCoolingSystem, type FanProfile } from './advanced-cooling-system';

// USB Connection types
type UsbConnectionType = 'USB4.0' | 'USB3.2' | 'USB3.1' | 'USB-C' | 'Thunderbolt4';

// Fan types
type FanType = 'BlowerStyle' | 'AxialFlow' | 'TwinTurbo' | 'VaporFan' | 'MagLev';

// Fan interface
interface FanSpecification {
  type: FanType;
  fanSize: number; // mm
  maxRPM: number;
  maxAirflow: number; // CFM
  maxStaticPressure: number; // mmH2O
  noiseLevel: number; // dBA
  controlInterface: 'PWM' | 'DC' | 'Auto';
  powerDraw: number; // Watts
  bearingType: 'FluidDynamic' | 'Ball' | 'Sleeve' | 'MagneticLevitation' | 'Rifle';
  bladeCount: number;
  zones: number;
}

// Cooling channel specification
interface CoolingChannelSpec {
  material: 'Copper' | 'Aluminum' | 'Carbon Fiber' | 'Graphene';
  channelCount: number;
  totalLength: number; // mm
  diameter: number; // mm
  heatCapacity: number; // J/K
  flowRate: number; // ml/min
  coverage: {
    m3: boolean;
    processor: boolean;
    gpu: boolean;
  };
}

// Fan performance
interface FanPerformance {
  currentRPM: number;
  currentAirflow: number; // CFM
  currentNoise: number; // dBA
  currentPower: number; // Watts
  dutyCycle: number; // percentage
  targetTemperature: number; // Celsius
  currentTemperature: number; // Celsius
}

// USB connection status
interface UsbConnectionStatus {
  connected: boolean;
  connectionType: UsbConnectionType;
  powerDelivery: number; // Watts
  dataRate: number; // Gbps
  port: string;
  stable: boolean;
}

/**
 * High-speed USB 4.0 Fan System with Integrated Cooling Channels
 */
class HighspeedFanSystem {
  private static instance: HighspeedFanSystem;
  private active: boolean = false;
  
  // Fan specifications
  private fanSpec: FanSpecification = {
    type: 'TwinTurbo',
    fanSize: 55, // mm
    maxRPM: 15000,
    maxAirflow: 55, // CFM
    maxStaticPressure: 9.8, // mmH2O
    noiseLevel: 42, // dBA
    controlInterface: 'PWM',
    powerDraw: 8.5, // Watts
    bearingType: 'MagneticLevitation',
    bladeCount: 15,
    zones: 3
  };
  
  // Cooling channel specifications
  private coolingSys: CoolingChannelSpec = {
    material: 'Copper',
    channelCount: 12,
    totalLength: 480, // mm
    diameter: 2.5, // mm
    heatCapacity: 450, // J/K
    flowRate: 850, // ml/min
    coverage: {
      m3: true,
      processor: true,
      gpu: true
    }
  };
  
  // Performance stats
  private fanPerf: FanPerformance = {
    currentRPM: 0,
    currentAirflow: 0,
    currentNoise: 0,
    currentPower: 0,
    dutyCycle: 0,
    targetTemperature: 65, // Celsius
    currentTemperature: 35 // Celsius
  };
  
  // USB connection
  private usbConnection: UsbConnectionStatus = {
    connected: false,
    connectionType: 'USB4.0',
    powerDelivery: 0,
    dataRate: 0,
    port: '',
    stable: false
  };
  
  // Control intervals
  private fanControlInterval: NodeJS.Timeout | null = null;
  private temperatureMonitorInterval: NodeJS.Timeout | null = null;
  
  private constructor() {
    log('🌪️ [FAN-SYS] Initializing USB 4.0 High-speed Fan System');
  }
  
  public static getInstance(): HighspeedFanSystem {
    if (!HighspeedFanSystem.instance) {
      HighspeedFanSystem.instance = new HighspeedFanSystem();
    }
    return HighspeedFanSystem.instance;
  }
  
  /**
   * Connect fan system via USB
   */
  public connectUsb(
    portName: string = 'usb-c1',
    connectionType: UsbConnectionType = 'USB4.0'
  ): UsbConnectionStatus {
    log(`🌪️ [FAN-SYS] Connecting to ${connectionType} port ${portName}`);
    
    // Calculate data rate based on connection type
    let dataRate = 0;
    let powerDelivery = 0;
    
    switch (connectionType) {
      case 'USB4.0':
        dataRate = 40; // Gbps
        powerDelivery = 100; // Watts
        break;
      case 'Thunderbolt4':
        dataRate = 40; // Gbps
        powerDelivery = 100; // Watts
        break;
      case 'USB3.2':
        dataRate = 20; // Gbps
        powerDelivery = 60; // Watts
        break;
      case 'USB3.1':
        dataRate = 10; // Gbps
        powerDelivery = 27; // Watts
        break;
      case 'USB-C':
        dataRate = 10; // Gbps
        powerDelivery = 15; // Watts
        break;
    }
    
    // Update connection status
    this.usbConnection = {
      connected: true,
      connectionType,
      powerDelivery,
      dataRate,
      port: portName,
      stable: true
    };
    
    log(`🌪️ [FAN-SYS] Connected to ${connectionType} port ${portName}`);
    log(`🌪️ [FAN-SYS] Data rate: ${dataRate} Gbps`);
    log(`🌪️ [FAN-SYS] Power delivery: ${powerDelivery}W`);
    
    return { ...this.usbConnection };
  }
  
  /**
   * Disconnect USB
   */
  public disconnectUsb(): boolean {
    if (!this.usbConnection.connected) {
      return false;
    }
    
    // Deactivate fan system if active
    if (this.active) {
      this.deactivate();
    }
    
    log('🌪️ [FAN-SYS] Disconnecting USB');
    
    // Reset connection
    this.usbConnection = {
      connected: false,
      connectionType: 'USB4.0',
      powerDelivery: 0,
      dataRate: 0,
      port: '',
      stable: false
    };
    
    log('🌪️ [FAN-SYS] USB disconnected');
    
    return true;
  }
  
  /**
   * Activate fan system
   */
  public activate(initialDutyCycle: number = 50): {
    success: boolean;
    rpm: number;
    airflow: number;
    message: string;
  } {
    if (this.active) {
      return {
        success: true,
        rpm: this.fanPerf.currentRPM,
        airflow: this.fanPerf.currentAirflow,
        message: 'Fan system already active'
      };
    }
    
    if (!this.usbConnection.connected) {
      return {
        success: false,
        rpm: 0,
        airflow: 0,
        message: 'Cannot activate: USB not connected'
      };
    }
    
    log(`🌪️ [FAN-SYS] Activating high-speed fan system at ${initialDutyCycle}% duty cycle`);
    
    // Check if we have enough power from USB
    if (this.usbConnection.powerDelivery < this.fanSpec.powerDraw) {
      log('🌪️ [FAN-SYS] Warning: USB power delivery may be insufficient for maximum performance');
    }
    
    // Initialize fan to requested duty cycle
    this.setFanSpeed(initialDutyCycle);
    
    // Start monitoring and control loops
    this.startMonitoring();
    
    this.active = true;
    
    log(`🌪️ [FAN-SYS] Fan activated at ${this.fanPerf.currentRPM} RPM`);
    log(`🌪️ [FAN-SYS] Current airflow: ${this.fanPerf.currentAirflow} CFM`);
    log(`🌪️ [FAN-SYS] Noise level: ${this.fanPerf.currentNoise} dBA`);
    
    return {
      success: true,
      rpm: this.fanPerf.currentRPM,
      airflow: this.fanPerf.currentAirflow,
      message: 'Fan system activated successfully'
    };
  }
  
  /**
   * Deactivate fan system
   */
  public deactivate(): boolean {
    if (!this.active) {
      return false;
    }
    
    log('🌪️ [FAN-SYS] Deactivating high-speed fan system');
    
    // Stop monitoring
    this.stopMonitoring();
    
    // Gradually slow down fan
    this.setFanSpeed(0);
    
    this.active = false;
    
    log('🌪️ [FAN-SYS] Fan system deactivated');
    
    return true;
  }
  
  /**
   * Set fan speed directly
   */
  public setFanSpeed(dutyCycle: number): {
    success: boolean;
    rpm: number;
    message: string;
  } {
    if (!this.usbConnection.connected) {
      return {
        success: false,
        rpm: 0,
        message: 'Cannot set fan speed: USB not connected'
      };
    }
    
    // Ensure duty cycle is within range
    dutyCycle = Math.max(0, Math.min(100, dutyCycle));
    
    log(`🌪️ [FAN-SYS] Setting fan duty cycle to ${dutyCycle}%`);
    
    // Calculate fan metrics based on duty cycle
    const rpm = Math.round((dutyCycle / 100) * this.fanSpec.maxRPM);
    const airflow = (dutyCycle / 100) * this.fanSpec.maxAirflow;
    
    // Calculate noise based on a non-linear curve (noise increases more at higher speeds)
    const noiseFactor = Math.pow(dutyCycle / 100, 1.5);
    const noise = dutyCycle > 0 
      ? Math.max(10, Math.round(noiseFactor * this.fanSpec.noiseLevel))
      : 0;
    
    // Calculate power draw
    const power = (dutyCycle / 100) * this.fanSpec.powerDraw;
    
    // Update performance metrics
    this.fanPerf = {
      ...this.fanPerf,
      currentRPM: rpm,
      currentAirflow: airflow,
      currentNoise: noise,
      currentPower: power,
      dutyCycle: dutyCycle
    };
    
    if (dutyCycle > 0) {
      log(`🌪️ [FAN-SYS] Fan running at ${rpm} RPM (${dutyCycle}%)`);
      log(`🌪️ [FAN-SYS] Airflow: ${airflow.toFixed(1)} CFM, Noise: ${noise} dBA`);
    } else {
      log('🌪️ [FAN-SYS] Fan stopped');
    }
    
    return {
      success: true,
      rpm,
      message: `Fan speed set to ${rpm} RPM (${dutyCycle}%)`
    };
  }
  
  /**
   * Start temperature monitoring and fan control
   */
  private startMonitoring(): void {
    if (this.fanControlInterval || this.temperatureMonitorInterval) {
      this.stopMonitoring();
    }
    
    log('🌪️ [FAN-SYS] Starting temperature monitoring and fan control');
    
    // Start temperature monitoring (every 3 seconds)
    this.temperatureMonitorInterval = setInterval(() => {
      this.updateTemperature();
    }, 3000);
    
    // Start fan control loop (every 5 seconds)
    this.fanControlInterval = setInterval(() => {
      this.automaticFanControl();
    }, 5000);
  }
  
  /**
   * Stop monitoring and control loops
   */
  private stopMonitoring(): void {
    if (this.fanControlInterval) {
      clearInterval(this.fanControlInterval);
      this.fanControlInterval = null;
    }
    
    if (this.temperatureMonitorInterval) {
      clearInterval(this.temperatureMonitorInterval);
      this.temperatureMonitorInterval = null;
    }
    
    log('🌪️ [FAN-SYS] Stopped temperature monitoring and fan control');
  }
  
  /**
   * Update current temperature reading
   */
  private updateTemperature(): void {
    // Get temperatures from custom heatsink or advanced cooling if available
    let newTemp = this.fanPerf.currentTemperature;
    
    if (customHeatsinkSystem && customHeatsinkSystem.isActive()) {
      const processorPerf = customHeatsinkSystem.getProcessorThermalPerformance();
      const m3Perf = customHeatsinkSystem.getM3ThermalPerformance();
      
      // Use the higher of processor or M.3 temperature
      newTemp = Math.max(processorPerf.loadTemperature, m3Perf.loadTemperature);
      
    } else if (advancedCoolingSystem && advancedCoolingSystem.isActive()) {
      const status = advancedCoolingSystem.getStatus();
      newTemp = Math.max(status.cpuTemp, status.gpuTemp);
      
    } else {
      // Simulate temperature changes if no real data available
      const tempVariation = Math.random() * 4 - 2; // -2 to +2 degrees
      newTemp = Math.max(30, Math.min(95, this.fanPerf.currentTemperature + tempVariation));
    }
    
    // Update current temperature
    if (Math.abs(newTemp - this.fanPerf.currentTemperature) > 1) {
      this.fanPerf.currentTemperature = newTemp;
      log(`🌪️ [FAN-SYS] Current temperature: ${newTemp.toFixed(1)}°C`);
    }
  }
  
  /**
   * Automatic fan control based on temperature
   */
  private automaticFanControl(): void {
    if (!this.active) {
      return;
    }
    
    const currentTemp = this.fanPerf.currentTemperature;
    const targetTemp = this.fanPerf.targetTemperature;
    const currentDuty = this.fanPerf.dutyCycle;
    
    let newDutyCycle = currentDuty;
    
    // Adjust fan speed based on temperature difference
    if (currentTemp > targetTemp + 10) {
      // Temperature is way too high, max fan speed
      newDutyCycle = 100;
    } else if (currentTemp > targetTemp + 5) {
      // Temperature is too high, increase fan speed significantly
      newDutyCycle = Math.min(100, currentDuty + 15);
    } else if (currentTemp > targetTemp + 2) {
      // Temperature is a bit high, increase fan speed
      newDutyCycle = Math.min(100, currentDuty + 5);
    } else if (currentTemp < targetTemp - 10) {
      // Temperature is way too low, minimum fan speed
      newDutyCycle = 25; // Keep a minimum speed for continuous cooling
    } else if (currentTemp < targetTemp - 5) {
      // Temperature is too low, decrease fan speed significantly
      newDutyCycle = Math.max(25, currentDuty - 10);
    } else if (currentTemp < targetTemp - 2) {
      // Temperature is a bit low, decrease fan speed
      newDutyCycle = Math.max(25, currentDuty - 5);
    }
    
    // Apply new duty cycle if it's different enough
    if (Math.abs(newDutyCycle - currentDuty) >= 5) {
      this.setFanSpeed(newDutyCycle);
    }
  }
  
  /**
   * Set target temperature
   */
  public setTargetTemperature(temperature: number): {
    success: boolean;
    previous: number;
    current: number;
    message: string;
  } {
    if (temperature < 30 || temperature > 85) {
      return {
        success: false,
        previous: this.fanPerf.targetTemperature,
        current: this.fanPerf.targetTemperature,
        message: 'Target temperature must be between 30°C and 85°C'
      };
    }
    
    const previous = this.fanPerf.targetTemperature;
    this.fanPerf.targetTemperature = temperature;
    
    log(`🌪️ [FAN-SYS] Target temperature set to ${temperature}°C (was ${previous}°C)`);
    
    return {
      success: true,
      previous,
      current: temperature,
      message: `Target temperature set to ${temperature}°C`
    };
  }
  
  /**
   * Apply fan profile from advanced cooling system
   */
  public applyFanProfile(profile: FanProfile): {
    success: boolean;
    profile: FanProfile;
    dutyCycle: number;
    message: string;
  } {
    if (!this.active) {
      return {
        success: false,
        profile,
        dutyCycle: 0,
        message: 'Fan system is not active'
      };
    }
    
    log(`🌪️ [FAN-SYS] Applying fan profile: ${profile}`);
    
    let dutyCycle = 0;
    
    // Set fan duty cycle based on profile
    switch (profile) {
      case 'Silent':
        dutyCycle = 30;
        this.fanPerf.targetTemperature = 75;
        break;
      case 'Standard':
        dutyCycle = 50;
        this.fanPerf.targetTemperature = 70;
        break;
      case 'Turbo':
        dutyCycle = 75;
        this.fanPerf.targetTemperature = 65;
        break;
      case 'Max':
        dutyCycle = 100;
        this.fanPerf.targetTemperature = 60;
        break;
      case 'Adaptive':
        // Start at 50% and let the automatic control adjust
        dutyCycle = 50;
        this.fanPerf.targetTemperature = 65;
        break;
    }
    
    // Set initial fan speed for the profile
    this.setFanSpeed(dutyCycle);
    
    return {
      success: true,
      profile,
      dutyCycle,
      message: `Applied ${profile} fan profile at ${dutyCycle}% initial speed`
    };
  }
  
  /**
   * Get current fan performance
   */
  public getFanPerformance(): FanPerformance {
    return { ...this.fanPerf };
  }
  
  /**
   * Get USB connection status
   */
  public getUsbStatus(): UsbConnectionStatus {
    return { ...this.usbConnection };
  }
  
  /**
   * Get fan specifications
   */
  public getFanSpecifications(): FanSpecification {
    return { ...this.fanSpec };
  }
  
  /**
   * Get cooling channel specifications
   */
  public getCoolingChannelSpecs(): CoolingChannelSpec {
    return { ...this.coolingSys };
  }
  
  /**
   * Check if fan system is active
   */
  public isActive(): boolean {
    return this.active;
  }
}

// Create and export instance
const highspeedFanSystem = HighspeedFanSystem.getInstance();

export {
  highspeedFanSystem,
  type UsbConnectionType,
  type FanType,
  type FanSpecification,
  type CoolingChannelSpec,
  type FanPerformance,
  type UsbConnectionStatus
};