/**
 * SHIELD CORE - ROG ALLY X INTEGRATION
 * 
 * Integration with ASUS ROG Ally X handheld gaming PC capabilities,
 * leveraging its AMD Ryzen Z1 Extreme processor with RDNA 3 graphics
 * for enhanced Shield Core performance and security features.
 * 
 * Version: ROG-ALLY-X-1.0
 */

import { log } from '../vite';
import { externalGpuSystem } from './external-gpu-integration';
import { highspeedFanSystem } from './highspeed-fan-usb4';

// ROG Ally X specifications
interface RogAllyXSpecs {
  processor: {
    model: string;
    cores: number;
    threads: number;
    baseClockSpeed: number; // GHz
    boostClockSpeed: number; // GHz
    cache: number; // MB
    tdp: number; // Watts
  };
  graphics: {
    model: string;
    architecture: string;
    computeUnits: number;
    maxFrequency: number; // MHz
    rayAccelerators: number;
    shaderProcessors: number;
    tflops: number;
    supportedAPIs: string[];
  };
  memory: {
    type: string;
    size: number; // GB
    frequency: number; // MHz
    bandwidth: number; // GB/s
    channels: number;
  };
  storage: {
    type: string;
    capacity: number; // GB
    interface: string;
    readSpeed: number; // MB/s
    writeSpeed: number; // MB/s
  };
  connectivity: {
    usb4Ports: number;
    usbCPorts: number;
    wifi: string;
    bluetooth: string;
    audioJack: boolean;
    xgMobilePort: boolean;
  };
  cooling: {
    system: string;
    maxFanSpeed: number; // RPM
    heatpipes: number;
    coolingCapacity: number; // Watts
    maxNoiseLevel: number; // dBA
  };
  display: {
    size: number; // inches
    resolution: string;
    refreshRate: number; // Hz
    responseTime: number; // ms
    touchEnabled: boolean;
  };
  powerDelivery: {
    batteryCapacity: number; // Wh
    maxCharging: number; // Watts
    typicalBatteryLife: number; // hours
  };
}

// Performance modes
type RogAllyPerformanceMode = 'Turbo' | 'Performance' | 'Balanced' | 'Silent' | 'Windows';

// ROG Ally X connection type
type ConnectionType = 'USB4' | 'USB-C' | 'WiFi' | 'Bluetooth';

// Connection status
interface ConnectionStatus {
  connected: boolean;
  connectionType: ConnectionType;
  bandwidth: number; // Mbps
  latency: number; // ms
  secure: boolean;
}

/**
 * ROG Ally X Integration System
 */
class RogAllyXIntegration {
  private static instance: RogAllyXIntegration;
  private active: boolean = false;
  
  // Device specifications
  private deviceSpecs: RogAllyXSpecs = {
    processor: {
      model: 'AMD Ryzen Z1 Extreme',
      cores: 8,
      threads: 16,
      baseClockSpeed: 3.3, // GHz
      boostClockSpeed: 5.1, // GHz
      cache: 24, // MB
      tdp: 30, // Watts
      integratedGraphics: 'AMD Radeon Graphics (RDNA 3)',
      graphicsCores: 12,
      graphicsFrequency: 2700 // MHz
    },
    graphics: {
      model: 'Qualcomm Adreno 750',
      architecture: 'Adreno 7-series',
      computeUnits: 8,
      maxFrequency: 1000, // MHz
      rayAccelerators: 0,
      shaderProcessors: 1024, 
      tflops: 4.2,
      supportedAPIs: ['Vulkan 1.3', 'OpenGL ES 3.2', 'OpenCL 2.0', 'DirectX 12']
    },
    memory: {
      type: 'LPDDR5X',
      size: 16, // GB
      frequency: 8533, // MHz
      bandwidth: 68.26, // GB/s
      channels: 4 // Quad-channel
    },
    storage: {
      type: 'PCIe 4.0 NVMe SSD',
      capacity: 1024, // GB
      interface: 'PCIe 4.0 x4',
      readSpeed: 7000, // MB/s
      writeSpeed: 5300 // MB/s
    },
    connectivity: {
      usb4Ports: 1,
      usbCPorts: 1,
      wifi: 'WiFi 6E (802.11ax)',
      bluetooth: 'Bluetooth 5.2',
      audioJack: true,
      xgMobilePort: true
    },
    cooling: {
      system: 'Dual-fan with vapor chamber',
      maxFanSpeed: 12000, // RPM
      heatpipes: 2,
      coolingCapacity: 65, // Watts
      maxNoiseLevel: 42 // dBA
    },
    display: {
      size: 7, // inches
      resolution: '1920x1080',
      refreshRate: 120, // Hz
      responseTime: 7, // ms
      touchEnabled: true
    },
    powerDelivery: {
      batteryCapacity: 80, // Wh
      maxCharging: 100, // Watts
      typicalBatteryLife: 6 // hours
    }
  };
  
  // Current performance mode
  private performanceMode: RogAllyPerformanceMode = 'Balanced';
  
  // Connection status
  private connectionStatus: ConnectionStatus = {
    connected: false,
    connectionType: 'USB4',
    bandwidth: 0,
    latency: 0,
    secure: false
  };
  
  // Integrated systems
  private externalGpuConnected: boolean = false;
  private fanSystemConnected: boolean = false;
  
  private constructor() {
    log('🎮 [ROG-ALLY-X] Initializing ROG Ally X integration system');
  }
  
  public static getInstance(): RogAllyXIntegration {
    if (!RogAllyXIntegration.instance) {
      RogAllyXIntegration.instance = new RogAllyXIntegration();
    }
    return RogAllyXIntegration.instance;
  }
  
  /**
   * Connect to ROG Ally X
   */
  public connect(connectionType: ConnectionType = 'USB4'): ConnectionStatus {
    log(`🎮 [ROG-ALLY-X] Connecting to ROG Ally X via ${connectionType}`);
    
    // Calculate bandwidth based on connection type
    let bandwidth = 0;
    let latency = 0;
    
    switch (connectionType) {
      case 'USB4':
        bandwidth = 40000; // 40 Gbps
        latency = 0.5; // ms
        break;
      case 'USB-C':
        bandwidth = 10000; // 10 Gbps
        latency = 1; // ms
        break;
      case 'WiFi':
        bandwidth = 2400; // 2.4 Gbps (WiFi 6E)
        latency = 5; // ms
        break;
      case 'Bluetooth':
        bandwidth = 50; // 50 Mbps
        latency = 20; // ms
        break;
    }
    
    // Update connection status
    this.connectionStatus = {
      connected: true,
      connectionType,
      bandwidth,
      latency,
      secure: true
    };
    
    log(`🎮 [ROG-ALLY-X] Connected to ROG Ally X via ${connectionType}`);
    log(`🎮 [ROG-ALLY-X] Connection bandwidth: ${bandwidth} Mbps`);
    log(`🎮 [ROG-ALLY-X] Connection latency: ${latency} ms`);
    
    return { ...this.connectionStatus };
  }
  
  /**
   * Disconnect from ROG Ally X
   */
  public disconnect(): boolean {
    if (!this.connectionStatus.connected) {
      return false;
    }
    
    // Disconnect integrated systems first
    this.disconnectExternalGpu();
    this.disconnectFanSystem();
    
    // Deactivate if active
    if (this.active) {
      this.deactivate();
    }
    
    log('🎮 [ROG-ALLY-X] Disconnecting from ROG Ally X');
    
    // Reset connection status
    this.connectionStatus = {
      connected: false,
      connectionType: 'USB4',
      bandwidth: 0,
      latency: 0,
      secure: false
    };
    
    log('🎮 [ROG-ALLY-X] ROG Ally X disconnected');
    
    return true;
  }
  
  /**
   * Activate ROG Ally X integration
   */
  public activate(mode: RogAllyPerformanceMode = 'Balanced'): {
    success: boolean;
    mode: RogAllyPerformanceMode;
    gpuFrequency: number;
    cpuFrequency: number;
    message: string;
  } {
    if (!this.connectionStatus.connected) {
      return {
        success: false,
        mode: 'Balanced',
        gpuFrequency: 0,
        cpuFrequency: 0,
        message: 'Cannot activate: ROG Ally X not connected'
      };
    }
    
    if (this.active) {
      // If already active, just change mode if different
      if (this.performanceMode !== mode) {
        return this.setPerformanceMode(mode);
      }
      
      return {
        success: true,
        mode: this.performanceMode,
        gpuFrequency: this.calculateGpuFrequency(),
        cpuFrequency: this.calculateCpuFrequency(),
        message: 'ROG Ally X integration already active'
      };
    }
    
    log(`🎮 [ROG-ALLY-X] Activating ROG Ally X integration in ${mode} mode`);
    
    // Apply the requested performance mode
    this.setPerformanceMode(mode, false);
    
    this.active = true;
    
    // Connect integrated systems if possible
    if (this.connectionStatus.connectionType === 'USB4') {
      this.connectExternalGpu();
      this.connectFanSystem();
    }
    
    const gpuFreq = this.calculateGpuFrequency();
    const cpuFreq = this.calculateCpuFrequency();
    
    log('🎮 [ROG-ALLY-X] ROG Ally X integration activated successfully');
    log(`🎮 [ROG-ALLY-X] Performance mode: ${this.performanceMode}`);
    log(`🎮 [ROG-ALLY-X] GPU Frequency: ${gpuFreq} MHz`);
    log(`🎮 [ROG-ALLY-X] CPU Frequency: ${cpuFreq} GHz`);
    
    return {
      success: true,
      mode: this.performanceMode,
      gpuFrequency: gpuFreq,
      cpuFrequency: cpuFreq,
      message: `ROG Ally X integration activated in ${mode} mode`
    };
  }
  
  /**
   * Deactivate ROG Ally X integration
   */
  public deactivate(): boolean {
    if (!this.active) {
      return false;
    }
    
    log('🎮 [ROG-ALLY-X] Deactivating ROG Ally X integration');
    
    // Disconnect integrated systems
    this.disconnectExternalGpu();
    this.disconnectFanSystem();
    
    this.active = false;
    
    log('🎮 [ROG-ALLY-X] ROG Ally X integration deactivated');
    
    return true;
  }
  
  /**
   * Set ROG Ally X performance mode
   */
  public setPerformanceMode(mode: RogAllyPerformanceMode, logOutput: boolean = true): {
    success: boolean;
    mode: RogAllyPerformanceMode;
    gpuFrequency: number;
    cpuFrequency: number;
    message: string;
  } {
    if (!this.connectionStatus.connected) {
      return {
        success: false,
        mode: this.performanceMode,
        gpuFrequency: 0,
        cpuFrequency: 0,
        message: 'Cannot set mode: ROG Ally X not connected'
      };
    }
    
    if (logOutput) {
      log(`🎮 [ROG-ALLY-X] Setting performance mode to ${mode}`);
    }
    
    const previousMode = this.performanceMode;
    this.performanceMode = mode;
    
    // Update external systems if connected
    if (this.externalGpuConnected) {
      let gpuMode: 'Standard' | 'Gaming' | 'AI' | 'Creator' | 'Extreme';
      
      switch (mode) {
        case 'Turbo': gpuMode = 'Extreme'; break;
        case 'Performance': gpuMode = 'Gaming'; break;
        case 'Balanced': gpuMode = 'Standard'; break;
        case 'Silent': gpuMode = 'Standard'; break;
        case 'Windows': gpuMode = 'Creator'; break;
        default: gpuMode = 'Standard';
      }
      
      externalGpuSystem.setPerformanceMode(gpuMode);
    }
    
    if (this.fanSystemConnected) {
      let fanProfile: 'Silent' | 'Standard' | 'Turbo' | 'Max' | 'Adaptive';
      
      switch (mode) {
        case 'Turbo': fanProfile = 'Max'; break;
        case 'Performance': fanProfile = 'Turbo'; break;
        case 'Balanced': fanProfile = 'Standard'; break;
        case 'Silent': fanProfile = 'Silent'; break;
        case 'Windows': fanProfile = 'Adaptive'; break;
        default: fanProfile = 'Standard';
      }
      
      highspeedFanSystem.applyFanProfile(fanProfile);
    }
    
    const gpuFreq = this.calculateGpuFrequency();
    const cpuFreq = this.calculateCpuFrequency();
    
    if (logOutput) {
      log(`🎮 [ROG-ALLY-X] Mode changed from ${previousMode} to ${mode}`);
      log(`🎮 [ROG-ALLY-X] New GPU frequency: ${gpuFreq} MHz`);
      log(`🎮 [ROG-ALLY-X] New CPU frequency: ${cpuFreq} GHz`);
    }
    
    return {
      success: true,
      mode,
      gpuFrequency: gpuFreq,
      cpuFrequency: cpuFreq,
      message: `Performance mode set to ${mode}`
    };
  }
  
  /**
   * Connect to external GPU system
   */
  private connectExternalGpu(): boolean {
    if (this.externalGpuConnected) {
      return true;
    }
    
    if (!externalGpuSystem) {
      log('🎮 [ROG-ALLY-X] External GPU system not available');
      return false;
    }
    
    log('🎮 [ROG-ALLY-X] Connecting external GPU system');
    
    const connectionResult = externalGpuSystem.connect('USB 4.0');
    
    if (connectionResult.connected) {
      this.externalGpuConnected = true;
      
      // Activate with appropriate mode
      let gpuMode: 'Standard' | 'Gaming' | 'AI' | 'Creator' | 'Extreme';
      
      switch (this.performanceMode) {
        case 'Turbo': gpuMode = 'Extreme'; break;
        case 'Performance': gpuMode = 'Gaming'; break;
        case 'Balanced': gpuMode = 'Standard'; break;
        case 'Silent': gpuMode = 'Standard'; break;
        case 'Windows': gpuMode = 'Creator'; break;
        default: gpuMode = 'Standard';
      }
      
      externalGpuSystem.activate(gpuMode);
      
      log('🎮 [ROG-ALLY-X] External GPU system connected and activated');
      return true;
    }
    
    log('🎮 [ROG-ALLY-X] Failed to connect external GPU system');
    return false;
  }
  
  /**
   * Disconnect from external GPU system
   */
  private disconnectExternalGpu(): boolean {
    if (!this.externalGpuConnected) {
      return false;
    }
    
    if (!externalGpuSystem) {
      return false;
    }
    
    log('🎮 [ROG-ALLY-X] Disconnecting external GPU system');
    
    // Deactivate first
    if (externalGpuSystem.isActive()) {
      externalGpuSystem.deactivate();
    }
    
    const result = externalGpuSystem.disconnect();
    
    if (result) {
      this.externalGpuConnected = false;
      log('🎮 [ROG-ALLY-X] External GPU system disconnected');
      return true;
    }
    
    return false;
  }
  
  /**
   * Connect to fan system
   */
  private connectFanSystem(): boolean {
    if (this.fanSystemConnected) {
      return true;
    }
    
    if (!highspeedFanSystem) {
      log('🎮 [ROG-ALLY-X] High-speed fan system not available');
      return false;
    }
    
    log('🎮 [ROG-ALLY-X] Connecting high-speed fan system');
    
    const connectionResult = highspeedFanSystem.connectUsb('usb-c1', 'USB4.0');
    
    if (connectionResult.connected) {
      this.fanSystemConnected = true;
      
      // Activate with appropriate profile
      let fanProfile: 'Silent' | 'Standard' | 'Turbo' | 'Max' | 'Adaptive';
      
      switch (this.performanceMode) {
        case 'Turbo': fanProfile = 'Max'; break;
        case 'Performance': fanProfile = 'Turbo'; break;
        case 'Balanced': fanProfile = 'Standard'; break;
        case 'Silent': fanProfile = 'Silent'; break;
        case 'Windows': fanProfile = 'Adaptive'; break;
        default: fanProfile = 'Standard';
      }
      
      highspeedFanSystem.activate(50);
      highspeedFanSystem.applyFanProfile(fanProfile);
      
      log('🎮 [ROG-ALLY-X] High-speed fan system connected and activated');
      return true;
    }
    
    log('🎮 [ROG-ALLY-X] Failed to connect high-speed fan system');
    return false;
  }
  
  /**
   * Disconnect from fan system
   */
  private disconnectFanSystem(): boolean {
    if (!this.fanSystemConnected) {
      return false;
    }
    
    if (!highspeedFanSystem) {
      return false;
    }
    
    log('🎮 [ROG-ALLY-X] Disconnecting high-speed fan system');
    
    // Deactivate first
    if (highspeedFanSystem.isActive()) {
      highspeedFanSystem.deactivate();
    }
    
    const result = highspeedFanSystem.disconnectUsb();
    
    if (result) {
      this.fanSystemConnected = false;
      log('🎮 [ROG-ALLY-X] High-speed fan system disconnected');
      return true;
    }
    
    return false;
  }
  
  /**
   * Calculate current GPU frequency based on performance mode
   */
  private calculateGpuFrequency(): number {
    const baseFreq = this.deviceSpecs.graphics.maxFrequency;
    
    switch (this.performanceMode) {
      case 'Turbo':
        return Math.round(baseFreq * 1.05); // 5% boost
      case 'Performance':
        return baseFreq;
      case 'Balanced':
        return Math.round(baseFreq * 0.9);
      case 'Silent':
        return Math.round(baseFreq * 0.7);
      case 'Windows':
        return Math.round(baseFreq * 0.95);
      default:
        return baseFreq;
    }
  }
  
  /**
   * Calculate current CPU frequency based on performance mode
   */
  private calculateCpuFrequency(): number {
    const baseFreq = this.deviceSpecs.processor.baseClockSpeed;
    const boostFreq = this.deviceSpecs.processor.boostClockSpeed;
    
    switch (this.performanceMode) {
      case 'Turbo':
        return boostFreq;
      case 'Performance':
        return baseFreq + (boostFreq - baseFreq) * 0.8;
      case 'Balanced':
        return baseFreq + (boostFreq - baseFreq) * 0.5;
      case 'Silent':
        return baseFreq;
      case 'Windows':
        return baseFreq + (boostFreq - baseFreq) * 0.7;
      default:
        return baseFreq;
    }
  }
  
  /**
   * Process Shield Core task using ROG Ally X hardware
   */
  public runShieldCoreTask(
    taskType: 'VoiceAuthentication' | 'GraphicsProcessing' | 'SecurityAnalysis' | 'DataEncryption',
    priority: 'Low' | 'Normal' | 'High' | 'Critical' = 'Normal'
  ): Promise<{
    success: boolean;
    taskType: string;
    executionTime: number;
    processingDetails: {
      cpuUsage: number;
      gpuUsage: number;
      memoryUsage: number;
      temperature: number;
    };
    message: string;
  }> {
    return new Promise((resolve) => {
      if (!this.active) {
        resolve({
          success: false,
          taskType,
          executionTime: 0,
          processingDetails: {
            cpuUsage: 0,
            gpuUsage: 0,
            memoryUsage: 0,
            temperature: 0
          },
          message: 'ROG Ally X integration not active'
        });
        return;
      }
      
      log(`🎮 [ROG-ALLY-X] Running ${priority} priority ${taskType} task`);
      
      // Determine which hardware to prioritize
      let useGpu = false;
      let executionTime = 0;
      let cpuUsage = 0;
      let gpuUsage = 0;
      
      switch (taskType) {
        case 'VoiceAuthentication':
          useGpu = false;
          executionTime = 50; // ms
          cpuUsage = 60;
          gpuUsage = 10;
          break;
        case 'GraphicsProcessing':
          useGpu = true;
          executionTime = 120; // ms
          cpuUsage = 30;
          gpuUsage = 75;
          break;
        case 'SecurityAnalysis':
          useGpu = false;
          executionTime = 200; // ms
          cpuUsage = 85;
          gpuUsage = 5;
          break;
        case 'DataEncryption':
          useGpu = false;
          executionTime = 80; // ms
          cpuUsage = 70;
          gpuUsage = 0;
          break;
      }
      
      // Adjust execution time based on performance mode
      const performanceFactor =
        this.performanceMode === 'Turbo' ? 0.7 :
        this.performanceMode === 'Performance' ? 0.85 :
        this.performanceMode === 'Silent' ? 1.4 :
        1.0; // Balanced
      
      executionTime *= performanceFactor;
      
      // Adjust for priority
      const priorityFactor =
        priority === 'Low' ? 1.3 :
        priority === 'High' ? 0.8 :
        priority === 'Critical' ? 0.6 :
        1.0; // Normal
      
      executionTime *= priorityFactor;
      
      // If external GPU connected and task uses GPU, offload it
      if (useGpu && this.externalGpuConnected) {
        // Process via external GPU
        log('🎮 [ROG-ALLY-X] Offloading task to external GPU');
        
        externalGpuSystem.runAccelerationTask(
          taskType === 'GraphicsProcessing' ? 'Graphics' : 'Compute',
          priority
        ).then(gpuResult => {
          resolve({
            success: true,
            taskType,
            executionTime: gpuResult.executionTime,
            processingDetails: {
              cpuUsage: cpuUsage * 0.5, // Lower CPU usage with external GPU
              gpuUsage: gpuResult.utilizationPeak,
              memoryUsage: 1.2, // GB
              temperature: 65
            },
            message: `${taskType} task processed with external GPU acceleration`
          });
        });
        
        return;
      }
      
      // Simulate task execution with a delay
      setTimeout(() => {
        // Task completed
        log(`🎮 [ROG-ALLY-X] ${taskType} task completed in ${executionTime.toFixed(0)}ms`);
        
        // Calculate memory usage
        const memoryUsage = cpuUsage * 0.03 + gpuUsage * 0.01; // GB
        
        // Calculate temperature
        const baseTemp = 45;
        const tempIncrease = (cpuUsage * 0.2 + gpuUsage * 0.15);
        const temperature = baseTemp + tempIncrease;
        
        resolve({
          success: true,
          taskType,
          executionTime,
          processingDetails: {
            cpuUsage,
            gpuUsage,
            memoryUsage,
            temperature
          },
          message: `${taskType} task processed successfully with ROG Ally X hardware`
        });
      }, Math.min(executionTime, 500)); // Cap actual waiting time
    });
  }
  
  /**
   * Get ROG Ally X specifications
   */
  public getDeviceSpecifications(): RogAllyXSpecs {
    return { ...this.deviceSpecs };
  }
  
  /**
   * Get connection status
   */
  public getConnectionStatus(): ConnectionStatus {
    return { ...this.connectionStatus };
  }
  
  /**
   * Get hardware utilization
   */
  public getHardwareUtilization(): {
    cpuUtilization: number;
    gpuUtilization: number;
    memoryUsage: number;
    temperature: number;
    powerConsumption: number;
  } {
    if (!this.active) {
      return {
        cpuUtilization: 0,
        gpuUtilization: 0,
        memoryUsage: 0,
        temperature: 0,
        powerConsumption: 0
      };
    }
    
    // Base utilization depending on performance mode
    let baseCpuUtil = 0;
    let baseGpuUtil = 0;
    
    switch (this.performanceMode) {
      case 'Turbo':
        baseCpuUtil = 25;
        baseGpuUtil = 30;
        break;
      case 'Performance':
        baseCpuUtil = 20;
        baseGpuUtil = 25;
        break;
      case 'Balanced':
        baseCpuUtil = 15;
        baseGpuUtil = 15;
        break;
      case 'Silent':
        baseCpuUtil = 10;
        baseGpuUtil = 5;
        break;
      case 'Windows':
        baseCpuUtil = 15;
        baseGpuUtil = 20;
        break;
    }
    
    // Add some random variations
    const cpuUtilization = baseCpuUtil + (Math.random() * 10 - 5);
    const gpuUtilization = baseGpuUtil + (Math.random() * 10 - 5);
    
    // Memory usage based on utilization
    const memoryUsage = (this.deviceSpecs.memory.size * 0.2) + 
                        (cpuUtilization * 0.05) + 
                        (gpuUtilization * 0.03);
    
    // Temperature based on utilization and performance mode
    const baseTemp = 
      this.performanceMode === 'Turbo' ? 55 :
      this.performanceMode === 'Performance' ? 50 :
      this.performanceMode === 'Silent' ? 40 :
      45; // Balanced or Windows
    
    const temperature = baseTemp + 
                        (cpuUtilization * 0.15) + 
                        (gpuUtilization * 0.1);
    
    // Power consumption based on utilization and performance mode
    const basePower = 
      this.performanceMode === 'Turbo' ? 25 :
      this.performanceMode === 'Performance' ? 20 :
      this.performanceMode === 'Silent' ? 10 :
      15; // Balanced or Windows
    
    const powerConsumption = basePower + 
                             (cpuUtilization * 0.2) + 
                             (gpuUtilization * 0.15);
    
    return {
      cpuUtilization,
      gpuUtilization,
      memoryUsage,
      temperature,
      powerConsumption
    };
  }
  
  /**
   * Check if ROG Ally X integration is active
   */
  public isActive(): boolean {
    return this.active;
  }
  
  /**
   * Get current performance mode
   */
  public getPerformanceMode(): RogAllyPerformanceMode {
    return this.performanceMode;
  }
}

// Create and export instance
const rogAllyXIntegration = RogAllyXIntegration.getInstance();

export {
  rogAllyXIntegration,
  type RogAllyXSpecs,
  type RogAllyPerformanceMode,
  type ConnectionType,
  type ConnectionStatus
};