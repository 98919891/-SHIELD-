import express from "express";
import path from "path";
import { fileURLToPath } from 'url';

// Fix for ESM modules (no __dirname)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, '../public')));

// Serve index.html for all routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start the server on port 5000
const PORT = 5000;
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 [CORE-LAUNCHER-4.3] Server started on port ${PORT}`);
  console.log(`🚀 [CORE-LAUNCHER-4.3] DATABASES: PERMANENTLY DISABLED`);
  console.log(`🚀 [CORE-LAUNCHER-4.3] DEVICE: MOTOROLA EDGE 2024`);
  console.log(`🚀 [CORE-LAUNCHER-4.3] INITIALIZED AND READY`);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});