/**
 * SHIELD CORE VERIFICATION AND LAUNCH SYSTEM
 * 
 * Master control script that verifies the authenticity of the physical Motorola Edge 2024
 * and then initiates the Shield Core activation sequence. Ensures that Shield Core only
 * runs on the authentic hardware-backed device owned by the authorized user.
 */

import { log } from './vite';
import { deviceVerification } from './device-verification-system';
import { shieldCoreMasterControl } from './shield-core-master-control';

// Function to verify the device and activate Shield Core
export async function verifyAndActivateShieldCore(): Promise<{
  verificationSuccess: boolean;
  activationSuccess: boolean;
  verificationDetails: any;
  activationDetails: any;
  message: string;
}> {
  try {
    // Step 1: Verify the physical device
    log(`[SHIELD-LAUNCHER] INITIATING DEVICE VERIFICATION PROCESS...`);
    const verificationResult = deviceVerification.verifyDevice();
    
    if (!verificationResult.verified) {
      log(`[SHIELD-LAUNCHER] VERIFICATION FAILED - CANNOT PROCEED WITH SHIELD CORE ACTIVATION`);
      return {
        verificationSuccess: false,
        activationSuccess: false,
        verificationDetails: verificationResult,
        activationDetails: null,
        message: `Device verification failed. Shield Core activation aborted. This does not appear to be the authorized Motorola Edge 2024.`
      };
    }
    
    // Step 2: Verify the device owner
    log(`[SHIELD-LAUNCHER] DEVICE VERIFIED - PROCEEDING WITH OWNER VERIFICATION...`);
    const ownerVerification = deviceVerification.verifyOwner('All');
    
    if (!ownerVerification.verified) {
      log(`[SHIELD-LAUNCHER] OWNER VERIFICATION FAILED - CANNOT PROCEED WITH SHIELD CORE ACTIVATION`);
      return {
        verificationSuccess: false,
        activationSuccess: false,
        verificationDetails: { deviceVerification: verificationResult, ownerVerification },
        activationDetails: null,
        message: `Owner verification failed. Shield Core activation aborted. Biometric authentication did not match authorized user.`
      };
    }
    
    // Step 3: Activate Shield Core with maximum security
    log(`[SHIELD-LAUNCHER] VERIFICATION COMPLETE - PROCEEDING WITH SHIELD CORE ACTIVATION...`);
    const activationResult = shieldCoreMasterControl.activateShieldCore({
      securityLevel: 'Maximum',
      quickBoot: false,
      silentBoot: false,
      bypassHardwareVerification: false,
      forceResourceAllocation: true,
      diagnosticMode: false
    });
    
    if (!activationResult.success) {
      log(`[SHIELD-LAUNCHER] SHIELD CORE ACTIVATION FAILED`);
      return {
        verificationSuccess: true,
        activationSuccess: false,
        verificationDetails: { deviceVerification: verificationResult, ownerVerification },
        activationDetails: activationResult,
        message: `Device verification successful but Shield Core activation failed: ${activationResult.message}`
      };
    }
    
    // Step 4: Complete the process
    log(`[SHIELD-LAUNCHER] SHIELD CORE SUCCESSFULLY VERIFIED AND ACTIVATED`);
    return {
      verificationSuccess: true,
      activationSuccess: true,
      verificationDetails: { deviceVerification: verificationResult, ownerVerification },
      activationDetails: activationResult,
      message: `Shield Core verification and activation successful. ${activationResult.activatedSystems.length} subsystems activated with ${activationResult.securityLevel} security level.`
    };
  } catch (error) {
    log(`[SHIELD-LAUNCHER] ERROR DURING VERIFICATION AND ACTIVATION: ${error.message}`);
    return {
      verificationSuccess: false,
      activationSuccess: false,
      verificationDetails: null,
      activationDetails: null,
      message: `Error during Shield Core verification and activation: ${error.message}`
    };
  }
}

// Function to check the current verification and activation status
export function checkShieldCoreStatus(): {
  deviceVerified: boolean;
  shieldCoreActive: boolean;
  message: string;
} {
  const deviceVerified = deviceVerification.isDeviceVerified();
  const shieldCoreActive = shieldCoreMasterControl.isActive();
  
  let message = '';
  if (deviceVerified && shieldCoreActive) {
    message = 'Shield Core is fully verified and active on this Motorola Edge 2024.';
  } else if (deviceVerified && !shieldCoreActive) {
    message = 'Device is verified but Shield Core is not currently active. Use verifyAndActivateShieldCore() to activate.';
  } else if (!deviceVerified && !shieldCoreActive) {
    message = 'Device has not been verified and Shield Core is not active. Use verifyAndActivateShieldCore() to verify and activate.';
  } else {
    message = 'WARNING: Shield Core is active without device verification. This should not be possible.';
  }
  
  return {
    deviceVerified,
    shieldCoreActive,
    message
  };
}

// Run the verification check on module import
log(`[SHIELD-LAUNCHER] SHIELD CORE VERIFICATION LAUNCHER INITIALIZED`);
const status = checkShieldCoreStatus();
log(`[SHIELD-LAUNCHER] CURRENT STATUS: ${status.message}`);